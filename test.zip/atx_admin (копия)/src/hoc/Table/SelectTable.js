import {Checkbox, Whisper, Popover, ButtonToolbar, Button} from "rsuite";
import {Table, Column, HeaderCell, Cell} from 'rsuite-table';
import React from "react";

const CheckCell = ({rowData, onChange, checkedKeys, dataKey, ...props}) => (
    <Cell {...props} style={{ padding: 0 }}>
        <div style={{ lineHeight: '30px', position: 'relative', top:'-8px' }}>
            <Checkbox
                value={rowData[dataKey]}
                inline
                // style={}
                onChange={onChange}
                checked={checkedKeys.some(item => item === rowData[dataKey])}
            />
        </div>
    </Cell>
);

export default Table => {
    class SelectTable extends React.PureComponent {
        constructor(props) {
            super(props);
            this.state = {
                checkedKeys: [],
                data: props.data,
                columns: props.columns
            };
            this.handleCheck = this.handleCheck.bind(this);
            this.onSelectAll = this.onSelectAll.bind(this);
            this.onSelectForPage = this.onSelectForPage.bind(this);
        }

        onSelectAll() {
            const checkedKeys = this.state.data.map(item => item.id);
            this.setState({
                checkedKeys
            });
            this.props.onChangeSelectElements(checkedKeys)
        }

        onSelectForPage() {
            console.log('tratata', this.state, this.props);
            const {displayLength, page} = this.props;
            const checkedKeys = this.getCheckedKeys(displayLength, page);
            this.setState({checkedKeys});
            this.props.onChangeSelectElements(checkedKeys)
        }

        getCheckedKeys = (displayLength, page) => {
            const {data} = this.props;
            return data.filter((v, i) => {
                const start = displayLength * (page - 1);
                const end = start + displayLength;
                return i >= start && i < end;
            }).map(el => el.id)
        };

        handleCheck(value, checked) {
            const {checkedKeys} = this.state;
            const nextCheckedKeys = checked
                ? [...checkedKeys, value]
                : checkedKeys.filter(item => item !== value);

            this.setState({
                checkedKeys: nextCheckedKeys
            });
            this.props.onChangeSelectElements(nextCheckedKeys)
        }

        render() {
            const {checkedKeys} = this.state;
            const {data} = this.props;
            console.log('SelectTable', this.props);

            let checked = false;
            let indeterminate = false;

            if (checkedKeys.length === data.length) {
                checked = true;
            } else if (checkedKeys.length === 0) {
                checked = false;
            } else if (checkedKeys.length > 0 && checkedKeys.length < data.length) {
                indeterminate = true;
            }
            const speaker = (
                <Popover title="Are you sure want to select all entries">
                    <ButtonToolbar>
                        <Button onClick={this.onSelectAll}>Yes</Button>
                        <Button onClick={this.onSelectForPage}>No, only on this page</Button>
                    </ButtonToolbar>
                </Popover>
            );
            const selectColumn = <Column width={80} align="center">
                <HeaderCell style={{padding: 0}} >
                    <Whisper placement="top" trigger="focus" speaker={speaker} >
                            <Checkbox
                                inline
                                checked={checked}
                                indeterminate={indeterminate}
                            />
                    </Whisper>
                </HeaderCell>
                <CheckCell
                    dataKey="id"
                    checkedKeys={checkedKeys}
                    onChange={this.handleCheck}
                />
            </Column>;

            return (
                <Table
                    data={data}
                    id="table"
                    selectColumn={selectColumn}
                    {...this.props}
                >
                </Table>
            );
        }
    }

    return SelectTable;
}

