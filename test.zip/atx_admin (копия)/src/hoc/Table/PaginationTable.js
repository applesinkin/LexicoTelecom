import React from 'react';
import {Table} from 'rsuite';
const {Pagination}  = Table;

export default   (Table) => {
    class PaginationTable extends React.PureComponent{
        constructor(props) {
            super(props);
            this.state = {
                loading: false,
                page: 1,
                data: props.data,
                displayLength: 12
            };
        }

        shouldComponentUpdate(nextProps){
            if(nextProps.page !== this.props.page){
                this.setState({page:nextProps.page});
                return false;
            }
            return true;
        }

        handleChangePage = (dataKey) => {
            this.setState({
              page: dataKey
            });
            this.props.onChangePage(dataKey)
        }

        handleChangeLength = (dataKey) => {
            this.setState({
              page: 1,
              displayLength: dataKey
            });
        }

        getData = () =>  {
            const { displayLength, page } = this.state;
            const { data } = this.props;

            return data.filter((v, i) => {
              const start = displayLength * (page - 1);
              const end = start + displayLength;
              return i >= start && i < end;
            });
        }


        render() {     
            const {  page } = this.state;
            const data = this.getData();
            console.log('Pagination table', this.state, this.props);
            return (
                <>
                    <Table {...this.props} data={data} />
                    <Pagination
                        activePage={page}                        
                        total={this.props.data.length}
                        displayLength={this.props.displayLength}
                        page={page}
                        onChangePage={this.handleChangePage}
                        onChangeLength={this.handleChangeLength}
                        showLengthMenu={false}
                    />
                </>
            )
        }
    }

    return PaginationTable; 
}