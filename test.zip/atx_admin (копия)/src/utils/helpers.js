import _ from "lodash";
import {EOL} from "const";
import {Alert as rAlert} from 'rsuite';
import {Table} from 'rsuite'
import React from 'react';

const {Column, HeaderCell, Cell} = Table;

export const pipe = (data, filters, model) => {
    console.log(filters);
    console.log(model);
    // debugger;    
    if(!Object.keys(filters).length) return data;

    return  data.filter( x => {
        for( let f of Object.keys(filters)){
            if(!filters[f]) continue;
            if( !model[f](x,filters[f],filters) ) return false;
        }
        return true;
    })
};
/*
export const pipe2 = (data, filters, model) => {
    data =   data.filter( x => {
        let statement = false;
        for( let f of Object.keys(filters)){
            if( model[f](x,filters[f]) ) {
                statement = true;
            }
        }
        console.log(statement);
        return statement;
    })
    // console.log(data, 'i love chrome debugger')
    return data
};
*/

export const deleteEmpty = obj => {

    if(typeof(obj) != 'object') return obj;

    for(let k of Object.keys(obj)){
        if(!obj[k] && obj[k] !== false)
            delete obj[k];

        if(Array.isArray(obj[k]) && !obj[k].length)
            delete obj[k];
    }

    
    return obj;
}


const sortNumbers = (data, sortColumn, sortType) => {
    return data.sort((a, b) => {
        let x = getValueFromObjPath(a, sortColumn);
        let y = getValueFromObjPath (b, sortColumn);
            
        if (sortType === 'asc') {
            return x - y;
        } else {
            return y - x;
        }
    });
}
const sortString = (data, sortColumn, sortType) => {
    return data.sort((a, b) => {
        let x = getValueFromObjPath(a, sortColumn);
        let y = getValueFromObjPath (b, sortColumn);
        if (typeof x === 'string') {
          x = x.charCodeAt();
        }
        if (typeof y === 'string') {
          y = y.charCodeAt();
        }
        if (sortType === 'asc') {
          return x - y;
        } else {
          return y - x;
        }
      });
}

const getValueFromObjPath = (obj, str) => str.split('.').reduce((o,i)=>o[i], obj);

export const sortData = (data, sortColumn, sortType) => {
    return data.sort((a, b) => {
        const aVal = _.isString(a[sortColumn]) ? a[sortColumn].toLowerCase() : a[sortColumn];
        const bVal = _.isString(b[sortColumn]) ? b[sortColumn].toLowerCase() : b[sortColumn];
        const comparisonResult = aVal >= bVal ? 1 : -1;

        return sortType === 'asc' ? comparisonResult : - comparisonResult;
    });
};
export const ID =  () => '_' + Math.random().toString(36).substr(2, 9);


export const saveFileBlob = (response, name) => {
    const url = window.URL.createObjectURL(new Blob([response]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', name);
    document.body.appendChild(link);
    link.click();
};


export const saveFileJson = (objArray, name, headers) => {
    const array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    if (headers) {
        array.unshift(headers);
    }
    let str = '';
    for (let i = 0; i < array.length; i++) {
        let line = '';
        for (let index in array[i]) {
            if (line != '') line += ';'

            line += array[i][index];
        }

        str += line + '\r\n';
    }
    const exportedFilename = name + '.csv' || 'export.csv';

    const url = window.URL.createObjectURL(new Blob([str], { type: 'text/csv;charset=utf-8;' }));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', exportedFilename);
    document.body.appendChild(link);
    link.click();
};

export const copyToClipboard = (text) => {
    const temp = document.createElement('textarea');
    document.body.appendChild(temp);
    temp.value = text ;
    temp.select();
    document.execCommand("copy");
    temp.remove();
};

export const CRUDitems = (old_list, new_list) => {
    const jsonStringOldItems = old_list.map(
        item => JSON.stringify(item)
    );
    const jsonStringNewItems = new_list.map(
        item => JSON.stringify(item)
    );
    const newAndChangesItems = new_list.filter( item => !jsonStringOldItems.includes(JSON.stringify(item)));
    const newAndChangesItemsIds = newAndChangesItems.map(item => item.id);
    const deletedItems = jsonStringOldItems
        .filter( itemStringify => !jsonStringNewItems.includes(itemStringify) )
        .map( itemStringify => JSON.parse(itemStringify))
        .filter( item => !newAndChangesItemsIds.includes(item.id));

    return [ newAndChangesItems, deletedItems ];
};

export const getFirstValueByName = (list, name, desiredKey, defaultValue = null) => {
    const found = _.find(list, (item) => item.name === name);

    return found ? found[desiredKey] : defaultValue;
};

export const toUTCDateTime = (date) => {
    return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds()));
};

export const toStartDayUTCTime = (date) => {
    return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0));
};

export const toEndDayUTCTime = (date) => {
    return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59));
};

export const removeNilValues = (obj) => {
    const respObject = {...obj};

    Object.keys(respObject).forEach(key => {
        //Remove keys with Undefined or Null values
        if (_.isNil(respObject[key])) {
            delete respObject[key];
        }
    });

    return respObject;
};

export const preventMultipleExecution = _.debounce((f) => {f()}, 1000, {leading: true, trailing: false});

export const responseErrorToString = (error) => {
    let errorString = '';

    if (_.isObject(error.data) && !_.isEmpty(error.data)) {
        _.each(error.data, (errMessage, fieldKey) => {
           errorString += `${fieldKey}: ${errMessage}${EOL}`;
        });
    } else {
        errorString = error.message;
    }

    return errorString;
};

export const renderColumn = ({label, dataKey, value = null, width = 200, ...props}) => (
    <Column width={width} {...props}>
        <HeaderCell>{label}</HeaderCell>
        <Cell dataKey={dataKey}>{value}</Cell>
    </Column>
);

export const hasError = (error) => {
    return error && Object.keys(error).map(i => error[i]).some(value => value === true);
};

export const isEmptyObj = (data) => {
    return Object.keys(data).length === 0 || Object.values(data).some(value => (value === null || value === ''));
};

export function canIMoveNumbersToAnotherTrunk(fromTrunk, toTrunk) {
    return fromTrunk.id !== toTrunk.id && !toTrunk.closed && fromTrunk.sp_key === toTrunk.sp_key
}

export const replaceUndefinedOrNull = (key, value) => {
    if (value === null || value === undefined) {
        return undefined;
    }

    return value;
};