import {Notification} from "rsuite";

export default (title='', description='', duration=3000) => {
    Notification.open({
        title,
        duration,
        description
    });
}