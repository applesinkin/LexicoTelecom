import React from 'react';
import {IconButton, Icon} from 'rsuite';

export default (props) =>(
    <IconButton
        appearance = "primary"
        icon = {<Icon icon="edit"/>}
        size = "xs"
        style = {{
            ...(props && props.style ? props.style : {}),
            marginRight: '15px',
            background:'#1E90FF'
        }}
        {...props}
    />
)