import React from 'react';
import {IconButton, Icon} from 'rsuite';

const style = {
    marginRight: '15px', 
    background:'#fff',
    color: '#000',
    border: '2px solid #20BA88',
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: '14px',
    lineHeight: '24px',
    borderRadius: '120%',
    width: '24px',
    textAlign: 'center'
}

const styleIcon = {
    lineHeight: '17px',
    fontSize: '10px'
}

export default (props) => (
    <IconButton  appearance="primary" {...props} icon={<Icon icon="plus" style={styleIcon} />}  size="xs"  style={style}/>
)