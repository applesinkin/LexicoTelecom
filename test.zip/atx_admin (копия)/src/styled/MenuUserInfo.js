import styled from 'styled-components';

export default styled.li`
    display: inline-block
    padding: 19px 16px;
    height: 56px;
    font-size: 13px;
    color: #fff;
`;
