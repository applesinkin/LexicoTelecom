import styled from 'styled-components';

export default styled.div`
    position: absolute;
    left: 4px;
    top: 4px;
    font-size: 8px;
    // padding: 18px 16px;
    // height: 56px;
`;
