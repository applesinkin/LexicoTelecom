import styled from 'styled-components';

export default styled.h1`
    font-family: Roboto;
    font-style: normal;
    font-weight: 500;
    font-size: 18px;
    line-height: 21px;
    color: #8256C8;
    padding: 15px 0px;
    div {
        display: inline-block;
        width: 50%;
    }
    div:last-child{
        text-align: right
    }
`;
