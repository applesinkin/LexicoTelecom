import React from 'react';
import styled from 'styled-components';
import { Button } from 'rsuite';
const GreenButton = styled.div`
    display: inline-block;
    padding: 0;
    button {
        background: #20BA88;
        color: #fff;
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.16);
        padding: 12px 34px;
        border-radius: 5px;
    }
    button:disabled {
        color: #fff;
        background: #939191;
        box-shadow: 0 4px 4px rgba(0, 0, 0, 0.16);
        opacity: 0.3;
    }
    button:disabled:hover {
        color: #fff;
        opacity: 0.45;
        background: #939191;
    }
    button:active, button:hover, button:focus{
        background: #20CA88 !important;
        color: #fff;
    }
`;

export default ({children,...props}) => (
    <GreenButton>
        <Button {...props}>{children}</Button>
    </GreenButton>
)

