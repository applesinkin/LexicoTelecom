import React from 'react';
import {IconButton, Icon} from 'rsuite';

export default (props) =>(
<IconButton  appearance="primary" {...props} icon={<Icon icon="list" />}  size="xs"  style={{marginRight: '15px', background:'#1E90FF'}}/>
)