import React from 'react';
import {IconButton, Icon} from 'rsuite';

export default (props) =>(
    <IconButton
        appearance = "primary"
        icon = {<Icon icon="trash" />}
        size = "xs"
        style = {{
            ...(props && props.style ? props.style : {}),
            marginRight: '15px',
            background:'rgb(248, 67, 47)'
        }}
        {...props}
    />
)