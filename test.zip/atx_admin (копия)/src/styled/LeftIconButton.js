import React from 'react';
import styled from 'styled-components';
import { Button, Icon } from 'rsuite';
const ButtonCss = styled.div`
    display: inline-block;
    padding: 0  10px;
    button {
        background: transparent;
        color: #363434;
        padding: 3px 8px;
        border: 2px solid #20BA88;
        position: relative;
        padding-left: 35px;
        i {
            position: absolute;
            background: #20BA88;
            top: 0;
            left: 0;
            color: #fff;
            // padding: -5px;
            width: 26px;
            height: 30px;
            display: inline-block;
            line-height: 30px;
        }
        // box-shadow: 0px 4px 30px rgba(0, 0, 0, 0.16);      
    }
`;

export default ({children,icon,...props}) => (
    <ButtonCss>
        <Button {...props}>
            <Icon icon={icon}  /> 
            {children}
        </Button>
    </ButtonCss>
)

