import React from 'react';
import styled from 'styled-components';

export const Vdivider = styled.div`
    background: #C4C4C4;
    width: 3px;
    height: 100%;
`;

