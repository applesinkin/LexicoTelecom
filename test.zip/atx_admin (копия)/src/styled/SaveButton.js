import React from 'react';
import styled from 'styled-components';
import { Button } from 'rsuite';
const ButtonCss = styled.div`
    display: inline-block;
    padding: 0  15px;
    button {
        background: #20BA88;
        color: #fff;
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.16);
        padding: 12px 34px;
        border-radius: 5px;
    }
    button:disabled {
        color: #fff;
        background: #939191;
        box-shadow: 0 4px 4px rgba(0, 0, 0, 0.16);
        opacity: 0.3;
    } 
`;

export default ({children,...props}) => (
    <ButtonCss>
        <Button {...props}>{children}</Button>
    </ButtonCss>
)

