import styled from 'styled-components';

export default styled.div`
    margin-top: 10px;
    background: #FFFFFF;
    box-shadow: 0px 4px 30px rgba(0, 0, 0, 0.16);
    border-radius: 5px;
    padding: 10px;
    min-height: 80vh;
`;
