import React  from 'react';
import {IconButton, Icon, Button} from 'rsuite';
import styled from 'styled-components';

export const EditTd = (props) => (
    <IconButton
        {...props}  
        appearance="primary"  
        icon={<Icon icon="edit" />}  
        size="xs"  
        style={{marginRight: '15px', background:'#1E90FF'}}
    />
);

export const DeleteTd = (props) => (
    <IconButton
        {...props}
        appearance="primary"  
        icon={<Icon icon="trash" />}  size="xs"  
        style={{marginRight: '15px', background:'#F8432F'}}
    />
);

export const RevokeTd = (props) => (
    <Button
        {...props}
        appearance="primary"
        size="xs"
        style={{marginRight: '15px', background:'#20BA88'}}
    ><b>R</b></Button>
);

export const AllocateTd = (props) => (
    <Button
        {...props}
        appearance="primary"
        size="xs"
        style={{marginRight: '15px', background:'#20BA88'}}
    ><b>A</b></Button>
);

export const DownloadTd = (props) => (
    <IconButton {...props} 
        appearance="primary"  
        icon={<Icon icon="cloud-download" />}  
        size="xs"
        style={{marginRight: '15px', background:'#20BA88'}}
    />
)

const sizes = {
    sm: '6px 12px',
    esm: '2px 14px'
}


const ButtonBox = styled.div`
    display: inline-block;
    padding: 0px;
 
    button {
        background: ${props => props.bg || "#8256c8"};
        border: ${props => props.border || "none"};
        color: ${props => props.color || "#fff"}; 
        box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.16);
        padding: ${props => sizes[props.size] || "12px 34px"};
        border-radius: 5px;
    }
`;

export const AddButton  = ({children, size, ...props}) => (
    <ButtonBox bg="#20BA88" size={size}>
        <Button {...props}  >{children}</Button>
    </ButtonBox>
)

export const CancelButton  = ({children, size, ...props}) => (
    <ButtonBox bg="#939191" size={size}>
        <Button {...props}  >{children}</Button>
    </ButtonBox>
)

export const RedBtn  = ({children, size, ...props}) => (
    <ButtonBox bg="#F8432F" size={size}>
        <Button {...props}  >{children}</Button>
    </ButtonBox>
)

export const BorderBtn = ({children, size, ...props}) => (
    <ButtonBox bg="#fff" border="2px solid #20BA88" color="#363434"  size={size}>
        <Button {...props}  >{children}</Button>
    </ButtonBox>
);
export const ButtonGroup = styled.div`
    button{
        margin-left: 5px;
        margin-right: 5px;
    }
`;

