import styled from 'styled-components';

export default styled.h1`
    font-family: Roboto;
    font-style: normal;
    font-weight: 500;
    font-size: 22px;
    line-height: 26px;
    /* identical to box height */

    text-align: center;

    /* Grey */

    color: #363434;
    display: inline-block;
`;
