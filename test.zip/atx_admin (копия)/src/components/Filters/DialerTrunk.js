import React from 'react';
import {connect} from 'react-redux';
import {SelectPicker, Form, Schema} from 'rsuite';
import CustomField from '../Form/CustomField';

const {StringType} = Schema.Types;

const model = Schema.Model({
    trunk_id: StringType().isRequired('Required')
});


const DialerTrunkList = ({dialerTrunkList, disabledTrunk,  trunk_id, updateRef, onChange}) => (
    <Form
        formDefaultValue={{trunk_id}}
        style={{marginBottom: 10}}
        model={model}
        ref={ref => updateRef ? updateRef(ref) : null}
    >
        <CustomField
            block
            data={dialerTrunkList}
            accepter={SelectPicker}
            labelKey="_name"
            valueKey="trunk_id"
            label="Dialer/Trunk"
            name="trunk_id"
            disabled={disabledTrunk}
            errorPlacement="topRight"
            onChange={(id) => onChange ? onChange(dialerTrunkList.find(trunk => trunk.trunk_id === id)) : onChange}
        />
    </Form>
)

const mapState = ({references}) => ({
    dialerTrunkList: references.dialerTrunkList
});

export default connect(mapState, {})(DialerTrunkList);