import React from 'react';
import {Route} from "react-router-dom";
import Layout from "../Layout";

const RouteWithLayout = ({layout = Layout, component: Component, ...rest}) => {
    if (Component) {
        return (
            <Route {...rest} render = {(props) =>
                React.createElement(layout, props, React.createElement(Component, props))
            }/>
        );
    }

    return (
        <Layout>
            <Route {...rest}>
                {rest.children}
            </Route>
        </Layout>
    );
};

export default RouteWithLayout;