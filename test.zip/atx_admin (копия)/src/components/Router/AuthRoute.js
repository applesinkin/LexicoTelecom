import React from 'react';
import RouteWithLayout from "./RouteWithLayout";
import {connect} from "react-redux";
import {Route, Redirect} from "react-router-dom";
import {DEFAULT_NOT_AUTH_PATH} from "../../const";

const AuthRoute = ({auth, ...props}) => {
    if (!auth) {
        return <Redirect to={DEFAULT_NOT_AUTH_PATH} />;
    }

    return <RouteWithLayout {...props} />
};

const mapState = ({auth})=> ({
    auth: auth.auth
});

export default connect(mapState)(AuthRoute);