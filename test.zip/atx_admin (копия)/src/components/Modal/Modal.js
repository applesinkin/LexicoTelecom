import React from 'react';
import {Modal as RsuiteModal, Button} from 'rsuite';
import {AddButton,CancelButton} from '../../styled/Buttons';

export const Modal = ({show, onClose, onSuccess,checkBefore, children, title, width, disabled, footer = false, successText = "Ok", extraDisabled = false}) => {

    const style = {};
    width &&  (style.width = width);
    return (
        <RsuiteModal show={show} onHide={onClose} style={style}>
            <RsuiteModal.Header>
                <RsuiteModal.Title>{title}</RsuiteModal.Title>
            </RsuiteModal.Header>
            <RsuiteModal.Body>
                {children}
            </RsuiteModal.Body>
            { footer && 
            <RsuiteModal.Footer style={{display: 'flex',justifyContent: 'space-around'}}>
                <AddButton loading={disabled} disabled={extraDisabled} onClick={() => {
                    if(checkBefore && !checkBefore()) return false;
                    onSuccess()
                }} >
                    {successText}
                </AddButton>
                <CancelButton onClick={onClose} disabled={disabled}>
                    Cancel
                </CancelButton>
            </RsuiteModal.Footer>
            }
        </RsuiteModal>
    );
};
export default Modal;