import React, {useState} from 'react';
import {Form, Schema, Alert} from 'rsuite';
import {api} from '../../api/loginRoutes';
import {responseErrorToString, splitList} from '../../utils';
const { StringType, NumberType } = Schema.Types;

const validationKeys = {
    name:   StringType().isRequired('Required').maxLength(40, 'The maximum is only 40 characters.'),
    str:    StringType().isRequired('Required').maxLength(40, 'The maximum is only 40 characters.'),
    str30:  StringType().isRequired('Required').maxLength(30, 'The maximum is only 30 characters.'),
    rate:   NumberType().isRequired('Required'),
    str_required: StringType().isRequired('Required'),
    num_required: NumberType().isRequired('Required'),
    number_list: StringType()
        .isRequired('Required')
        .pattern(/^(?: *\d+ *(?:\n|$))+$/, 'Please enter a valid numbers')
        .addRule((value) => {
            const valueList = splitList(value);
            for (const row of valueList) {
                if (row.length > 15 || row.length < 7) {
                    return false
                }
            }
            return true;
        }, 'Each row should be greater than 7 and less than 15')
        .addRule((value) => !(splitList(value).length > 100),
            'The number of entered telephone numbers exceeds 100 rows'),
    numbers: NumberType().isRequired('Required').isInteger('Only whole numbers'),
    ranges: NumberType().isRequired('Required').isInteger('Only whole numbers'),
    in_template_list_range: StringType()
        .addRule((value) => {
            const valueList = value.trim()
                .replace( /\r?\n/g, ' ')
                .split(' ').filter( s => s !== "")
            for (const row of valueList) {
                if (row.length > 15 || row.length < 7) {
                    return false
                }
            }
            return true
        }, 'Each row should be greater than 7 and less than 15')
        .addRule((value) => {
            const valueList = value.trim()
                .replace( /\r?\n/g, ' ')
                .split(' ').filter( s => s !== "")
            return !((valueList).length > 100)
        }, 'The number of entered telephone numbers exceeds 100 rows')
        .pattern(/^(?: *[0-9]{6,14} *(?:[X]{3,6}\r|[X]{3,6}\n|[X]{3,6}$))+$/, 'Please enter a valid numbers')
        .isRequired('This field is required'),
    in_template_range: StringType()
        .addRule((value) => {
            if (value.length > 15 || value.length < 7) {
                return false
            }
        }, 'Template should be greater than 7 and less than 15')
        .pattern(/^(?: *[0-9]{6,14} *([X]{1,6}$))$/, 'Please enter a valid numbers')
        .isRequired('This field is required'),
};

export const MyForm = (_props) => {
    const {
        disabled, children, update, method, checkResultKey, noCheck, noSend, addData = {}, updateRef, target,
        formValue = {}, formDefaultValue = {}, model, unsendFields,
        ...props
    } = _props;

    const childrenModel = {};
    const fieldsValues = {...formDefaultValue, ...formValue};


    /**
     * Вместо проверки isArray Лучше использовать уже готовый метод React.Children.map
     * Удалил лишние If'ы
     */

    const _children = React.Children.map(children, (formControl) => {
        const { props } = formControl || {};
        const { name, validationKey } = props || {};

        if (name) {
            if (validationKeys[validationKey]) {
                childrenModel[name] = validationKeys[validationKey];
            } else if (validationKeys[name]) {
                childrenModel[name] = validationKeys[name];
            }
        }

        return React.isValidElement(formControl) ? React.cloneElement(formControl, {disabled}) : formControl;
    });

    const [_formValue, setFormValue] = useState(fieldsValues);

    const modelData =  Schema.Model({
        ...childrenModel,
        ...model
    });
  
    const getFormValue = (form) => () => {
        let data = form.getFormValue();
        // После удаления значения в SelectPicker, значение заменяется на null, но после повторной отправки формы
        // значение превращается из null в 0, что не даёт валидации повторно вывести ошибку Required
        const sde_key = data.sde_key !== 0 ? data.sde_key : null;

        data = {...data, sde_key};
        // console.log(data)
        Object.keys(data).map( key => {
            const type = form.props.model.getFieldType(key);

            //console.log(key, type);
            if(type.name === "number"){
                data[key] = +data[key];
            }

            //Remove unused fields from data
            if (unsendFields && unsendFields.includes(key)) {
                delete data[key];
            }
        });

        return data;
    };

    const send = (form) => () => {
        if (!form) return;

        return new Promise( async(resolve, reject) => {

            if (noSend) return resolve(true);

            const data = getFormValue(form)();

            // Во многих формах, где есть возможность выбора метода используется одна и та же форма. Поля которые расчитаны
            // на один метод, при выборе другого очищаются, но в данных на отправку запроса остаётся ключ с нуловым значением.
            // Некоторые запросы валятся с валидацией, когда они не ожидают лишних ключей.
            Object.keys(data).forEach(key => (data[key] == null || data[key] === "") && delete data[key]);

            if(form.check()){
                try {
                    const result = await api(method,{
                        target,
                        ...data,
                        ...addData,
                        undefined: undefined
                    }, true);

                    if( result && (
                        noCheck
                        ||
                        (Object.keys(result).length && ( (checkResultKey && result[checkResultKey]) || true))
                    ) ) {
                        update && update(result);
                        return resolve(true);
                    }
                } catch (e) {
                    Alert.error(responseErrorToString(e.response.data.error), 5000);

                    resolve(false);
                }

            }

            return resolve(false);
        });
    };

    return (
        <Form
            {...props}
            formDefaultValue={formDefaultValue}
            formValue={{...formDefaultValue, ..._formValue}}
            onChange={(values) => {
                if (props.onChange) props.onChange(values);

                setFormValue(values);
            }}
            ref = { ref => updateRef({...ref, getFormValue: getFormValue(ref), send: send(ref)})}
            layout = "inline"
            model = {modelData}
         >
            {_children}
        </Form>
    );
};

export default MyForm;