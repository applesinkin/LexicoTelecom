import React, {useState} from 'react';
import { Modal, Button, ButtonGroup } from 'rsuite';
import './colors.css';
const styleColor = {
    height: '24px',
    width: '24px',
    display: 'inline-block',
    margin: '9px',    
    cursor: 'pointer',
    border: '3px solid #fff',
    borderRadius: '12px',
}

const colors = ['#1976d2' , '#26c6da', '#673ab7', '#e91e63', '#f44336', '#00bcd4', '#ff8f00' ]

const ColorSetting = ({color, setColor, showModalColor, show}) =>  {
    

    const [_color, _setColor] =  useState(color);
    
    const onClick = ()  => setColor(_color);
    const onChange = (e) => _setColor(e.target.value);
    const setDefault = () =>_setColor('#3498ff');
    const setColorStandard = (color) => _setColor(color);
    
    return (
        <>
        <style dangerouslySetInnerHTML={{__html:`:root {--main-bg: ${color};}`} } />
        <Modal show={show} onHide={() => showModalColor(false)}>
            <Modal.Header>
            <Modal.Title>Modal Title</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div>
                    { colors.map( c => <span onClick={()=>setColorStandard(c)} style={{...styleColor, background:c , boxShadow: c === _color  ? '0 0 10px 3px #03a9f4' : ''}}></span>)}
                </div>
                {/* <div>
                    <input  type="color" value={_color} onChange={onChange} />  Your variant
                </div> */}
                <Button onClick={setDefault} >Default</Button>
            </Modal.Body>
            <Modal.Footer>
            <Button  onClick={onClick}  appearance="primary">
                Ok
            </Button>
            <Button  onClick={() => showModalColor(false)} appearance="subtle">
                Cancel
            </Button>
            </Modal.Footer>
        </Modal>  
        </>
        );
 
}
    
export default ColorSetting;