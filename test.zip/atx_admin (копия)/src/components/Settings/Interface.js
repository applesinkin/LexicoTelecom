import React from 'react';
import { Modal, Button, ButtonGroup } from 'rsuite';
import interface2 from '../../img/interface2.png';
import interface1 from '../../img/interface1.png';
import { runInThisContext } from 'vm';


const styleImg = {
    maxWidth:"90%",
    margin: "0 auto"
}

export default class Interface extends React.Component {
    state = {
        sidebar: this.props.sidebar || false
    }

    onClick = (sidebar) =>{
        this.setState({sidebar})
    }

    setSidebar = () => {
        this.props.setSidebar(this.state.sidebar)
    }

    render () {
        const {showModalInterface, show} = this.props;
        const { sidebar } = this.state;

        return (
            <Modal show={show} onHide={() => showModalInterface(false)}>
                <Modal.Header>
                <Modal.Title>Modal Title</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div style={{textAlign:'center'}}>
                        <img src={ sidebar ? interface1 : interface2}  style={styleImg}/>
                    </div>
                    <ButtonGroup style={{marginTop:12}} justified>
                        <Button onClick={() => this.onClick(false)} appearance={ !sidebar ? 'primary' : "ghost"}>Header Menu</Button>
                        <Button onClick={() => this.onClick(true)} appearance={ sidebar ? 'primary' : "ghost"} >Sidebar</Button>        
                    </ButtonGroup>
                </Modal.Body>
                <Modal.Footer>
                <Button  onClick={this.setSidebar}  appearance="primary">
                    Ok
                </Button>
                <Button  onClick={() => showModalInterface(false)} appearance="subtle">
                    Cancel
                </Button>
                </Modal.Footer>
            </Modal>  
            )
        };
}
    