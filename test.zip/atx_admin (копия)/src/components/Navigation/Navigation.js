import React, {useState, memo, useEffect} from 'react';
import {Badge, Dropdown, Icon, Nav} from 'rsuite';
import SUser from '../../styled/MenuUserInfo';
import {withRouter} from 'react-router';
import {Link} from 'react-router-dom';
import {ACCOUNT_USER_MODIFY_BY_SELF} from '../../const/apiMethods';
import {USER_INFO} from '../../const/localStorageKeys';
import ModalEditProfile from 'components/EditProfile/ModalEditProfile';
import {checkPermissionsFor} from 'store/storeHelpers';
import {connect} from 'react-redux';
import {
    modifyAccountRequest,
    modifyPasswordRequest,
    openAllocationModal,
    showModalColor,
    showModalInterface
} from 'actions';
import {unLogin} from 'actions/auth';

const Navigation = ({onClickInrerface, onClickColor, openAllocationModal, unLogin, history, location, updatedInfo, ...props}) => {
    const [showEditProfileModal, onChangeShowEditProfileModal] = useState(false);

    const {modifyPasswordRequest, modifyAccountRequest} = props;

    const user = localStorage.getItem(USER_INFO);
    const savedUser = user && JSON.parse(user);
    const userInfo = updatedInfo || savedUser || {};

    const {name} = userInfo;

    return (
        <Nav panel={true} appearance="subtle">
            <Badge style={{
                background: '#00ffa1',
                width: '4px',
                height: '4px',
                position: 'absolute',
                top: '2px',
                left: '2px',
                zIndex: 10
            }}/>
            <div
                style={{
                    position: 'absolute',
                    top: '2px',
                    left: '8px',
                    fontSize: '8px',
                    zIndex: 10,
                    color: 'white'
                }}
            >
                {savedUser.account_name}
            </div>

            {
                checkPermissionsFor(ACCOUNT_USER_MODIFY_BY_SELF) ?
                    <Dropdown
                        className={'custom-dropdown-menu'}
                        toggleClassName={'custom-dropdown-menu-toggle'}
                        menuStyle={{borderTopLeftRadius: 0, borderTopRightRadius: 0}}
                        style={{
                            width: '100%',
                            height: '100%',
                            marginTop: '0px',
                            marginLeft: '0px',
                            marginRight: '24px',
                            maxWidth: '140px',
                        }}
                        title={<span style={{
                            wordWrap: 'break-word',
                            whiteSpace: 'normal',
                            maxWidth: '140px',
                            minWidth: '140px',
                            float: 'left',
                            textAlign: 'left',
                            display: 'inline-block'
                        }}>{name}</span>}>
                        <Dropdown.Item
                            onSelect={() => onChangeShowEditProfileModal(true)}
                        >
                            <Icon icon="edit2"/>
                            Edit profile
                        </Dropdown.Item>
                    </Dropdown>
                : <SUser> {name} </SUser>
            }
            <ModalEditProfile
                show={showEditProfileModal}
                onClose={()=>onChangeShowEditProfileModal(false)}
                {...{updatedInfo, modifyAccountRequest, modifyPasswordRequest, userInfo}}
            />

            {/* <NavLink icon={<Icon icon="home" />} href="/" >Dashboard</NavLink> */}
            <NavLink to="/accounts">Accounts</NavLink>
            <NavLink to="/prices">Prices</NavLink>
            <NavLink to="/access-list">Access list</NavLink>
            <NavLink to="/cdr">CDR</NavLink>
            <NavLink to="/traffic-reports">Traffic Reports</NavLink>
            {/* <NavLink>Traffic report</NavLink> */}
            <NavLink to="/live-calls">Live calls</NavLink>
            {/* <NavLink>Notifications</NavLink> */}
            <NavLink onClick={openAllocationModal}>Number allocation</NavLink>
            <NavLink to="/ranges-numbers">Ranges & numbers</NavLink>
            <NavLink to="/auth-numbers">Auth Numbers</NavLink>
            <NavLink style={{float: 'right'}} icon={<Icon icon="sign-out"/>} onClick={unLogin}>Log out</NavLink>
            {/*<Dropdown  style={{float:'right'}} title="Settings" icon={<Icon icon="cog" />}>*/}
            {/*    <Dropdown.Item eventKey="4" onClick={onClickInrerface}  >Interface</Dropdown.Item>*/}
            {/*    <Dropdown.Item eventKey="5" onClick={onClickColor} >Colors</Dropdown.Item>*/}
            {/*</Dropdown>*/}
        </Nav>
    )
};

const mapState = ( {auth} )=> ({
    permissions: auth.permissions,
    updatedInfo: auth.updatedInfo
});

const NavLink = withRouter(props => (
    <Nav.Item componentClass={Link}
              active={props.location.pathname.indexOf(props.to) === 0}
              {...props}
    />)
);

export default withRouter(connect(mapState)(Navigation));