import React, {useRef, useState} from 'react';
import css from './CheckboxBadge.module.css';
import {Checkbox, Icon} from 'rsuite';

const CheckboxBadge = ({children, ...props}) => {
    const {checked} = props;

    return (
        <div className={[css.CheckboxBadge, checked ? css.checked : '', props.wrapperClassName].join(' ')} onClick={(e) => {
            props.onChange(props.value, !checked, e);
        }}>
            <Icon icon={checked ? 'check' : 'plus'} className={'mr-1'}/>
            {children}
            <Checkbox {...props} checked={checked}/>
        </div>
    );
};

CheckboxBadge.displayName = 'Checkbox';

export default CheckboxBadge;