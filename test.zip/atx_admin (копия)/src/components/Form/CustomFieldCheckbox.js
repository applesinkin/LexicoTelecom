import React from 'react';
import {FormGroup,  Checkbox , FormControl, ControlLabel, HelpBlock} from 'rsuite'

export default class  extends React.PureComponent {
    render() {
      const { name, message, label, accepter, error, ...props } = this.props;
      return (
        <FormGroup>
          <FormControl
            name={name}
            accepter={accepter}
            errorMessage={error}
            onChange = {(value, checked) => console.log(checked)} 
          />
         </FormGroup>
      );
    }
  }