import React, {useState} from 'react';
import CustomField from './CustomField';
import {InputNumber} from 'rsuite';

export const NumberField = ({onChange, ...props}) => {
    const [value, setValue] = React.useState(props.value);

    return (
        <CustomField
            accepter={InputNumber}
            size="sm"
            style={{width: 135}}
            placeholder="0"
            value = {value}
            max={100000}
            onChange = {(v) => {
                if(onChange) onChange(v);
                setValue(v);
            }}
            {...props}
        />
)};

export default NumberField;















