import React from 'react';
import LeftIcon from '../styled/LeftIconButton';
import { getFileResponse } from '../api/loginRoutes';
import { saveFileBlob } from '../utils/helpers';


export default ({ method, params, title, fileName, ...props}) => {
    const [loading, setLoading] = React.useState(false)
    
    const exportFile = async () => {
        setLoading(true);
        const result = await getFileResponse(method,params)
        if(result)
            saveFileBlob(result,fileName)
        setLoading(false)

    }

    return (
        <LeftIcon 
            onClick={() => exportFile()} 
            loading = {loading} 
            icon = "upload2"
            {...props}     
        >{title}</LeftIcon>
    )
};