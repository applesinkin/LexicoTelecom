import React from 'react';
import Pagination from '../../components/Pagination';
import {Button, ButtonToolbar, Checkbox, Notification, Table} from 'rsuite';
import RenderedColumns from './RenderColumns';
import {ObjectSet} from '../../utils/ObjectSet';
import css from './Table.module.css';
import ShowColumnPicker from "components/Table/ShowColumnPicker";
import _ from 'lodash';

const { Column, HeaderCell, Cell } = Table;

/**
 * Для правильной работы выбора колонок в таблицу нужно передать columnSelectorLSKey
 * это и будет являться ключём для храрения выбраных колонок в LocalStorage
 */
export class MyTable extends React.Component{
    selectedlist =  this.props.isSetObject ? new ObjectSet() :  new Set();

    constructor(props) {
        super(props);

        const allColumnsKeys = props.columns.map(column => column.dataKey);
        let columnsKeys = props.columns.filter(column => !column.hideDefault).map(column => column.dataKey);

        if (props.columnSelectorLSKey) {
            //Get saved columns to show from Local Storage
            columnsKeys = localStorage.getItem(props.columnSelectorLSKey) ?
                JSON.parse(localStorage.getItem(props.columnSelectorLSKey)) : columnsKeys;
        }

        this.state = {
            selectAll: false,
            columns: [],
            isSelectColumnsDropdownOpen: false,
            showColumnsKeys: columnsKeys || allColumnsKeys,
        };
    }

    configureColumns () {
        let columns = [...this.props.columns];
        const showColumnsKeys = this.state.showColumnsKeys;
        const {columnSelectorLSKey} = this.props;

        if (columnSelectorLSKey) {
            //Set saved
            localStorage.setItem(columnSelectorLSKey, JSON.stringify(showColumnsKeys));

            columns = columns.filter((column) => showColumnsKeys.includes(column.dataKey));

            if (columns.length) {
                columns[0].headerProps = {className:`${css.columnHeaderWithIcon}`};
            }
        }

        this.setState({columns});
    }

    clear = () => {
        const { isselected } = this.props;
        const {selectAll } = this.state; 
        if(isselected) {
            this.selectedlist.clear();
            if(selectAll)
                this.setState({selectAll},this.setSelectParent)
            else
                this.setSelectParent()
            
        }
    };

    shouldComponentUpdate({ data, stateChecked, row_key = 'id' }){
        if(stateChecked && data !== this.props.data){
            data.map(
                row => (row.checked) && (this.selectedlist.add(this.gettingSelectItem(row)))
            )
        }

        return true;
    }

    componentDidMount() {
        this.configureColumns();
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        //Uncheck checkboxes when data in table changes
        if (this.props.count && prevProps.count !== this.props.count) {
            this.onToggleAll(false);
        }

        if (this.props.columns !== prevProps.columns
            || this.state.showColumnsKeys !== prevState.showColumnsKeys) {
            this.configureColumns();
        }
    }

    onChangePage = (page) => {
        this.props.getItems(page, this.props.per_page)
    };

    onChangePerPage = (per_page) => {
        this.props.getItems(1, per_page)
    };

    setSelectParent = () => {
        const {setSelected} = this.props;
        const {selectAll} = this.state;

        if (!setSelected) return;

        setSelected({
            list: Array.from(this.selectedlist.values()),
            all: selectAll
        })  
    };

    onToggle = (id, checked) => {
        if(checked)
            this.selectedlist.add(id);
        else
            this.selectedlist.delete(id);

        this.setSelectParent();
        this.forceUpdate();
    };

    onToggleAll = (checked) => {
        const {selectAll} = this.state;
        const {data, row_key = 'id', ispagination, isSelectedAll} = this.props;

        if (!checked) {
            speaker(Notification.closeAll());
        }

        if (isSelectedAll && checked && !selectAll && ispagination)
            Notification.open({
                duration: 0,
                description: [
                    <div className="mb-2">Do you want to choose records on all pages according to clause of
                        filter?</div>,
                    <div className="text-right">{
                        speaker(
                            () => {
                                this.setState({selectAll: true}, this.setSelectParent);
                                Notification.closeAll();
                            },
                            () => {
                                Notification.closeAll();
                            })
                    }</div>
                ],
                key: 'allocatedNumberChooser'
            });
        else if (!checked && selectAll)
            this.setState({selectAll: false}, this.setSelectParent);



        for (let row of data) {
            checked 
            ? 
            this.selectedlist.add(this.gettingSelectItem(row)) 
            : 
            this.selectedlist.delete(this.gettingSelectItem(row))
        }
        
        this.setSelectParent();
        this.forceUpdate();
    };

    getHeight = () => {
        const { data = [],height}  = this.props;
        const heightValues = ((data.length * 30) || 100) + 50;

        switch (height) {
            case '50%':
                const h = (window.innerHeight/2);
                return Math.min(h,heightValues);
            case '30%':
                const h30 = (window.innerHeight/3);
                return Math.min(h30,heightValues);
            case '25%':
                const h25 = (window.innerHeight/4);
                return Math.min(h25,heightValues);
            default:
                return heightValues;
        }
    };

    gettingSelectItem = (row) => {
        const { isSetObject, row_key = 'id' } = this.props;
        return isSetObject ? row : row[row_key];
    };

    render () {
        const {
                data = [], loading, isselected, row_key = 'id', active_id,
                ispagination, count, page, per_page, onRowClick,
                width, ActionCell, hidePerPage, disabled, columns, getItems, height, ...props
            } = this.props;

        const {selectAll} = this.state;
        const _columns = RenderedColumns(this.state.columns);

        const propTables = {...props};

        if (onRowClick)
            propTables.onRowClick = (row) => onRowClick(row[row_key]); 
        if (active_id) {
            propTables.rowClassName = (row) => {
                let rowClass = row && row[row_key] === active_id ? 'active--row' : null;

                if (!rowClass && props.rowClassName) {
                    rowClass = _.isFunction(props.rowClassName) ? props.rowClassName(row) : props.rowClassName;
                }

                return rowClass;
            }
        }

        (width) && (propTables.width = width);
        (!ispagination) && (propTables.virtualized = true);


        return  (
            <div className="position-relative">
                {this.props.columnSelectorLSKey &&
                    <ShowColumnPicker
                        value={this.state.showColumnsKeys}
                        columns={this.props.columns}
                        onChange={(value) => this.setState({showColumnsKeys: value})}
                    />
                }
                <Table
                    height={ this.getHeight()}
                    data={data}
                    loading={loading}
                    rowHeight={30}
                    {...propTables}
                    >
                        {_columns}
                        {ActionCell}
                        {isselected &&
                            <Column width={50}>
                                <HeaderCell>
                                    {data.length ?
                                        <Checkbox
                                            onChange={(v,checked) =>  this.onToggleAll(checked)}
                                            checked = {selectAll || data.every(
                                                row => this.selectedlist.has(this.gettingSelectItem(row))
                                            ) }
                                            style={{position:'relative', top:'-5px'}} />
                                        :
                                        ''
                                     }
                                </HeaderCell>
                                <Cell>
                                    {(row) => <Checkbox
                                                disabled = {selectAll}
                                                checked = { row.checked || this.selectedlist.has(this.gettingSelectItem(row)) || selectAll}
                                                onChange={(v,checked) => this.onToggle(this.gettingSelectItem(row),checked)}
                                                style={{position:'relative', top:'-5px'}} />}
                                </Cell>
                            </Column>
                        }
                </Table>
                { ispagination &&
                    <Pagination
                        disabled = {disabled}
                        total = {count}
                        per_page = {per_page}
                        activePage = {page}
                        hidePerPage = {hidePerPage}
                        onChangePage = {this.onChangePage}
                        onChangePerPage  = {this.onChangePerPage}
                    />
                }
            </div>
        );
             
    }
}


export default MyTable;

const speaker = (Ok,No) =>  (
    <div>
        <ButtonToolbar>
          <Button onClick ={Ok}>Yes</Button>
          <Button onClick ={No} >No, only on this page</Button>
        </ButtonToolbar>
      </div>
);