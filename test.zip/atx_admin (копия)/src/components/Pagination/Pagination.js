import React from 'react';
import { Pagination, Schema, Form , InputNumber} from 'rsuite';

import CustomField from '../Form/CustomField';
import {DEFAULT_PER_PAGE_MEDIUM} from "../../const";

const { NumberType } = Schema.Types;

const perPageModel = Schema.Model({
    per_page: NumberType().isInteger('Integer').isRequired('Required').min(1,'Minimum 1').max(10000,'Maximum 10000'),
});

const styleForm = {
    display:'inline-block',
    position: 'relative',
    top: '-12px'
}

export default ({total=0, per_page = DEFAULT_PER_PAGE_MEDIUM, hidePerPage, activePage = 1 , onChangePage, onChangePerPage, disabled = false}) =>{
return (
        <div>
            <Pagination  size="xs" 
                maxButtons={5}
                pages={Math.ceil(total/per_page)} 
                activePage={activePage} 
                onSelect={onChangePage}
                disabled={disabled || total === 0}
                first last />   
                { !hidePerPage && 
                    <Form layout="inline"
                            onChange={({per_page:_ = 0}) => _ ?  onChangePerPage(+_) : null}
                            model={perPageModel}
                            style={styleForm}
                            formDefaultValue={{per_page}}
                            >
                            <CustomField
                                name="per_page"
                                accepter={InputNumber}
                                errorPlacement="topRight"
                                defaultValue={per_page}
                                max={10000} 
                                min={1}
                                size="sm"
                                style={{width: 135}}
                                placeholder="Rows per page"
                                disabled={disabled}
                            />
                    </Form>
                }
        </div>   
)
}