import React,{useState}  from 'react';
import { Sidebar,  Sidenav, Nav, Icon, Dropdown } from 'rsuite';




export default  ({onClickInrerface}) => {

    const [show, setShow] = useState(true);
    const changeShow = () =>{
        setShow(!show);
    }
    const styleBottom = {
        position: 'absolute',
        bottom : '0',    
    }
    styleBottom.width = show ? '260px' : '56px';

    return (

        <Sidebar    style={{ display: 'flex', flexDirection: 'column' }}
            width={show ? 260 : 56}            
            collapsible  
        >        
            <Sidenav appearance="inverse" expanded={show}  style={{ height: '100vh' }} >
                <Sidenav.Body>
                <Nav>            
                    <Nav.Item icon={<Icon icon="home" />} >Home</Nav.Item>
                    <Nav.Item icon={<Icon icon="buysellads" />} >Accounts</Nav.Item>
                    
                    <Nav.Item icon={<Icon icon="th-list" />}  >Prices</Nav.Item>            
                    <Nav.Item icon={<Icon icon="phone" />} >Allocate Numbers</Nav.Item>
                    
                    <Dropdown
                        placement="rightTop"
                        eventKey="4"
                        title="Settings"
                        icon={<Icon icon="cog" />}
                    >
                        <Dropdown.Item eventKey="4-1" onClick={onClickInrerface} >Interface</Dropdown.Item>
                        <Dropdown.Item eventKey="4-2">Colors</Dropdown.Item>                
                    </Dropdown>
                    

                </Nav>      
                
                <Nav style={styleBottom}>
                    <Nav.Item onClick={changeShow} icon={<Icon icon={show  ? 'angle-left' : 'angle-right'} />} > <span style={{opacity:0}}>I</span></Nav.Item>
                </Nav>
                
                </Sidenav.Body>
            </Sidenav>
        </Sidebar>      
    );
};