import React, {Component} from 'react';
import {Container, Content, FlexboxGrid, Header} from "rsuite";
import Menu from "components/Navigation/Navigation";
import SettingInterface from "../containers/Setting/Inerface";
import SettingColor from "../containers/Setting/Color";
import NumberAllocation from "../pages/NumberAllocation";
import ErrorBoundary from "./Error";
import SideNav from "./SideNav";
import {connect} from "react-redux";
import {
    modifyAccountRequest,
    openAllocationModal,
    showModalColor,
    showModalInterface
} from '../actions';
import {unLogin} from "../actions/auth";
import VersionLabel from "components/VersionLabel/VersionLabel";

class Layout extends Component {
    render() {
        let ContainerWrapper;
        let {
            showModalInterface,
            showModalColor,
            unLogin,
            openAllocationModal,
            sidebar,
            method_list,
            modifyAccountRequest,
            modifyPasswordRequest,
            accountInfo,
            error,
            errorMessage
        } = this.props;
        const onClickInterface = () => showModalInterface(true);
        const onClickColor = () => showModalColor(true);

        if (sidebar) {
            ContainerWrapper = (props) => (
                <Container className="rs-container-has-sidebar">
                    <SideNav {...{onClickColor, unLogin, onClickInterface}}/>
                    <SettingInterface />
                    <SettingColor />
                    <Container>
                        {props.children}
                    </Container>
                </Container>
            )
        } else {
            ContainerWrapper = (props) => (
                <Container style={{minHeight: '100vh'}}>
                    {props.children}
                </Container>
            )
        }

        return (
            <ContainerWrapper>
                <Header>
                    <Menu {...{
                        onClickColor,
                        unLogin,
                        onClickInterface,
                        openAllocationModal,
                        method_list,
                        modifyAccountRequest,
                        modifyPasswordRequest,
                        accountInfo,
                        error,
                        errorMessage
                    }}/>
                    <SettingInterface/>
                    <SettingColor/>
                    <NumberAllocation/>
                </Header>
                <Content>
                    <FlexboxGrid justify="center">
                        <FlexboxGrid.Item colspan={22}>
                            <ErrorBoundary>
                                {this.props.children}
                            </ErrorBoundary>
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                </Content>
                <VersionLabel/>
                {/* <Footer>Footer</Footer> */}
            </ContainerWrapper>
        );
    }
}

const mapState = ( {settings, auth, references, accounts} )=> ({
    sidebar: settings.sidebar,
    auth: auth.auth,
    method_list: references.method_list,
    accountInfo: accounts.accountInfo,
    error: accounts.editError,
    errorMessage: accounts.editErrorMessage
});

export default connect(mapState,
    {
        showModalInterface,
        showModalColor,
        openAllocationModal,
        unLogin,
        modifyAccountRequest,
    })(Layout);