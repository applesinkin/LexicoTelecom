import React, {useEffect, useState} from 'react';
import ModalEdit from 'components/Modal/ModalEdit';
import {FlexboxGrid, Form, FormControl, Schema, Message} from 'rsuite';
import 'components/EditProfile/menu-colors.css';
import {replaceUndefinedOrNull} from '../../utils/helpers';

const {StringType} = Schema.Types;

const styles = {
    marginRight: '20px'
};


export default ({maxWidth = 520, show, onClose, data, modifyAccountRequest}) => {
    const [formValue, onChangeFormValue] = useState({});
    const [disabledButton, onDisableButton] = useState(false);

    let form;

    const formModel = Schema.Model({
        old_password: StringType()
            .isRequired('This field is required'),
    });


    const onSubmit = (form, model, value) => {
        if (!form.check()) {
            return false;
        }

        const comparedData = {...data, old_password: value.old_password};

        const formData = JSON.stringify(comparedData, replaceUndefinedOrNull);
        const clearedData = JSON.parse(formData);

        modifyAccountRequest(clearedData);

        return true;
    };

    const styled = getComputedStyle(document.documentElement);

    return (
        <ModalEdit {...{show, onClose}}
               onClose={() => onClose()}
               onSuccess={() => onSubmit(form, formModel, formValue)}
               successButtonProps={ {disabled: !disabledButton}}
               title="Confirm profile changes"
               successButton='Accept'
               width={maxWidth}
        >
            <Form
                model={formModel}
                ref={ref => form = ref}
                onChange={(data) => {
                    const checkedData = formModel.check(data);

                    const checker = Object.keys(checkedData).map(i => checkedData[i].hasError).every(value => value === false);
                    if (checker) {
                        onDisableButton(true);
                    } else {
                        onDisableButton(false);
                    }

                    onChangeFormValue(data);
                }}
            >
                <Message
                    type="info"
                    description="Type current password if you want to confirm changes"
                    style={{
                        width: '90%',
                        left: '5%',
                        marginBottom: '20px',
                        border: `1px solid ${styled.getPropertyValue('--color-info')}`
                    }}
                />

                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    {
                        <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                            Password
                        </FlexboxGrid.Item>
                    }
                    <FlexboxGrid.Item
                        style={{
                            width: '100%',
                            maxWidth: '300px',
                            minWidth: '140px'
                        }}>
                        <FormControl
                            name="old_password"
                            type="password"
                            placeholder="Password"
                            style={{
                                maxWidth: '300px',
                                minWidth: '140px'
                            }}
                        />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
            </Form>
        </ModalEdit>
    );
};