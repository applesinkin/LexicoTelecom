import React, {useEffect, useState} from 'react';
import {Button, FlexboxGrid, Form, FormControl, Icon, Schema, Message} from 'rsuite';
import ModalEdit from '../Modal/ModalEdit';
import ModalEditProfileConfirm from './ModalEditProfileConfirm';
import {USER_INFO} from '../../const/localStorageKeys';

const {StringType} = Schema.Types;

const styles = {
    marginRight: '20px'
};

export default ({maxWidth = 520, show, onClose, loading, updatedInfo, ...props}) => {
    const {modifyAccountRequest, error, errorMessage} = props;

    const user = localStorage.getItem(USER_INFO);
    const userInfo = updatedInfo || user && JSON.parse(user);

    const defaultFormProfileValue = {
        ...(userInfo && userInfo.name ? {name: userInfo.name} : {}),
        ...(userInfo && userInfo.surname ? {surname: userInfo.surname} : {}),
        ...(userInfo && userInfo.email ? {email: userInfo.email} : {}),
        ...(userInfo && userInfo.phone ? {phone: userInfo.phone} : {})
    };

    let form;

    const [showChangePassword, onChangeShowChangePassword] = useState(false);
    const [preparedData, onChangePreparedData] = useState(null);
    const [showConfirmEditModal, onChangeConfirmEditModal] = useState(false);
    const [passwordEqual, onEqualPasswords] = useState(false);

    const [formProfileValue, onChangeProfileFormValue] = useState(defaultFormProfileValue);
    const [formPasswordValue, onChangePasswordFormValue] = useState({});
    const [formProfileError, onChangeProfileErrorValue] = useState({});
    const [formPasswordError, onChangePasswordErrorValue] = useState({});
    const [disabledButton, onDisabledButton] = useState({password: true, profile: true});


    const clearFormState = () => {
        onChangeProfileFormValue(defaultFormProfileValue);
        onChangePasswordFormValue({});
        onChangeProfileErrorValue({});
        onChangePasswordErrorValue({});

        onChangeShowChangePassword(false);
        onEqualPasswords(false);
        onDisabledButton({password: true, profile: true})
    };

    const formProfileModel = Schema.Model({
        name: StringType()
            .maxLength(40, 'The maximum of this field is 40 characters'),
        surname: StringType()
            .maxLength(40, 'The maximum of this field is 40 characters'),
        email: StringType()
            .isEmail('Please enter an email address')
            .maxLength(256, 'The maximum of this field is 256 characters'),
        phone: StringType()
            .pattern(/^[1-9][\d]*$/, 'The number must not begin with 0 and must contain only digits')
            .maxLength(15, 'The maximum  of this field is 15 characters')
    });

    const formPasswordModel = Schema.Model({
        password: StringType()
            .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])[A-Za-z'\d#?!_@$%^&*-]{8,}$/, 'At least one number and uppercase and lowercase letter')
            .minLength(8, 'Password must be at least 8 characters ')
    });

    useEffect(() => {
        if (error && errorMessage) {
            clearFormState();
        }
    }, [error]);

    const onSubmit = (form) => {
        if (!form.check()) {
            return false;
        }
        onChangePreparedData({...formPasswordValue, ...formProfileValue});
        onChangeConfirmEditModal(true);

        return false
    };

    const checkFormError = (errorObj) => {
        return Object.keys(errorObj).map(i => errorObj[i].hasError).every(value => value === false)
    };

    const clearPassword = () => {
        formPasswordError && Object.keys(formPasswordError).length !== 0 && onChangePasswordErrorValue({
            ...Object.keys(formPasswordError)
                .filter(key => key !== 'password')
                .reduce((result, current) => {
                    result[current] = formPasswordError[current];
                    return result;
                }, {})
        });
        console.log(formPasswordValue, formPasswordError);
        formPasswordValue && Object.keys(formPasswordValue).length !== 0 && onChangePasswordFormValue(
            Object.assign({},
                ...Object.entries(formPasswordValue)
                    .filter(([key]) => key !== 'password')
                    .map(([result, current]) => ({[result]: current}))
            ));
        onChangeShowChangePassword(false);
        onEqualPasswords(false);
    };

    const styled = getComputedStyle(document.documentElement);

    return (
        <ModalEdit {...{show, onClose}}
                   onSuccessClose={false}
                   onClose={() => {
                       onClose();
                       clearFormState();
                   }}
                   onSuccess={() => onSubmit(form, formProfileValue)}
                   successButton={'Send'}
                   successButtonProps={{
                       disabled:
                           !checkFormError(formProfileError) ||
                           !checkFormError(formPasswordError) ||
                           showChangePassword && !passwordEqual && (!disabledButton.password || !disabledButton.profile) ||
                           !showChangePassword && disabledButton.profile
                   }}
                   title={`Edit profile`}
                   width={maxWidth}
        >
            <Form
                ref={ref => form = ref}
                model={formProfileModel}
                onChange={(data) => {
                    const checkedData = formProfileModel.check(data);
                    const formData = {name: data.name, surname: data.surname, email: data.email, phone: data.phone};

                    onChangeProfileErrorValue(checkedData);
                    onChangeProfileFormValue(formData);

                    if ((!formData.name && !formData.surname && !formData.email && !formData.phone && !formData.password) ||
                        (userInfo &&
                            (formData.name === userInfo.name && formData.surname === userInfo.surname &&
                                formData.email === userInfo.email && formData.phone === userInfo.phone))) {
                        onDisabledButton({...disabledButton, profile: true});
                    } else {
                        onDisabledButton({...disabledButton, profile: false})
                    }
                }}
                value={formProfileValue}
                formDefaultValue={formProfileValue}
            >
                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    {
                        <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                            Name
                        </FlexboxGrid.Item>
                    }
                    <FlexboxGrid.Item className="edit-profile-input-wrapper">
                        <FormControl
                            name="name"
                            type="text"
                            placeholder="Name"
                            className="edit-profile-input"
                        />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    {
                        <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                            Surname
                        </FlexboxGrid.Item>
                    }
                    <FlexboxGrid.Item className="edit-profile-input-wrapper">
                        <FormControl
                            name="surname"
                            type="text"
                            placeholder="Surname"
                            className="edit-profile-input"
                        />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    {
                        <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                            Email
                        </FlexboxGrid.Item>
                    }
                    <FlexboxGrid.Item className="edit-profile-input-wrapper">
                        <FormControl
                            name="email"
                            type="email"
                            placeholder="Email"
                            className="edit-profile-input"
                        />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    {
                        <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                            Phone
                        </FlexboxGrid.Item>
                    }
                    <FlexboxGrid.Item className="edit-profile-input-wrapper">
                        <FormControl
                            name="phone"
                            type="text"
                            placeholder="Phone"
                            className="edit-profile-input"
                        />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
            </Form>
            {
                showChangePassword && (!disabledButton.password || !disabledButton.profile) || (disabledButton.profile) &&
                <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                    <Message
                        showIcon
                        type="warning"
                        description="Nothing to update"
                        style={{
                            width: '100%',
                            border: `1px solid ${styled.getPropertyValue('--color-warning')}`
                        }}
                    />
                </FlexboxGrid>
            }
            <Form
                ref={ref => form = ref}
                model={formPasswordModel}
                onChange={(data) => {
                    const checkedData = formPasswordModel.check(data);

                    onChangePasswordErrorValue(checkedData);

                    if (data.password && data.confirm_password) {
                        onEqualPasswords(data.password === data.confirm_password);
                    }

                    onChangePasswordFormValue({password: data.password});

                    onDisabledButton({...disabledButton, password: !data.password})
                }}
                value={formPasswordValue}
                formDefaultValue={formPasswordValue}
            >
                {!showChangePassword && <FlexboxGrid style={{marginTop: '20px', width: '100%'}}>
                    <FlexboxGrid.Item style={{width: '100%'}}>
                        <Button
                            style={{width: '100%'}}
                            onClick={() => onChangeShowChangePassword(true)}
                            appearance="ghost"
                            color="violet"
                            disabled={loading}
                        >
                            <Icon icon="pencil"/> Change password
                        </Button>
                    </FlexboxGrid.Item>
                </FlexboxGrid>}
                {showChangePassword && <>
                    <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                        {
                            <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                                Password
                            </FlexboxGrid.Item>
                        }
                        <FlexboxGrid.Item
                            style={{
                                width: '100%',
                                maxWidth: '300px',
                                minWidth: '140px'
                            }}>
                            <FormControl
                                errorMessage={formPasswordError.password && formPasswordError.password.errorMessage || null}
                                name="password"
                                type="password"
                                placeholder="Password"
                                style={{
                                    maxWidth: '300px',
                                    minWidth: '140px'
                                }}
                            />
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                    <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                        {
                            <FlexboxGrid.Item style={{...styles, width: '100%', maxWidth: '100px'}}>
                                Confirm
                            </FlexboxGrid.Item>
                        }
                        <FlexboxGrid.Item
                            style={{
                                width: '100%',
                                maxWidth: '300px',
                                minWidth: '140px'
                            }}>
                            <FormControl
                                name="confirm_password"
                                type="password"
                                placeholder="Confirm password"
                                style={{
                                    maxWidth: '300px',
                                    minWidth: '140px'
                                }}
                            />
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                    {
                        !passwordEqual &&
                        <FlexboxGrid align="middle" style={{width: '100%', marginBottom: '20px'}}>
                            <span style={{color: 'red'}}>Password and confirm password should be equal!</span>
                        </FlexboxGrid>
                    }
                    <FlexboxGrid style={{marginTop: '20px', width: '100%'}}>
                        <FlexboxGrid.Item style={{width: '100%'}}>
                            <Button
                                style={{width: '100%'}}
                                onClick={() => {
                                    clearPassword()
                                }}
                                appearance="ghost"
                                color="violet"
                                disabled={loading}
                            >
                                <Icon icon="reply"/> Don't change password
                            </Button>
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                </>}
            </Form>
            <ModalEditProfileConfirm
                show={showConfirmEditModal}
                onClose={()=> {
                    clearPassword();
                    onChangeConfirmEditModal(false);
                }}
                data={preparedData}
                {...{
                    modifyAccountRequest
                }}
            />
        </ModalEdit>
        );
};