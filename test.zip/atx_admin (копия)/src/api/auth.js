import  { loginAxios, requestAxios } from './';
import {Alert} from "rsuite";
import {responseErrorToString} from "utils";

export const login = (data) => {
    return loginAxios.post('',
        {
            jsonrpc: "2.0",
            method: "account_user_login",
            params:  {...data, site: 1},
            id: null,
        });
};

export const notAuthApi = (method, params = {}, processErrorManual = true) => {
    return loginAxios.post('',
        {
            jsonrpc: "2.0",
            method,
            params,
            id: null
        }
    )
        .then(response => (response && response.data && response.data.result) || {})
        .catch((e) => {
            if (processErrorManual) {
                return Promise.reject(e);
            } else if (e.response) {
                Alert.error(responseErrorToString(e.response.data.error));
            }
        })
};

export const unlogin = () => {
    return requestAxios.post('',
        {
            jsonrpc: "2.0",
            method: "account_user_session_logout",            
            id: null,
        })
    .then( response =>  response )
    .catch( e => false )
};

