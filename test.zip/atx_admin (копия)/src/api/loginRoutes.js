import  { requestAxios } from '.';
import {responseErrorToString} from "utils";
import {Alert} from 'rsuite';

export const api = (method = '', params = {}, processErrorManual) => {
    return requestAxios.post('',
        {
            jsonrpc: "2.0",
            method,
            params,
            id: null
        }
    )
    .then(response => (response && response.data && response.data.result) || {})
        .catch((e) => {
            if (processErrorManual) {
                return Promise.reject(e);
            } else {
                Alert.error(responseErrorToString(e.response.data.error));
            }
        })
};

export const generateApiUrl = ({method, path = ''}) => {
    return `${process.env.REACT_APP_API_URL}${path}?method=${method}`
};

export const getFileResponse = (method, params) => {
    return requestAxios.post(
        generateApiUrl({method, path: '/csv'}),
        {
            jsonrpc: '2.0',
            method,
            params,
            id: null,
        },
        {
            responseType: 'blob'
        }
        
    )
    .then( response => (response && response.data) )
    .catch( e => null )
};