import axios from 'axios';
import { Alert } from 'rsuite';
import store  from '../store/index';
import { setAuth } from '../actions/auth';
import {generateApiUrl} from "./loginRoutes";
import _ from 'lodash';
import {DEFAULT_NOT_AUTH_PATH} from "const";
import history from "config/history";


const  _loginAxios = () => {
    const instanceAxios =  axios.create({
        baseURL: process.env.REACT_APP_API_URL,
        headers: {        
            "Content-Type": 'application/json'
        }
    });

    return instanceAxios;
};


const  _requestAxios = () => {
    let instanceAxios =  axios.create({
        baseURL: process.env.REACT_APP_API_URL,
        headers: {        
            "Content-Type": 'application/json'
        },
        timeout: 3600000
    });

    /* Request Interceptor */
    instanceAxios.interceptors.request.use(function (config) {
        // Do something before request is sent    
        if(localStorage.getItem('api_key')){
            config.baseURL = generateApiUrl({method: config.data.method});

            config.headers = {
                ...config.headers,
                'Session-Key': localStorage.getItem('api_key')
            }
        } else {
            store.dispatch(setAuth(false));
        }
            
        return config;
      }, function (error) {
        // Do something with request error
        return Promise.reject(error);
    });

    const codeError = {
        1 : 'No Authorization',
        3 : 'Invalid request',
        DEFAULT: 'Something Went Wrong'
    };

    /* Response Interceptor */
    instanceAxios.interceptors.response.use(function (response) {
        if (response.data.error){
            if (response.data.error.code === 1 || response.data.error.code === 2) {
                store.dispatch(setAuth(false))
                localStorage.removeItem('api_key');
                history.push(DEFAULT_NOT_AUTH_PATH);
            }
            else {                
                Alert.error(codeError[response.data.error.code] || codeError.DEFAULT);
            }

            return null;
        }

        return response;
    }, function (error) {
        const { response } = error;
        const responseError = _.get(response, 'data.error');

        if (responseError){
            if (responseError.code === 1 || response.data.error.code === 2) {
                store.dispatch(setAuth(false));
                localStorage.removeItem('api_key');
                history.push(DEFAULT_NOT_AUTH_PATH);

                return null;
            }
        }

        return Promise.reject(error);
    });

    return instanceAxios;
};


export const loginAxios = _loginAxios();
export const requestAxios = _requestAxios();
