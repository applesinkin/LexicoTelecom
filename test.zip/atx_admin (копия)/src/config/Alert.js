import {ALERT_DISPLAY_DURATION} from "const";
import {Alert} from 'rsuite';

Alert.config({duration: ALERT_DISPLAY_DURATION});