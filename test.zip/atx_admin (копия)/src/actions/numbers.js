import {DESC_SORT, PRICE_NUMBERS, SET_NUMBERS} from '../const/';
import {api} from '../api/loginRoutes';
import {createAction} from  './defaults';
import {DEFAULT_PER_PAGE_TINY} from "../const";


const setLoading = createAction('SET_LOADING_'+PRICE_NUMBERS);
const setNumbers = createAction(SET_NUMBERS);

export const getNumbers = (pr_key,filter = {},page = 1, per_page = DEFAULT_PER_PAGE_TINY, sort = {}) => (dispatch) => {
    dispatch(setLoading(true));

    let sort1, sort1_desc;

    if (sort.column) {
        sort1 = sort.column;
        sort1_desc = sort.type && sort.type === DESC_SORT;
    }

    api('price_range_number:get_list', {pr_key,
        filter: {
            show_allocated_numbers:false,
            show_unallocated_numbers:false,
            show_test_numbers:false,
            show_block_allocation_numbers: false,
            show_only_block_allocation_numbers: false,
            ...filter
        },
        page,per_page, sort1, sort1_desc
    })
        .then( ({price_range_number_count,price_range_number_list}) => {
            localStorage.setItem(PRICE_NUMBERS+'_per_page', per_page);
            dispatch(setNumbers({
                items: price_range_number_list || [],
                count: price_range_number_count || 0,
                page,
                per_page
            }));
        })
        .finally(() => dispatch(setLoading(false)));
};
