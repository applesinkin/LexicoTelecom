import {REFERENCES_DIALER_TRUNK} from '../const/';
import {REFERENCES_SET_LISTS, REFERENCES_SET_LOADING} from './actionTypes';

import {api} from '../api/loginRoutes';
import {createAction} from './defaults';
import {REFERENCES_FOR_REPORTS_METHOD, REFERENCES_METHOD} from '../const/apiMethods';


const setLoading = createAction(REFERENCES_SET_LOADING);
const setReferences = createAction(REFERENCES_SET_LISTS);

export const getReferences = () => (dispatch) => {
    dispatch(setLoading(true));

    api(REFERENCES_METHOD)
        .then((references) => {
            dispatch(setReferences(references));
        })
        .finally(() => dispatch(setLoading(false)));
};

export const getReferencesForReports = () => (dispatch) => {
    dispatch(setLoading(true));

    api(REFERENCES_FOR_REPORTS_METHOD)
        .then((references) => {
            dispatch(setReferences(references));
        })
        .finally(() => dispatch(setLoading(false)));
};

const setDialerTrunk = createAction(REFERENCES_DIALER_TRUNK);

export const getDialerTrunk = () => (dispatch) => {
    api('trunk_list_for_accounts')
        .then(({trunk_list = []}) => {
            dispatch(setDialerTrunk(trunk_list.map(
                x =>({
                    ...x,
                    trunk_id: x.tr_uuid,
                    _name:`${x.acc_name}\\${x.tr_name}\\${x.sp_name}`
                })
            )));
        })
};