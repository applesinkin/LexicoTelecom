import {ACCESS_LIST as PREFIX, DEFAULT_PER_PAGE_MEDIUM, DESC_SORT} from '../const'
import {api} from '../api/loginRoutes'
import {createAction} from  './defaults'

const setAccessList = createAction('SET_ITEMS_'+PREFIX);
const setLoading = createAction('SET_LOADING_'+PREFIX);

export const getAccessList = (filter, page = 1, per_page = DEFAULT_PER_PAGE_MEDIUM, sort) => (dispatch) => {
    dispatch(setLoading(true));

    let sort1, sort1_desc;

    if (sort.column) {
        sort1 = [sort.column];
        sort1_desc = sort.type && sort.type === DESC_SORT;
    }

    api('access_list__get_list', {filter, page, per_page, sort1, sort1_desc})
        .then(({access_list_count = 0, access_list_list = []}) => {
            localStorage.setItem(PREFIX + '_per_page', per_page);

            dispatch(setAccessList({
                count: access_list_count,
                access_list_list,
                page,
                per_page
            }));
        })
        .finally(() => dispatch(setLoading(false)));
};
