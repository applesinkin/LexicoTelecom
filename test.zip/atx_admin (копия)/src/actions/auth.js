import {DEFAULT_AUTH_PATH, DEFAULT_NOT_AUTH_PATH, SET_AUTH, SET_LOADING_INFO} from '../const';
import {login, unlogin} from '../api/auth';
import {createAction} from  './defaults';
import { setRoles } from './index';
import history from '../config/history';
import {NEED_SECOND_AUTH, SET_PERMISSION} from "actions/actionTypes";
import {api} from "api/loginRoutes";
import {notAuthApi} from "api/auth";
import {Alert} from 'rsuite';
import _ from 'lodash';
import {DEFAULT_ERROR_MESSAGE, SET_INFO_ACCOUNT} from 'const';
import {USER_INFO} from 'const/localStorageKeys';

export const setAuth = createAction(SET_AUTH);
const setLoading = createAction(SET_LOADING_INFO);
const setInfoAccount = createAction(SET_INFO_ACCOUNT);

export const checkLogin = (data) => (dispatch) => {
    dispatch(setLoading(true));
    login(data).then((response) => {
        const secondAuthType = response.data.result.second_authentication_type;

        if (secondAuthType) {
            dispatch({
                type: NEED_SECOND_AUTH,
                payload: {
                    secondAuthType: secondAuthType === 1 ? 'email' : 'phone',
                    secondAuthLink: secondAuthType === 1 ? response.data.result.email : response.data.result.phone,
                    secondAuthEmail: response.data.result.email
                }
            })
        } else {
            dispatch(setAuth(true));
            dispatch(setRoles(response.data.result.session.account_user.role_list));

            localStorage.setItem('api_key', response.data.result.session.session_key);
            localStorage.setItem('userInfo', JSON.stringify(response.data.result));

            history.push(DEFAULT_AUTH_PATH);
        }

    }).catch((error) => {
        dispatch(setAuth(false));
        Alert.error(_.get(error, 'response.data.error.data.error_type', DEFAULT_ERROR_MESSAGE));

        return Promise.reject(error);
    }).finally(() => {
        dispatch(setLoading(false));
    })
};

export const getPermission = () => (dispatch) => {
    api('permitted_methods').then((resp) => {
        dispatch({
            type: SET_PERMISSION,
            payload: resp
        })
    })
};


export const unLogin = () => async (dispatch) => {
    await unlogin();

    localStorage.removeItem('api_key');
    localStorage.removeItem(USER_INFO);
    dispatch( setAuth(false) );
    dispatch( setInfoAccount(null) );

    history.push(DEFAULT_NOT_AUTH_PATH);
};