import {
    SET_ROLES
} from '../const/';
import {api} from '../api/loginRoutes';
import {createAction} from  './defaults';

export const setRoles = createAction(SET_ROLES);