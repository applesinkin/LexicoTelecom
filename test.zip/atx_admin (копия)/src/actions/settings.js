import {SETTINS_MODAL_SHOW, SET_SIDEBAR, SETTINS_MODAL_COLOR_SHOW, SET_COLOR, SET_NUMBER_ALLOCATION_MODAL} from '../const/';
import {createAction} from './defaults';


const _setModal = createAction(SETTINS_MODAL_SHOW);
export const showModalInterface = (value) => (dispatch) => {
    dispatch(_setModal(value));
};

const _setSidebar = createAction(SET_SIDEBAR);
export const setSidebar = (value) => (dispatch) => {
    dispatch(_setSidebar(value));
};

const _setModalColor = createAction(SETTINS_MODAL_COLOR_SHOW);
export const showModalColor = (value) => (dispatch) => {
    dispatch(_setModalColor(value));
};
const _setColor = createAction(SET_COLOR);
export const setColor = (value) => (dispatch) => {
    localStorage.setItem('color-schema', value);
    dispatch(_setColor(value));
};

const setStatusAllocationModal = createAction(SET_NUMBER_ALLOCATION_MODAL);
export const openAllocationModal = () => (dispatch) => {
    dispatch(setStatusAllocationModal(true));
};
export const closeAllocationModal = () => (dispatch) => {
    dispatch(setStatusAllocationModal(false));
};