import {
    ACCOUNTS as PREFIX, VIEW_ACCOUNT, SET_VIEW_ACCOUNT, ADD_TRUNK_ACCOUNT,
    SET_ALLOCATED_ACCOUNT, SET_TRUNK_ACCOUNT, SET_TRUNK_ACCOUNT_LOADING, SET_ALLOCATED_ACCOUNT_LOADING,
    SET_USERS_ACCOUNT, SET_USERS_ACCOUNT_LOADING,
    SET_VIEW_ACCOUNT_AFTER_DELETE, DESC_SORT, SET_INFO_ACCOUNT, SET_LOADING_INFO, SET_EDIT_ERROR, SET_EDIT_ERROR_MESSAGE
} from '../const/';
import {Alert} from 'rsuite';
import {api, getFileResponse} from '../api/loginRoutes';
import {createAction} from  './defaults';
import { saveFileBlob } from '../utils/helpers'
import { formatDateApiWithoutTime } from '../utils/format';
import {ACCOUNT_USER_MODIFY_BY_SELF, ACCOUNT_USER_MODIFY_PASSWORD_BY_SELF} from '../const/apiMethods';
import {USER_INFO} from '../const/localStorageKeys';
import {ACCOUNT_CREATE_METHOD} from "const/apiMethods";
import {SET_ACCESS_LIST_FILTERS, SET_ACCESS_LIST_FILTERS_LOADING} from 'const';

const setAccounts = createAction('SET_ITEMS_'+PREFIX);
const setLoading = createAction('SET_LOADING_'+PREFIX);
const viewAccount = createAction(VIEW_ACCOUNT);
const setViewAccount = createAction(SET_VIEW_ACCOUNT);

const setEditError = createAction(SET_EDIT_ERROR);
const setEditErrorMessage = createAction(SET_EDIT_ERROR_MESSAGE);

const setViewAccountTrunk = createAction(SET_TRUNK_ACCOUNT);
const setViewAccountTrunkAfterDelete = createAction(SET_VIEW_ACCOUNT_AFTER_DELETE)

const setViewAccountTrunkLoading = createAction(SET_TRUNK_ACCOUNT_LOADING);
const setViewAccountAllocated = createAction(SET_ALLOCATED_ACCOUNT);
const setViewAccountAllocatedLoading = createAction(SET_ALLOCATED_ACCOUNT_LOADING);
const addViewAccountTrunk = createAction(ADD_TRUNK_ACCOUNT);

const setViewAccessListFiltersLoading = createAction(SET_ACCESS_LIST_FILTERS_LOADING);
const setViewAccessListFilters = createAction(SET_ACCESS_LIST_FILTERS);

const setViewAccountUsers = createAction(SET_USERS_ACCOUNT);
const setViewAccountUsersLoading = createAction(SET_USERS_ACCOUNT_LOADING);

const setInfoAccount = createAction(SET_INFO_ACCOUNT);
const setLoadingInfo = createAction(SET_LOADING_INFO);

export const getAccounts = () => (dispatch) => {
    dispatch(setLoading(true));

    api('account:get_list').then(({account_list = []}) => {
        dispatch(setAccounts(
            account_list.map(
                x => ({
                    ...x,
                    name: x.name || '',
                    account_manager: x.account_manager || {},
                    closed: !x.active || x.deleted,
                    balance: x.BALANCE || 0,
                    invoice_balance: x.BALANCE_INV || 0
                })
            )
        ));

    }).finally(() => dispatch(setLoading(false)));
};

export const getAccount = (id, getFromApi= true) => (dispatch) => {
    dispatch(setLoading(true));

    if (!getFromApi) {
        dispatch(viewAccount(id));
    } else {
        api('account:get', {target: {account_id: id}})
            .then(({account = {}}) => {
                dispatch(
                    setViewAccount({
                        ...account,
                        permission_list: account.permission_list || [],
                        trunk_notificaton: account.trunk_notificaton || []
                    }));
            })
            .finally(() => dispatch(setLoading(false)));
    }
};

export const getAccessListFilter = (id, filter, page = 1, per_page, sort = {}) => (dispatch) => {
    dispatch(setViewAccessListFiltersLoading(true));

    api('access:get_list', {target: {account_id: id}, filter, page, per_page, sort})
        .then(({access_list}) => dispatch(setViewAccessListFilters(access_list)))
};

export const getAccountTrunk = (id, callback) => (dispatch) => {
    dispatch(setViewAccountTrunkLoading(true));

    dispatch(setViewAccountAllocated({
        items: [],
        count: 0,
        page: 1
    }));

    api('trunk:get_list',{target:  {account_id: id }})
        .then( ({ trunk_list = [] }) => {
            dispatch(
            setViewAccountTrunk(
                (trunk_list || []).map( trunk => ({
                    ...trunk,
                    type: trunk.is_default_term_point ? 'Default IVR' : `${trunk.protocol_name}/${trunk.ip}:${trunk.port} ${trunk.tprefix}`
                }))
            ));
             callback && callback(trunk_list || [])
            }
        )
        .finally(() => dispatch(setViewAccountTrunkLoading(false)));
};

export const createAccountTrunk = (id, data) => (dispatch) => {
    api('trunk:create', {
        target: {account_id: id},
        sp_key: data.sp_key,
        prt_key: data.prt_key,
        ...data
    }).then(({trunk}) => trunk && dispatch(addViewAccountTrunk({...trunk, ...data})))
};

export const editAccountTrunk = (id, trunk_id, data) => (dispatch) => {
    api('trunk:modify', {
        target: {account_id: id, trunk_id: trunk_id},
        sp_key: data.sp_key,
        prt_key: data.prt_key,
        ...data
    }).then(({trunk}) => trunk && dispatch(addViewAccountTrunk({...trunk, ...data})))
};

export const removeAccountTrunk = (id, trunk_id, trunk1_id) => (dispatch) => {
    dispatch(setViewAccountTrunkLoading(true));

    api('trunk:get_list',{target:  {account_id: id }})
        .then( ({ trunk_list = [] }) => {
            if (trunk1_id) {
                api('trunk:remove', {target: {account_id: id, trunk_id, trunk1_id}}).then(({trunk}) => {
                    dispatch(setViewAccountTrunkAfterDelete(trunk.id))
                })
            } else {
                api('trunk:remove', {target: {account_id: id, trunk_id}}).then(({trunk}) => {
                    dispatch(setViewAccountTrunkAfterDelete(trunk.id))
                });
            }
        })
        .finally(() => dispatch(setViewAccountTrunkLoading(false)));

};

export const getAccountAllocatedNumbers = (account_id, trunk_id, group, filter, page = 1, per_page, sort = {}) => (dispatch) => {
    dispatch(setViewAccountAllocatedLoading(true));

    let sort1, sort1_desc;

    if (sort.column) {
        sort1 = sort.column === 'name' ? 'price_range_name' : sort.column;
        sort1_desc = sort.type && sort.type === DESC_SORT;
    }

    localStorage.setItem('allocatedNumbersPerPage', per_page);

    api('trunk_number__get_list',{target:{account_id ,trunk_id} , group, filter, page, per_page, sort1, sort1_desc}).then(
        ({trunk_number_list, group_price_range_list, group_subdestination_list,
             trunk_number_count, group_price_range_count, group_subdestination_count}) => dispatch(setViewAccountAllocated(
            {
                items: (trunk_number_list || group_price_range_list || group_subdestination_list || []).map(
                    x => {
                        if(group_price_range_list) {
                            x.pr_key = x.price_range.pr_key;
                            x.sde_key = x.price_range.sde_key;
                            x.sp_key = x.price_range.sp_key;
                            x.subdestination_name = x.price_range.subdestination_name;
                        }

                        if(!x.subdestination_name){
                            x.subdestination_name = x.sde_name;
                        }

                        if(x.start_date && x.end_date)
                            x.date = formatDateApiWithoutTime(x.start_date) + '-' + formatDateApiWithoutTime(x.end_date);
                        if(x.price_range)
                            x.name = x.price_range.name;

                        if(x.price_ranges && x.trunk_numbers)
                            x.allocated_numbers_and_ranges = x.trunk_numbers +'/'+ x.price_ranges;

                        return x;
                    }
                ),
                count: trunk_number_count || group_price_range_count || group_subdestination_count || 0,
                page,
                per_page
            }
            )))
        .finally(() => dispatch(setViewAccountAllocatedLoading(false)));
};

export const getAccountUsers = (account_id) => (dispatch) => {
    dispatch(setViewAccountUsersLoading(true));
    api('account_user:get_list', {target: {account_id}} )
        .then( ({account_user_list}) => {
            dispatch(setViewAccountUsers(account_user_list || []))
        })
        .finally(() => dispatch(setViewAccountUsersLoading(false)));

};

export const createAccount = (params) => dispatch => {
    api(ACCOUNT_CREATE_METHOD, params).then( data => {
        console.log(data)
    } )
    // api('trunk_number__get_list',{target:  {account_id: id , trunk_id: trunk_id }}).then( ({ trunk_list = [] }) => dispatch(setViewAccountAllocated(trunk_list || [])))
    // api('trunk_number__get_list',{target:  {account_id: id , trunk_id: trunk_id }}).then( responce => console.log(responce))
};

export const modifyAccountRequest = ({name, surname, email, phone, password, old_password}) => (dispatch) => {
    const user = localStorage.getItem(USER_INFO);
    const userInfo = user && JSON.parse(user);

    const params = {
        ...(name ? {name: name} : {}),
        ...(surname ? {surname: surname} : {}),
        ...(phone ? {phone: phone} : {}),
        ...(email ? {email: email} : {}),
    };

    const dataToSave = {...userInfo, ...params};

    api(ACCOUNT_USER_MODIFY_BY_SELF, {...params, ...(password ? {password: password} : {}), old_password}, true)
        .then(response => {
            if (response) {
                dispatch(setEditError(false));
                if (response && response.account_user) {
                    Alert.success('Profile data has successfully changed!', 15000);
                    dispatch(setInfoAccount({
                        name: userInfo.name,
                        surname: userInfo.surname,
                        phone: userInfo.phone,
                        email: userInfo.email, ...params
                    }));
                    localStorage.setItem(USER_INFO, JSON.stringify(dataToSave))
                }
            }
        })
        .catch(error => {
            if (error.response && error.response.data.error.data.old_password) {
                Alert.error('Wrong old password', 15000);

                dispatch(setEditErrorMessage("Wrong old password"))
            }
        })
};