export const newAccount = "/accounts/new";

