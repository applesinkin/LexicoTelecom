import React, {useEffect, useState} from 'react';
import Login from './pages/Login/Login';
import Accounts from './containers/Accounts';
import NewAccount from './containers/CreateAccount';
import AccountView from './pages/Account';
import AccessList from './pages/AccessList/AccessList';
import LiveCalls from './pages/LiveCalls';
import Prices from './pages/Prices/Prices';
import RangesNumbers from './pages/RangesAndNumbers/Ranges';
import {Router, Switch, Route, Redirect} from "react-router-dom";
import Reload from "./components/Reload";
import history from './config/history';
import {DEFAULT_AUTH_PATH, DEFAULT_NOT_AUTH_PATH} from "./const";
import AuthRoute from "./components/Router/AuthRoute";
import {connect} from "react-redux";
import {getReferences} from "./actions/references";
import CDRPage from "./pages/CDR/CDRPage";
import TrafficReportsPage from "pages/TrafficReports/TrafficReportsPage";
import AuthNumbers from './pages/AuthNumbers/AuthNumbers';
import {getPermission} from "actions/auth";
import ResetPassword from "pages/ResetPassword/ResetPassword";


function App({auth, getReferences, getPermission}) {
    useEffect(() => {
        if (auth) {
            getReferences();
            getPermission();
        }
    });

    return (
        <Router history={history}>
            <Switch>
                <Route path="/login" component={Login}/>
                <Route path="/reset-password/:token?" component={ResetPassword}/>
                <AuthRoute exact path="/accounts" component={Accounts}/>
                <AuthRoute exact path="/accounts/view/:id" component={AccountView}/>
                <AuthRoute exact path="/accounts/new" component={NewAccount}/>
                <AuthRoute exact path="/access-list" component={AccessList}/>
                <AuthRoute exact path="/live-calls" component={LiveCalls}/>
                <AuthRoute exact path="/prices" component={Prices}/>
                <AuthRoute exact path="/ranges-numbers" component={RangesNumbers}/>
                <AuthRoute exact path="/cdr" component={CDRPage}/>
                <AuthRoute exact path="/traffic-reports" component={TrafficReportsPage}/>
                <AuthRoute exact path="/auth-numbers" component={AuthNumbers}/>
                <AuthRoute exact path="/reload" component={Reload}/>
                {!auth ? <Redirect to={DEFAULT_NOT_AUTH_PATH}/> : <Redirect to={DEFAULT_AUTH_PATH}/>}
            </Switch>
        </Router>
    );
}

const mapState = ({auth})=> ({
    auth: auth.auth
});

export default connect(mapState, {
    getReferences,
    getPermission
})(App);
