import {
    SETTINS_MODAL_SHOW,
    SET_SIDEBAR,
    SETTINS_MODAL_COLOR_SHOW,
    SET_COLOR,
    SET_NUMBER_ALLOCATION_MODAL
} from '../const/';

const initialState = {
    interfaceShow: false,
    sidebar: false,
    color: localStorage.getItem('color-schema') || '#8256C8',
    colorShow: false,
    showAllocation: false
};

const handlers = {
    [SETTINS_MODAL_SHOW]: (state, {payload}) => ({...state, interfaceShow: payload}),
    [SET_SIDEBAR]: (state, {payload}) => ({...state, sidebar: payload, interfaceShow: false}),
    [SETTINS_MODAL_COLOR_SHOW]: (state, {payload: colorShow}) => ({...state, colorShow}),
    [SET_COLOR]: (state, {payload: color}) => ({...state, color, colorShow: false}),
    [SET_NUMBER_ALLOCATION_MODAL]: (state, {payload: showAllocation}) => ({...state, showAllocation}),
    DEFAULT: state => state
};

export default (state = initialState, action) => {
    const handle = handlers[action.type] || handlers.DEFAULT;
    return handle(state, action)
};
