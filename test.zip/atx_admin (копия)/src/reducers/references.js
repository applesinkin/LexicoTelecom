import {
    DEFAULT_SP_KEY,
    REFERENCES_DIALER_TRUNK
} from '../const/';
import {REFERENCES_SET_LISTS, REFERENCES_SET_LOADING} from "../actions/actionTypes";
import _ from 'lodash';

const initialState = {
    loading: false,
    currency_list:[],
    payment_terms_list:[],
    account_manager_list:[],
    worldzone_list: [],
    destination_list: [],
    subdestination_list: [],
    protocol_list: [],
    service_plan_list: [],
    service_plan_list_filtered: [],
    client_list: [],
    dialer_list: [],
    supplier_list: [],
    dialerTrunkList: [],
    defaultSPKey: DEFAULT_SP_KEY,
};

const handlers = {
    [REFERENCES_SET_LOADING]: (state,{payload}) =>({...state, loading: payload}),
    [REFERENCES_SET_LISTS]: (state, {payload: references}) => ({
        ...state,
        ...references,
        defaultSPKey: _.get(references, 'service_plan_list[0].sp_key', DEFAULT_SP_KEY),

        loading: false
    }),
    [REFERENCES_DIALER_TRUNK]: (state, {payload: dialerTrunkList}) => ({...state, dialerTrunkList}),
    DEFAULT: state => state
};

export default  (state = initialState, action) => {
  const handle = handlers[action.type] || handlers.DEFAULT;
  return handle(state,action)
};
