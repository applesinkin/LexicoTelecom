import { combineReducers } from 'redux';
import accounts from './accounts';
import settings from './setting';
import auth from './auth';
import references from './references';
import access_list from './access_list'
import live_calls from "./live_calls";
import prices from "./prices";
import ranges from "./ranges";
import numbers from "./numbers";
import roles from './roles';
import cdr from './cdr';
import traffic_reports from "reducers/traffic_reports";
import auth_numbers from './auth_numbers';

export default combineReducers({
    accounts,
    settings,
    auth,
    references,   
    access_list,
    live_calls,
    prices,
    ranges,
    numbers,
    roles,
    cdr,
    traffic_reports,
    auth_numbers
});