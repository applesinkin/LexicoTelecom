import {AUTH_NUMBERS as PREFIX} from '../const/';

const initialState = {
    loading: false,
    auth_number_list: [],
    loadingItem: false,
};


const handlers = {
    ['SET_ITEMS_'+PREFIX]: (state,{payload: auth_number_list}) =>({...state, auth_number_list, loading: false}),
    ['SET_LOADING_'+PREFIX]: (state,{payload}) =>({...state,loading: payload}),
    ['SET_LOADING_ITEM_'+PREFIX]: (state,{payload}) =>({...state, loadingItem: payload}),
    DEFAULT: state => state
};

export default  (state = initialState, action) => {
    const handle = handlers[action.type] || handlers.DEFAULT;
    return handle(state,action)
};
