import  {SET_AUTH, SET_LOADING_INFO} from '../const';
import {NEED_SECOND_AUTH, SET_PERMISSION} from "actions/actionTypes";
import _ from 'lodash';
import {SET_INFO_ACCOUNT} from 'const';

const userInfo = localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) : null;

const initialState = {
    info: userInfo,
    updatedInfo: null,
    auth:  !!localStorage.getItem('api_key'),
    role: _.get(userInfo, 'session.account_user.role_list[0]', null),
    secondAuthType: null,
    secondAuthLink: null,
    secondAuthEmail: null,
    loading: false,
    permissions: []
};

const handlers = {
    [SET_AUTH]: (state,{payload}) =>({
        ...state,
        auth:payload,
        loading: false,
        secondAuthType: null,
        secondAuthLink: null,
        secondAuthEmail: null
    }),
    [SET_INFO_ACCOUNT]: (state, {payload}) => ({...state, updatedInfo: payload, loading: false}),
    [SET_LOADING_INFO]: (state,{payload}) =>({...state, loading:payload}),
    [NEED_SECOND_AUTH]: (state,{payload}) =>({...state, ...payload}),
    [SET_PERMISSION]: (state,{payload}) =>({...state, permissions: payload}),
    DEFAULT: state => state
};

export default  (state = initialState, action) => {
  const handle = handlers[action.type] || handlers.DEFAULT;
  return handle(state,action)
};



