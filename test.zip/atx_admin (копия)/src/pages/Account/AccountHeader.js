import React from 'react';
import {Nav} from 'rsuite';
import styled from 'styled-components';

const Name =  styled.span`
    font-family: Roboto;
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 16px;
    color: #8256C8;
    margin-right: 3px;
`;
const Value =  styled.span`
    font-family: Roboto;
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 16px;
    color: #363434;
    margin-right: 15px;
`;
const Header =  styled.div`
    margin-bottom: 25px;
`;


export default ({activeTab, onSelect, account = {}}) =>{
    const { name = '', account_manager = {}, currency = '', payment_terms = '' } = account;
    const { name:am_name = '',  } = account_manager || {};

    return (
            <>
                <Header>
                    <Name>Account:</Name><Value>{name}</Value>
                    <Name>Manager:</Name><Value>{am_name}</Value>
                    <Name>Currency:</Name><Value>{currency}</Value>
                    <Name>Payment terms:</Name><Value>{payment_terms}</Value>
                </Header>
                <Nav  activeKey={activeTab} onSelect={onSelect}  appearance="tabs" >
                    <Nav.Item eventKey="general">General</Nav.Item>
                    <Nav.Item eventKey="trunks">Trunks</Nav.Item>
                    <Nav.Item eventKey="rates">Rates</Nav.Item>
                    <Nav.Item eventKey="access">Access List Filters</Nav.Item>
                </Nav>
            </>    
        )
}