import {connect} from 'react-redux';
import {getAccount, getAccountAllocatedNumbers, getAccountTrunk, getAccountUsers,} from '../../actions/accounts';
import {getRates} from '../../actions/rates';
import Account from './Account';
import {getAccessListFilter} from 'actions';

const mapState = ({accounts, references, roles}) => ({
    account: accounts.accountView,
    accountLoading: accounts.loading,
    hasData: !!accounts.items.length,
    trunks: accounts.accountTrunk,
    trunksLoading: accounts.accountTrunkLoading,
    allocatedNumbers: accounts.accountAllocated,
    allocatedNumbersCount: accounts.accountAllocatedCount,
    allocatedNumbersPage: accounts.allocatedNumbersPage,
    allocatedNumbersPerPage: accounts.allocatedNumbersPerPage,
    
    payment_terms_list: references.payment_terms_list,
    currency_list: references.currency_list,
    allocatedNumbersLoading: accounts.accountAllocatedLoading,
    account_manager_list: references.account_manager_list,
    worldzone_list: references.worldzone_list,
    loadingReferences: references.loading,
    subdestination_list: references.subdestination_list,
    destination_list: references.destination_list,

    accountUsers: accounts.accountUsers,
    accountUsersLoading: accounts.accountUsersLoading,

    rates: accounts.rates,
    ratesLoading: accounts.ratesLoading,
    account_user_modify_method: roles.account_user_modify_method,
    account_user_remove_method: roles.account_user_remove_method,

    accessList: accounts.accessList,
    accessListLoading: accounts.accessListLoading
});

export default connect(mapState,
    {
        getAccount,
        getAccountTrunk,
        getAccessListFilter,
        getAccountAllocatedNumbers,
        getAccountUsers,
        getRates
    })(Account);
  
