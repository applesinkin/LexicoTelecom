import React from 'react';
import {Panel} from 'rsuite';
import TabGeneral from './General/TabGeneral';
import TabRates from './Rates/TabRates';
import TabTrunks from './Trunks';
import TabFilters from './Filters/TabFilters';
import AccountHeader from './AccountHeader';
import TabAccessListFilters from 'pages/Account/AccessListFilters/TabAccessListFilters';
import {getAccessListFilter} from 'actions';

export default  class  extends React.Component{
    state = {
        activeTab: 'trunks'
    };

    onSelect = (activeKey) => this.setState({activeTab:activeKey});

    shouldComponentUpdate(nextProps, nextState, nextContext) {
        if (nextState.activeTab !== 'trunks' && this.props.allocatedNumbers !== nextProps.allocatedNumbers) {
            return false;
        }

        return true;
    }

    componentDidUpdate(prevProps, prevState) {
        const {activeTab} = this.state;

        if (prevState.activeTab !== activeTab && this.tabTrunks.current) {
            this.getTrunks()
        }
    }

    componentDidMount() {
        this.tabTrunks = React.createRef();
        const tab = new URLSearchParams(this.props.location.search).get('tab');
         if(tab && ['general', 'trunks', 'rates'].includes(tab)) this.setState({activeTab:tab});

        this.acc_key = this.props.match.params.id;
        this.props.getAccount(this.acc_key, !!this.props.hasData);
        this.getTrunks();
        this.props.getAccountUsers(this.acc_key);
        this.props.getRates(this.acc_key);
    }

    getRates = (filter) => this.props.getRates(this.acc_key,filter);    
    getNumbers = (trunk_id,group,filter, page, per_page, sort) => () => {
        if (trunk_id) this.props.getAccountAllocatedNumbers(this.acc_key, trunk_id, group, filter,page, per_page, sort);
    };
    getTrunks = () => {
        if(this.tabTrunks.current)
            this.tabTrunks.current.setTrunk(null);
        this.props.getAccountTrunk(this.acc_key, (trunks)=>{
            const activeTrunk = trunks && trunks.length ? trunks.find((trunk) => !trunk.closed) : null;

            if(this.tabTrunks.current && activeTrunk) {
                this.tabTrunks.current.setTrunk(activeTrunk.id)
            }
        });
    };
    getAccess = (filter, page, per_page, sort) => {
        this.props.getAccessListFilter(this.acc_key, filter, page, per_page, sort)
    };

    render () {
        const {activeTab } =  this.state;
        const { currency_list, payment_terms_list, account_manager_list, loadingReferences, accessList, accessListLoading } = this.props;
        const {accountUsers, account_user_modify_method, account_user_remove_method, accountLoading, accountUsersLoading} = this.props;
        
        const { account = {}, getAccount , trunks, trunksLoading, worldzone_list, subdestination_list, destination_list,
                allocatedNumbers, allocatedNumbersLoading, allocatedNumbersCount, allocatedNumbersPage , allocatedNumbersPerPage } = this.props;

        const acc_key = this.acc_key;
        const isGeneralTabDependencyLoading = loadingReferences || accountLoading || accountUsersLoading;

        const {rates, ratesLoading} = this.props;
        return (
            
            <Panel style={{marginTop: 10}} classPrefix="white-pannel">
                <AccountHeader 
                    activeTab={activeTab}
                    onSelect={this.onSelect}
                    account={account}
                />
                {
                    (() =>  {
                        switch (activeTab) {
                            case 'general':
                                return <TabGeneral disabled={isGeneralTabDependencyLoading} {...{
                                    account,
                                    currency_list, 
                                    payment_terms_list, 
                                    account_manager_list,
                                    accountUsers,
                                    account_user_modify_method,
                                    account_user_remove_method,
                                    getAccount,
                                    loading: isGeneralTabDependencyLoading
                                }}
                                  getAccountUsers={() => this.props.getAccountUsers(this.acc_key)}
                                />;
                            case 'trunks':
                                return <TabTrunks
                                    ref = {this.tabTrunks}
                                    worldzone_list={worldzone_list}
                                    subdestination_list={subdestination_list}
                                    destination_list={destination_list}
                                    getNumbers = {this.getNumbers}
                                    getTrunks = {this.getTrunks}
                                    {...{
                                        trunks,
                                        trunksLoading,
                                        acc_key,
                                        account,
                                        allocatedNumbers,
                                        allocatedNumbersLoading,
                                        allocatedNumbersCount,
                                        allocatedNumbersPage,
                                        allocatedNumbersPerPage
                                    }}
                                />;
                            case 'rates':
                                return <TabRates {...{
                                    rates,
                                    ratesLoading,
                                    worldzone_list,
                                    subdestination_list,
                                    destination_list
                                }}
                                getItems = {this.getRates}
                                account_id = {this.acc_key}
                                />;
                            case 'access':
                                return <TabAccessListFilters {...{
                                    accessList,
                                    accessListLoading
                                }}
                                    getItems = {this.getAccess}
                                    account_id = {this.acc_key}
                                />;
                            default:
                                return null;
                        }
                    })()
                }
            </Panel>
        );    
    }
};