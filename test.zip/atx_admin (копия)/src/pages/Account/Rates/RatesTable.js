import React from 'react';
import {Table, IconButton, Icon} from 'rsuite';
import RenderedColumns from '../../../components/Table/RenderColumns';
import Edit from '../../../styled/EditButton';
import Remove from '../../../styled/DeleteButton';
import Pagination from '../../../components/Pagination'
import {renderColumn, toUTCDateTime} from 'utils';

const { Column, HeaderCell, Cell } = Table;

const columns = RenderedColumns([
    {label: 'Subdestination', dataKey: 'subdestination_name'},
    {label: 'Rate', dataKey: 'rate'},
    {label: 'Start date', dataKey: 'start_date', formatData: 'date'},
    {label: 'End date', dataKey: 'end_date', formatData: 'date'}
], {end_date: true});

export default ({data = [], loading = false, total, per_page, activePage, onChangePage, onChangePerPage, onClickDelete, onClickEdit}) => {
    
    const getData = () =>  {
        const start = per_page * (activePage - 1);
        const end = start + per_page;
        
        return data.filter((v, i) => i >= start && i < end);
    };

    const _data = getData();

    return (
        <>
            <Table
                data={_data}
                loading={loading}
                rowHeight={30}
                height={ ((_data.length * 30) || 100) + 50}
            >
                {columns}
                <Column width={50}>
                    <HeaderCell/>
                    <Cell style={{overflow: 'unset'}}>
                        {(rate) => <Edit onClick = { () => onClickEdit(rate)} style={{top: '-2px'}}/> }
                    </Cell>
                </Column>
                <Column width={50}>
                    <HeaderCell/>
                    <Cell style={{overflow: 'unset'}}>
                        {({id}) => <Remove onClick = { () => onClickDelete(id)} style={{top: '-2px'}}/> }
                    </Cell>
                </Column>
            </Table>
            <Pagination {...{total,per_page, activePage, onChangePage, onChangePerPage}} />
        </>
    );
};