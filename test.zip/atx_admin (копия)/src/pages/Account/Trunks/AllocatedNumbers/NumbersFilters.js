import React from 'react';
import WZ from '../../../../components/Filters/WZ';
import DE from '../../../../components/Filters/DE';
import SDE from '../../../../components/Filters/SDE';
import Search, {str} from '../../../../components/Filters/Search';
import {Form, FormGroup, Schema} from 'rsuite';
import FormHOC from '../../../../hoc/FilltersForm';
import './Allocated.css';
import Checkbox from '../../../../hoc/Checkbox';
import {debounce} from 'lodash';

const numbersFiltersModel = Schema.Model({str});

const NumbersFilters = React.forwardRef(({onChange, disabled}, ref) => {
    const [searchInput, onChangeSearchInput] = React.useState(null);
    const [formValue, onChangeFormValue] = React.useState({});
    return (
        <>
            <Form
                layout="inline"
                style={{display: 'inline-block'}}
            >
                <Search
                    onBlur={(event) => {
                        event.target && event.target.name === 'str' && event.target.focus();
                    }}
                    disabled={disabled}
                    placeholder="Range/Number search"
                    onChange={debounce((value) => {
                        onChangeSearchInput(value);
                        onChange({...formValue, str: value})
                    }, 1000)}
                />
            </Form>
            <Form
                layout="inline"
                style={{display: 'inline-block'}}
                onChange={(value) => {
                    onChangeFormValue(value);
                    onChange({...value, str: searchInput});
                }}
                model={numbersFiltersModel}
                ref={ref}
                readOnly={disabled}

            >
                <WZ disabled={disabled}/>
                <DE disabled={disabled}/>
                <SDE disabled={disabled}/>
                <FormGroup>
                    <Checkbox disabled={disabled} name="actual">Show outdated/revoked</Checkbox>
                </FormGroup>
            </Form>
        </>
    );
});

export default FormHOC(NumbersFilters, numbersFiltersModel, 300);