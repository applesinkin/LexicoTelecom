/* eslint-disable default-case */
import React from 'react';
import TableServerSort from '../../../../components/Table/TableServerSort';
import Filters from './NumbersFilters';
import {Radio, RadioGroup} from 'rsuite';
import {FooterActions, RadioCSS} from '../styled';
import AllocatedNumbersModal from './AllocateNumbersModal';
import NumbersActions from './NumbersActions';
import ChangeRateModal from './AllocateNumbersModal/ChangeRateModal';
import RevokeNumbersModal from '../RevokeNumbersModal';
import MoveNumbersModal from 'pages/Account/Trunks/MoveNumbersModal';
import {canIMoveNumbersToAnotherTrunk, convertDataInColumn} from 'utils';

const columns = [
    {label: 'Number', dataKey: 'number', sortable: true, displayWhen: ['trunk_number']},
    {label: 'Range', dataKey: 'name', sortable: true, displayWhen: ['trunk_number', 'price_range']},
    {label: 'Rate', dataKey: 'rate', sortable: true, displayWhen: ['trunk_number', 'price_range', 'subdestination']},
    {
        label: 'Created Date',
        dataKey: 'start_date',
        displayWhen: ['trunk_number'],
        formatData: 'date',
        sortable: true,
    },
    {
        label: 'Revoked Date',
        dataKey: 'end_date',
        displayWhen: ['trunk_number'],
        formatData: 'date',
        sortable: true,
    },
    {label: 'Allocated numbers', dataKey: 'trunk_numbers', sortable: true, displayWhen: ['price_range']},
    {label: 'Subdestination', dataKey: 'subdestination_name', sortable: true, displayWhen: ['subdestination']},
    {label: 'Allocated numbers and ranges', dataKey: 'allocated_numbers_and_ranges', displayWhen: ['subdestination']},
];

export default class extends React.Component {
    shouldComponentUpdate({trunk_id}) {
        if (trunk_id !== this.props.trunk_id) {
            const {currentDisplay, filterState} = this.state;
            const {allocatedNumbersPerPage} = this.props;

            const filters = filterState || this.filters.getValues();
            this.props.getNumbers(currentDisplay, filters, 1, allocatedNumbersPerPage);
            this.tableRef.clear();
            this._selectedList.clear();
            return false;
        }
        return true;
    }

    filters = null;
    _selectedList = new Set();

    state = {
        selected: {all: false, list: []},
        filterState: null,
        currentDisplay: 'trunk_number',
        showChangeRateModal: false,
        showRevokeModal: false,
        showMoveModal: false,
        showAllocatedNumbersModal: false,
        searchLoading: false,
        sort: {},
    };
    tableRef = null;

    getFilters = () => ({...this.filters.getValues()});
    getSelectedList = () => ({...this.state.selected, countAll: this.props.allocatedNumbersCount});

    getNumbers = (page, per_page, sort) => {
        const {currentDisplay} = this.state;

        this.props.getNumbers(currentDisplay, this.filters.getValues(), page, per_page, sort);
    };

    setFocusOnInput = (input) => {
        if (input.ref.current._reactInternalFiber.firstEffect.stateNode.focus)
            input.ref.current._reactInternalFiber.firstEffect.stateNode.focus();
    };

    onChangeFilters = (filters) => {
        const {currentDisplay, sort, searchLoading} = this.state;

        if (!searchLoading) this.setState({searchLoading: true});

        const intervalTimer = () => {
            setTimeout(() => {
                this.setState({searchLoading: false, filterState: filters});
                this.setFocusOnInput(this.filters);
            }, 1000);
        };

        intervalTimer();
        this.props.getNumbers(currentDisplay, filters, 1, this.props.allocatedNumbersPerPage, sort);
        // ref>current>_reactInternalFiber>firstEffect>stateNode
    };
    onChangeGroup = (currentDisplay) => {
        const {filterState} = this.state;

        this.tableRef.clear();
        this._selectedList.clear();
        this.setState({currentDisplay});
        this.props.getNumbers(currentDisplay, filterState || this.filters.getValues(), 1, this.props.allocatedNumbersPerPage, this.state.sort);
    };
    getInitialValues = () => {
        const {currentDisplay, selected} = this.state;
        let list = null;

        if (selected.all) {
            return {filter: this.filters.getValues(), filterAll: true};
        }
        switch (currentDisplay) {
            case 'trunk_number':
                list = {trn_key_list: selected.list};
                break;
            case 'price_range':
                list = {pr_key_list: selected.list};
                break;
            case 'subdestination':
                list = {sde_key_list: selected.list};
                break;

        }
        return {...list};
    };

    getCurrentEntityName = () => {
        return {
            'trunk_number': 'number',
            'price_range': 'range',
            'subdestination': 'subdestination'
        }[this.state.currentDisplay];
    };

    getSelectedCount = () => {
        const {selected: {list, all}} = this.state;
        if (all) return this.props.allocatedNumbersCount;

        return list.length;
    };

    updateItems = () => {
        const {currentDisplay, sort, filterState} = this.state;
        const {allocatedNumbersPerPage: per_page, allocatedNumbersPage: page, getNumbers} = this.props;
        this.tableRef && this.tableRef.clear();
        this._selectedList.clear();
        getNumbers(currentDisplay, filterState || this.filters.getValues(), page, per_page, sort);
    };
    proxyFilters = (filters) => {
        return {
            ...filters,
            actual: !filters.actual
        };

    };
    getRowKey = () => {
        const {currentDisplay} = this.state;
        switch (currentDisplay) {
            case 'trunk_number':
                return 'trn_key';
            case 'price_range':
                return 'pr_key';
            case 'subdestination':
                return 'sde_key';
        }
    };
    updateSelectedList = (selected) => {
        const {allocatedNumbers} = this.props;
        const rowKey = this.getRowKey();

        for (let item of this._selectedList) {
            if (!selected.list.find(key => key === item[rowKey]))
                this._selectedList.delete(item);
        }

        selected.list.map(key => {
            const value = allocatedNumbers.find(item => item[rowKey] === key);
            if (value)
                this._selectedList.add(value);
        });

        this.setState({selected});
    };

    getDataForChangeRate = () => {
        for (let item of this._selectedList) {
            return {
                sde_key: item.sde_key,
                sde_name: item.subdestination_name,
                account_name: this.props.account_name,
                sp_key: this.props.sp_key
            };
        }
    };

    render() {
        const {
            trunk_id, acc_key, showAllocatedNumbersModal, closeAllocatedNumbersModal,
            allocatedNumbers, allocatedNumbersLoading, allocatedNumbersCount, allocatedNumbersPage, allocatedNumbersPerPage,
            trunksLoading
        } = this.props;
        const {selected, currentDisplay, showChangeRateModal, showRevokeModal, showMoveModal, searchLoading} = this.state;
        const loading = trunksLoading || allocatedNumbersLoading;
        const currentTrunk = this.props.trunks.find((trunk) => trunk.id === trunk_id);

        const isselected = this.filters && this.filters.formValue ? !this.filters.formValue.actual : true;

        const data = convertDataInColumn(allocatedNumbers, "end_date", (value, column, key) => {
            return {...column, [key]: value ? new Date(new Date(new Date(value).setSeconds(new Date(value).getSeconds() - 1))) : null}
        });


        return (
            <div>
                <Filters
                    ref={ref => this.filters = ref}
                    onChange={this.onChangeFilters}
                    proxy={this.proxyFilters}
                    disabled={searchLoading || loading}
                />
                <RadioCSS>
                    <RadioGroup onChange={this.onChangeGroup} defaultValue={'trunk_number'} name="radioList" inline>
                        <Radio value="trunk_number" disabled={loading}>Numbers</Radio>
                        <Radio value="price_range" disabled={loading}>Ranges</Radio>
                        <Radio value="subdestination" disabled={loading}>Subdestinations</Radio>
                    </RadioGroup>
                    <AllocatedNumbersModal
                        forsed_open={showAllocatedNumbersModal}
                        onClose={closeAllocatedNumbersModal}
                        trunk_id={trunk_id}
                        sp_key={this.props.sp_key}
                        update={this.updateItems}
                        account_id={acc_key}
                        disabled={this.props.readonly}
                    />
                </RadioCSS>
                <TableServerSort
                    ref={ref => this.tableRef = ref}
                    data={data}
                    height="50%"
                    loading={searchLoading || loading}
                    columns={columns.filter(el => el.displayWhen.indexOf(currentDisplay) !== -1)}
                    count={allocatedNumbersCount}
                    per_page={allocatedNumbersPerPage}
                    page={allocatedNumbersPage}
                    getItems={this.getNumbers}
                    row_key={this.getRowKey()}
                    setSelected={this.updateSelectedList}
                    disabled={!trunk_id}
                    ispagination
                    isselected={isselected}
                    isSelectedAll={isselected}
                    onSort={(column, type) => this.setState({sort: {column, type}})}
                />
                <FooterActions>
                    <NumbersActions
                        actions={[
                            {
                                label: 'Change rate',
                                handler: () => this.setState({showChangeRateModal: true})
                            },
                            {
                                label: 'Revoke numbers',
                                handler: () => this.setState({showRevokeModal: true})
                            },
                            {
                                label: 'Move to another trunk',
                                handler: () => this.setState({showMoveModal: true})
                            },
                        ]}
                        disabled={!selected.list.length}
                    />
                </FooterActions>
                {showChangeRateModal && <ChangeRateModal
                    target={{trunk_id}}
                    targetPrice={{account_id: acc_key}}
                    initialValues={this.getInitialValues()}
                    update={this.updateItems}
                    getData={this.getDataForChangeRate}
                    onClose={() => this.setState({showChangeRateModal: false})}
                />}
                {showRevokeModal && <RevokeNumbersModal
                    target={{trunk_id}}
                    initialValues={this.getInitialValues()}
                    entity={this.getCurrentEntityName()}
                    getCount={this.getSelectedCount}
                    update={this.updateItems}
                    onClose={() => this.setState({showRevokeModal: false})}
                />}
                {showMoveModal && <MoveNumbersModal
                    target={{trunk_id}}
                    trunks={this.props.trunks.filter((trunk) => canIMoveNumbersToAnotherTrunk(currentTrunk, trunk))}
                    initialValues={this.getInitialValues()}
                    entity={this.getCurrentEntityName()}
                    getCount={this.getSelectedCount}
                    update={this.updateItems}
                    onClose={() => this.setState({showMoveModal: false})}
                />}
            </div>
        );

    }
}


