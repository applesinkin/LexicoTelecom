import React from 'react';
import { Form, Alert, Table as _Table, InputNumber} from 'rsuite';
import Checkbox from '../../../../../hoc/Checkbox';
import WZ from '../../../../../components/Filters/WZ';
import DE from '../../../../../components/Filters/DE';
import SDE from '../../../../../components/Filters/SDE';
import NumberField from '../../../../../components/Form/NumberField';
import MyForm from '../../../../../components/MyForm';
import { api } from '../../../../../api/loginRoutes';
import Table from '../../../../../components/Table';
import {pipe} from '../../../../../utils/helpers';
import RateField from "../../../../../components/Form/RateField";
const { Column, HeaderCell, Cell } = _Table;

export default ({activeTab, onSelect, target, sp_key, showResult, setNumberList, setHideBufferButtons, account_id, ...props} )  => {

    const [data,  setData] = React.useState({
        current: [],
        loading: true,
        state: []
    });

    React.useEffect( () => {
        setData({
            ...data,
            loading: true,
        });

        api('account_price__get_fullprice', {sp_key, target: {account_id: account_id}}).then(
            ({fullprice_for_account}) => {
                setData({
                    current: fullprice_for_account || [],
                    loading: false,
                    state: fullprice_for_account || [],
                })
            }
        )
    },[sp_key, account_id])
    
    const onChangePrice = (sde_key, price) => {
        const stateItems = data.state.map( 
            row => row.sde_key === sde_key ? {...row, checked: true, rate: price} : row
        )  
        const currentItems = data.current.map ( 
            row => row.sde_key === sde_key ? {...row, checked: true, rate: price} : row
        )
        
        setData({
            ...data,
            current: currentItems,
            state: stateItems,
        })
    }
    const onChangeChecked = (selected) => {
        const stateItems = data.state.map(
            row => selected.list.includes(row.sde_key) ? {...row, checked: true} : {...row, checked: false}
        )  
        const currentItems = data.current.map (
            row => selected.list.includes(row.sde_key) ? {...row, checked: true} : {...row, checked: false}
        )
        setData({
            ...data,
            current: currentItems,
            state: stateItems,
        })
    } 
    const onChangeFilters = (filters) => {
        setData({
            ...data,
            state: pipe(data.current, filters, FiltersFuncs)
        })
    }
   return (<>
        <FiltersSubdestination onChange={onChangeFilters} />
        <Table 
            data={data.state}
            height = "30%"
            loading={data.loading}
            columns = {columns} 
            row_key = "sde_key"
            setSelected = {onChangeChecked}  
            isselected
            stateChecked
            ActionCell = {ActionCell(onChangePrice)}
            width ={650}
        />
        <MyForm
            target={target}
            method="allocation:mass"
            checkResultKey = 'price_range_number_list'
            update = { ({price_range_number_list}) => {
                showResult();
                setNumberList(price_range_number_list || []);
                setHideBufferButtons(true);
            }}
            formDefaultValue={{
                random_number: true,
                ranges: 1,
                numbers: 10
            }}
            addData={{
                list: data.current.filter(x => x.checked).map( x => ({sde_key: x.sde_key, rate: +x.rate}))
            }}
            {...props}>
            <NumberField
                name="ranges"
                label="Ranges per subdestination"
                validationKey="numbers"
                min={0}
                step={1}
                useBr
            />
            <NumberField
                name="numbers"
                label="Number per range"
                useBr
                min={0}
                step={1}
            />
            <Checkbox name="random_number" defaultChecked>Random order</Checkbox>
        </MyForm>
</>)
}


const FiltersFuncs = {
    sde_key: (x,f) => x.sde_key === f,
    de_key: (x,f) => x.de_key === f,
    wz_key: (x,f) => x.wz_key === f,
    rate_from: (x,f) => x.rate >= +f,
    rate_to: (x,f, allfilters) => {
        // debugger;
        return (+f ? x.rate <= +f : true)},
}    

const FiltersSubdestination =  ( {onChange}) =>  {
    return (
            <Form 
                layout="inline"
                onChange={onChange}
                >
                <WZ />
                <DE />
                <SDE />
                <br />
                <RateField label={'Rate range from'} name="rate_from" />
                <RateField label={'to'} name="rate_to" />
            </Form>
        )
}

const columns = [
    {label: 'Subdestination', dataKey: 'sde_name'}
];

const ActionCell = (onChange) => (
    <Column flexGrow={1} >
        <HeaderCell>Price</HeaderCell>
        <Cell>
            { rowData => (
                <InputNumber
                    key={rowData.sde_key}
                    max={10}
                    min={0}
                    step={0.00001}
                    size="sm"
                    placeholder="0"
                    value={rowData.rate}
                    style={{position:'relative', top: '-5px', width: 100}}
                    onChange = { value => onChange(rowData.sde_key, value)}
                />
            )}
        </Cell>
    </Column>
);