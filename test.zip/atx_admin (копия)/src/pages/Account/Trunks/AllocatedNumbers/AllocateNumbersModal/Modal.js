import React, {useState} from 'react';
import NumberForm from './NumberForm';
import MassForm from './MassForm';
import ListForm from './ListForm';
import ModalSendApi from '../../../../../components/Modal/ModalSendApi'
import {connect} from 'react-redux';
import Tabs from './Tabs';
import DialerTrunk from '../../../../../components/Filters/DialerTrunk';
import {getDialerTrunk} from '../../../../../actions/references'
import AllocationResult from "./AllocationResult";
import Button from 'rsuite/es/Button';

const AllocateModal = ({ show, getDialerTrunk, disabledTrunk = false, trunk_id: _trunk_id, sp_key: _sp_key, update, onClose,
                           account_id: _account_id}) => {
    const [activeTab, setActiveTab] = useState('numberForm');
    const onSelect = (activeKey) => setActiveTab(activeKey);

    React.useEffect(() => {
        if(show)
            getDialerTrunk()
    }, [show]);

    const [sp_key, setSpKey] = useState(_sp_key);
    React.useEffect(() => setSpKey(_sp_key), [_sp_key]);

    const [trunk_id, setTrunkId] = useState(_trunk_id);
    React.useEffect(() => setTrunkId(_trunk_id), [_trunk_id]);

    const [account_id, setAccountId] = useState(_account_id);
    React.useEffect(() => setAccountId(_account_id), [_account_id]);

    const [showResult, setShowResult] = useState(false);
    const [numberList, setNumberList] = useState([]);

    const [hideBufferButtons, setHideBufferButtons ] = useState(false);

    return (
        <>
            {show &&
            <ModalSendApi
                title="Allocate numbers"
                successText="Allocate"
                update={update}
                onClose={onClose}
                width="730px"
                checkFirstAll
            >
                <DialerTrunk trunk_id={trunk_id} onChange={(trunk = {}) => {
                    trunk.trunk_id && setTrunkId(trunk.trunk_id);
                    trunk.sp_key && setSpKey(trunk.sp_key);
                    trunk.acc_uuid && setAccountId(trunk.acc_uuid)
                }}
                             disabledTrunk={disabledTrunk}
                />
                <Tabs activeTab={activeTab} onSelect={onSelect}/>
                {getForm({
                    activeTab, onSelect,
                    target: {trunk_id}, sp_key,
                    showResult: () => setShowResult(true),
                    setNumberList,
                    account_id,
                    setHideBufferButtons
                })}
            </ModalSendApi>}
            <AllocationResult
                show={showResult}
                numberList={numberList}
                onClose={() => setShowResult(false)}
                trunk_id={trunk_id}
                showFullList={activeTab !== 'massForm'}
                hideBufferButtons={hideBufferButtons}
            />
        </>
    );
};

const getForm = (props) => {
    switch (props.activeTab) {
        case 'numberForm':
            return <NumberForm {...props} />;
        case 'massForm':
            return <MassForm {...props} />;
        case 'listForm':
            return <ListForm {...props} />;
        default:
            return null;
    }

};

const mapState = ({references}) => ({});

export default connect(mapState, {getDialerTrunk})(AllocateModal);