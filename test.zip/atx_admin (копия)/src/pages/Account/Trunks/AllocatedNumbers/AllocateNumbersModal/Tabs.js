import React from 'react';
import {Nav} from 'rsuite';


export default ({activeTab, onSelect}) => (
    <Nav activeKey={activeTab} onSelect={onSelect}  appearance="tabs" style={{marginBottom: 20}} >
        <Nav.Item eventKey="numberForm">Number allocation</Nav.Item>
        <Nav.Item eventKey="massForm">Mass allocation</Nav.Item>
        <Nav.Item eventKey="listForm">List allocation</Nav.Item>                    
    </Nav>
)