import React from 'react';
import MyForm from './../../../../../components/MyForm';
import { Alert } from 'rsuite';
import Checkbox from '../../../../../hoc/Checkbox' 
import Text from '../../../../../components/Form/Text';
import SDE, {SDE_Component} from '../../../../../components/Filters/SDE'
import RateField from '../../../../../components/Form/RateField';
import NumberField from '../../../../../components/Form/NumberField';
import styled from 'styled-components'
import {api} from "api/loginRoutes";

export default  ({activeTab,setNumberList, onSelect, target, showResult, setHideBufferButtons, ...props} )  => {
    // const allocationTypeStyle = {display: 'flex',  justifyContent: 'space-between', width: '600px'}
    let formRef = React.useRef({random_number:false})
    const [method, setMethod] = React.useState('allocation:template')  
    const [valueTemplate, setValueTemplate] = React.useState('')  
    const [valueSde, setValueSde] = React.useState(null)
    const [pickedInput, changeInput] = React.useState(true) // true - template, false - subdestination
    const [valueForm, setValueForm] = React.useState({random_number: true, numbers: 10});

    const templateInput = <Text name="template" validationKey={ method === "allocation:template" ? "in_template_range" : null}
                                label="Template" width="md"
                                onChange={ (value) => {
                                    setValueTemplate(value);
                                }}
                                value = {valueTemplate}
                                placeholder="1234567890XX"
                                onClick={()=>{
                                    setMethod("allocation:template");
                                    changeInput(true)
                                    setValueSde(null)
                                }}
    />

    const sdeInput =  <SDE name="sde_key"
                           onChange={ (value) => {
                               setValueSde(value);
                           }}
                           value={valueSde}
                           validationKey = "num_required"
                           useBr
                           onClick={()=>{
                               setMethod("allocation:subdestination");
                               changeInput(false)
                               setValueTemplate(null)
                           }}
    />

    const handleFormChange = async (newFormValues) => {
        if (newFormValues.sde_key && valueForm.sde_key !== newFormValues.sde_key) {
            const resp = await api('account_price__get_fullprice_subdestination', {
                sp_key: props.sp_key,
                target: {account_id: props.account_id},
                sde_key: newFormValues.sde_key,
            });

            newFormValues.rate = resp.fullprice_for_account ? resp.fullprice_for_account.rate : '';
        }

        setValueForm(newFormValues);
    };


    return (
        <MyForm
            // Я вернул таргет, ибо после отправки запроса формы, method в запросе не менялся при последующих отправках
            target={method === 'allocation:subdestination' ? {...target, sde_key:valueSde} : target}
            //target={target}
            method={method}
            checkResultKey = 'price_range_number_list'
            update = { ({price_range_number_list}) => {
                showResult();
                setNumberList(price_range_number_list || []);
                setHideBufferButtons(false);
            }}
            {...props}
            className = "numberForm"
            onChange={handleFormChange}
            formValue={valueForm}
            >

            {!pickedInput ?
                <Fieldset> {templateInput} </Fieldset>
                :
                templateInput
            }
            <span className="rs-form-inline rs-control-label">or</span>
            {pickedInput ?
                <>
                    <Fieldset> {sdeInput} </Fieldset>
                    <br/>
                </>
                :
                sdeInput
            }

            <RateField name="rate" label="Rate" value={valueForm.rate}/>
            <NumberField name="numbers" label="Number amount" min={1} max={100000}/>
            <Checkbox name="random_number" defaultChecked>Random order</Checkbox>
        </MyForm>
    )
};
const Fieldset = styled.fieldset`
    border: none;
    margin: 0;
    padding: 0;
    display: inline-block;
    position: relative;
    > div > div > input {
        cursor: not-allowed
    }
    > div > div > div.rs-picker-select > a {
       cursor: not-allowed
    }
    > div > div {
        opacity: 0.6
        color: #888888
    }
`;