import React from 'react';
import {Modal, Button} from "rsuite";

export default ({show, onClose, onConfirm, size}) => {
    return (
        <Modal size={size} show={show} onHide={onClose}>
            <Modal.Header>
                <Modal.Title>Revoke numbers</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                Selected 55 numbers from this trunk will be revoked. Do you really want to do it?
            </Modal.Body>
            <Modal.Footer>
                <Button onClick={onConfirm} appearance="subtle">
                    Yes
                </Button>
                <Button  onClick={onClose} appearance="primary">
                    Cancel
                </Button>
            </Modal.Footer>
        </Modal>
    );
};