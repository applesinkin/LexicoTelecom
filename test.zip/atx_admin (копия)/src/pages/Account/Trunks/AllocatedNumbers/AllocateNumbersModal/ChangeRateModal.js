import React, {useState} from 'react';
import ModalSendApi from '../../../../../components/Modal/ModalSendApi';
import {Alert, Checkbox, DatePicker, Schema} from 'rsuite';
import ApiRequest from '../../../../../components/ApiRequest';
import {toEndDayUTCTime, toStartDayUTCTime} from 'utils';
import FormControl from 'rsuite/es/FormControl';
import ControlLabel from 'rsuite/es/ControlLabel';
import FormGroup from 'rsuite/es/FormGroup';
import {MIN_RATE_VALUE} from 'const';
import MyForm from '../../../../../components/MyForm';

const {NumberType} = Schema.Types;

export default ({initialValues, getData, target, targetPrice, update, ...props}) => {
    const [canSend, setSend] = React.useState(false);
    const [rate, setRate] = React.useState(0);
    const [endDate, setEndDate] = useState(null);
    const [withDate, setWithDate] = useState(false);
    const data = getData();

    const changeRateModel = {
        rate: NumberType()
            .min(MIN_RATE_VALUE, `The minimum value of this field is ${MIN_RATE_VALUE}`)
            .max(10, `The minimum value of this field is 10`)
    };

    return (
        <ModalSendApi
            {...props}
            title="Change Rate"
            successText="Change"
            update={update}
            extraDisabled={!rate || withDate && (!endDate || !rate)}
        >
            <ApiRequest
                target={targetPrice}
                method="account_price:create"
                checkResultKey = 'account_price'
                canSend = {canSend}
                data = {{
                    sp_key: data.sp_key,
                    sde_key: data.sde_key,
                    rate: rate
                }}
                update = { () => {
                    Alert.success(`Default rate ${rate} was set`);
                }}
            >
                <Checkbox onChange={(value, checked) => setSend(checked)} className="mb-3">
                    Set this  rate as defa435345ult for {data.sde_name} for {data.account_name}
                </Checkbox>
            </ApiRequest>
            <MyForm
                formDefaultValue={initialValues}
                model={changeRateModel}
                target={target}
                method="trunk_number__filter:change_rate"
                checkResultKey = 'trunk_numbers'
                update = { ({trunk_numbers}) => {
                    Alert.success(`Change Rate for ${trunk_numbers} numbers`)
                }}
                addData={{
                    rate: rate,
                ...(endDate ? {end_date: endDate} : {})
                }}
                className="d-flex flex-column align-items-center"
            >
                <FormGroup className="mb-3 mr-0">
                    <ControlLabel className="mr-3 mb-0">New Rate</ControlLabel>
                    <FormControl name="rate"
                                 label="New Rate"
                                 style={{width: 140}}
                                 placeholder="0.0001"
                                 onChange={value => setRate(+value)}
                                 errorPlacement="topStart"
                    />
                </FormGroup>
                <FormGroup className="mb-0 mr-0">
                    <Checkbox inline className="mr-4 ml-0" onChange={(v, checked) => {
                        setWithDate(checked);

                        if (!checked) {
                            setEndDate(null);
                        }
                    }}>From date</Checkbox>
                    <DatePicker
                        name="end_date"
                        placeholder="Enter Date"
                        disabled={!withDate}
                        onChange={(date) => {
                            date && setEndDate(toStartDayUTCTime(date));
                        }}
                    />
                </FormGroup>
            </MyForm>
        </ModalSendApi>
    );
};