import React, {useState} from 'react';
import {Alert, List as RsuiteList, Modal as RsuiteModal} from 'rsuite';
import {AddButton as Button, CancelButton,ButtonGroup} from "../../../../../styled/Buttons";
import styled from 'styled-components';
import {saveFileJson, copyToClipboard, saveFileBlob} from '../../../../../utils';
import {getFileResponse} from "../../../../../api/loginRoutes";
import {EOL} from "const";

const AllocationResult = ({onClose, numberList, account_id, trunk_id, hideBufferButtons, showFullList, show}) => {
    const filteredNumberList = numberList.filter(number => number.hasOwnProperty('status') && number.status === 0 || !number.hasOwnProperty('status'));

    const onDownload = () => {
        saveFileJson(filteredNumberList.map(item => ({
                number: item.number,
                trn_name: item.trn_name,
                rate: item.rate,
                currency_name: item.currency_name
            })),
            'Numbers',
            {
                number: 'Number',
                trn_name: 'Range',
                rate: 'Rate',
                currency_name: 'Currency'
            }
        );
    };

    const onCopy = () => {
      copyToClipboard(filteredNumberList
          .map( item => `${item.number}, ${item.trn_name}, ${item.rate} ${item.currency_name}`)
          .join(EOL)
      );
      Alert.success(`Copied!`)
    };

    const [loading, setLoading] = useState(false);
    const onCompleteDownload = async() => {
        setLoading(true);
        const result = await getFileResponse('trunk_number:get_list', {
            target: {trunk_id} //TODO maybe need add account_id
        });
        if(result) saveFileBlob(result,'allocated_numbers.csv');
        setLoading(false)
    };

    const numberListItems = filteredNumberList.map( item => <RsuiteList.Item key={item.prn_key}>
        {item.number}, {item.trn_name}, {item.rate} {item.currency_name}
    </RsuiteList.Item>);


    return (
            <RsuiteModal
                show={show}
                onHide={onClose}
                style={{width: '820px'}}
            >
                <RsuiteModal.Header>
                    <RsuiteModal.Title>
                        New Allocated numbers
                    </RsuiteModal.Title>
                </RsuiteModal.Header>
                <RsuiteModal.Body style={{minHeight: '228px', maxHeight: '360px', overflow: 'hidden'}}>
                    <div className="text-center"><strong>{filteredNumberList.length}</strong> numbers were allocated</div>
                    {showFullList &&
                        <List size='sm' style={{minHeight: '216px', maxHeight: '288px'}}>
                            {numberListItems}
                        </List>
                    }
                </RsuiteModal.Body>
                <RsuiteModal.Footer>
                    <ButtonGroup style={{textAlign: 'center'}}>
                        {!hideBufferButtons && <Button onClick={onCopy}>Copy List</Button>}
                        <Button onClick={onDownload}>Download List</Button>
                        <Button onClick={onCompleteDownload} loading={loading} disabled={loading}>
                            Download complete list allocated numbers
                        </Button>
                        <CancelButton onClick={onClose}>Close</CancelButton>
                    </ButtonGroup>
                </RsuiteModal.Footer>
            </RsuiteModal>
    );
};

export default AllocationResult;


const List = styled(RsuiteList)`
    margin-top: 10px;
`;