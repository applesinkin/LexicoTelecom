import React from 'react';
import { Alert, Form, FormGroup,Input, InputNumber, FormControl, HelpBlock, ControlLabel, Button , SelectPicker, Checkbox, Schema} from 'rsuite';
import Tabs from './Tabs';
import MyForm from  '../../../../../components/MyForm';
import Text from  '../../../../../components/Form/Text';
import RateField from '../../../../../components/Form/RateField';
import {splitList} from '../../../../../utils';
import CustomField from  '../../../../../components/Form/CustomField';

export default  ({activeTab, setNumberList: _setNumberList, showResult, onSelect, target, setHideBufferButtons, ...props} )  => {
    let timerid = null;
    const [number_list, setNumberList] = React.useState([]);
    const changeNumberList = (str) =>{
        clearTimeout(timerid);

        timerid = setTimeout( (str) => {
            setNumberList(splitList(str));
        }, 300, str)
    };
    

return (
        <MyForm
            target={target}
            method="allocation:number_list"
            checkResultKey = 'price_range_number_list'
            update = { ({price_range_number_list}) => {
                showResult();
                _setNumberList(price_range_number_list || []);
                setHideBufferButtons(false);
            }}
            addData = {{number_list}}
            {...props}
        >
            <CustomField
                accepter={Input}
                errorPlacement="topRight"
                componentClass="textarea"
                name='number_list'
                onChange = {changeNumberList} 
                rows={3}
                style={{ width: 300, maxWidth: 650, height: 500, resize: 'auto'}}
                placeholder="Number list"
                useBr
            />
            <RateField label="Rate" name="rate" />
        </MyForm>
    )
};