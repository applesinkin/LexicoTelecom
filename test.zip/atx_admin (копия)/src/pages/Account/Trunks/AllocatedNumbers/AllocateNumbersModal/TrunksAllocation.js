import React, {useState} from 'react';
import {AddButton} from '../../../../../styled/Buttons';
import Modal from './Modal';

export default ({trunk_id, sp_key, update, onClose, forsed_open = false, account_id, disabled}) => {
    const [show, setShow] = useState(false);

    React.useEffect(() => {
        if (forsed_open) {
            setShow(true)
        }
    }, [forsed_open]);


    return (
        <div style={{float: 'right', marginTop: '-10px'}}>
            <AddButton disabled={!trunk_id || disabled} onClick={() => setShow(true)}>
                Allocate new Numbers
            </AddButton>
            <Modal
                show={show}
                trunk_id={trunk_id}
                disabledTrunk
                sp_key={sp_key}
                update={update}
                onClose={() => {
                    setShow(false);
                    onClose();
                }}
                account_id={account_id}
            />
        </div>
    );
}
