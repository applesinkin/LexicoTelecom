import React from 'react';
// import {Button} from 'rsuite';
// import TrunkModal from "./TrunkModal";
import AllocatedNumbers from './AllocatedNumbers/AllocatedNumbers';
import Trunks from './Trunks';
import {Header} from './styled';
import {Checkbox} from "rsuite";


export default  class  extends React.Component{
    state = {
        showAllocatedNumbersModal: false,
        trunk_id: null,
        showClosedTrunks: false,
        numbersTableReadonly: false
    };
    
    getNumbers = (group, filter, page, per_page, sort) => this.props.getNumbers(this.state.trunk_id, group, filter, page, per_page, sort)();
    setTrunk = (trunk_id) => {
        if (this.props.allocatedNumbersLoading) return;

        const activeTrunk = this.props.trunks.find((trunk) => trunk.id === trunk_id);
        const numbersTableReadonly = activeTrunk ? activeTrunk.closed: true;

        this.setState({trunk_id, numbersTableReadonly})
    };

    render () {
        const {showAllocatedNumbersModal} =  this.state;
        const { account, 
                trunks, trunksLoading, acc_key, getTrunks,
                allocatedNumbers, allocatedNumbersLoading, allocatedNumbersCount, allocatedNumbersPage, allocatedNumbersPerPage, setActiveTrunk  } = this.props;
        const { trunk_id} =  this.state;
        
        return (
            <>
                <Header>Trunks</Header>
                <div className="d-flex justify-content-end align-items-center" style={{position: 'absolute', right: 0,top: 114}}>

                    <Checkbox style={{marginRight: 0}}
                              onClick={() => {this.setState({showClosedTrunks: !this.state.showClosedTrunks})}}
                    />
                    <span style={{marginRight: 200}}>Show closed trunks</span>
                </div>
                <Trunks
                    trunk_id={trunk_id || trunks && trunks.length && trunks[0].id}
                    {...{
                        trunks: trunks.filter((trunk) => this.state.showClosedTrunks ? true : !trunk.closed),
                        trunksLoading,
                        allocatedNumbersLoading,
                        getTrunks,
                        acc_key
                    }}
                    onAllocateNumbers = {()=>this.setState({showAllocatedNumbersModal:true})}
                    getTrunks = {getTrunks}
                    setTrunk = {this.setTrunk}
                />
                <Header>Allocated numbers</Header>
                <AllocatedNumbers
                    {...{
                        allocatedNumbers,
                        allocatedNumbersLoading,
                        allocatedNumbersCount,
                        allocatedNumbersPage,
                        allocatedNumbersPerPage,
                        showAllocatedNumbersModal,
                        trunk_id,
                        trunksLoading,
                        trunks
                    }}
                    closeAllocatedNumbersModal = {()=>this.setState({showAllocatedNumbersModal:false})}
                    sp_key =  {(trunks.find(trunk => trunk.id === trunk_id) || {}).sp_key}
                    acc_key = {acc_key}
                    account_name = {account.name}
                    getNumbers = {this.getNumbers}
                    readonly = {this.state.numbersTableReadonly}
                />
            </>
        )
    }
}
