import React, {useState} from 'react';
import {Alert, Checkbox, DatePicker} from 'rsuite';
import ModalSendApi from '../../../components/Modal/ModalSendApi'
import ApiRequest from '../../../components/ApiRequest'
import {toEndDayUTCTime, toStartDayUTCTime, toUTCDateTime} from 'utils';


export default ({initialValues, target, getCount, entity, ...props}) => {
    const [endDate, setEndDate] = useState(null);
    const [withDate, setWithDate] = useState(false);

    return (
        <ModalSendApi 
            {...props}
            title="Revoke Number"
            successText="Yes"
            extraDisabled={withDate && !endDate}
        >
            <ApiRequest
                method="trunk_number__filter:revoke"
                checkResultKey = 'trunk_numbers'
                target= {target}
                update = { ({trunk_numbers}) => {
                    Alert.success(`Revoked ${trunk_numbers} numbers`)
                }}
                data={{
                    ...(endDate ? {end_date: endDate} : {}),
                    ...initialValues
                }}
            >
                <div>
                    <p>Selected <strong>{getCount()}</strong> {entity}(s) from this trunk will be revoked. Do you really want to do it?</p>
                    <div className="text-center mt-4">
                        <Checkbox inline className="mr-2" onChange={(v, checked) => {
                            setWithDate(checked);

                            if (!checked) {
                                setEndDate(null);
                            }
                        }}>From date</Checkbox>
                        <DatePicker placeholder="Enter Date" disabled={!withDate} onChange={(date) => {
                            date && setEndDate(toStartDayUTCTime(date));
                        }}/>
                    </div>
                </div>
            </ApiRequest>
        </ModalSendApi>
    );
};