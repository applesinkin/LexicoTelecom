import React from 'react';
import Table from '../../../components/Table';
import {AddButton as Add, AllocateTd, DeleteTd, DownloadTd, EditTd, RevokeTd} from '../../../styled/Buttons';
import {Table as _Table} from 'rsuite';
import TrunkModal from './TrunkModal/TrunkModal';
import {getFileResponse} from '../../../api/loginRoutes';
import {saveFileBlob} from '../../../utils/helpers';
import {HeaderTrunkActions} from './styled';
import RevokeTrunkModal from './RevokeTrunkModal';
import RemoveTrunkModal from './RemoveTrunkModal';
import {canIMoveNumbersToAnotherTrunk} from 'utils';

const {Column, HeaderCell, Cell} = _Table;

const columns = [
    {label: 'Name', dataKey: 'name'},
    {label: 'Type', dataKey: 'type'},
    {label: 'Price', dataKey: 'service_plan_name'},
    {label: 'Start Date', dataKey: 'start_date', formatData: 'date'},
    {label: 'End Date', dataKey: 'end_date', formatData: 'date'},
];

export default class extends React.Component {
    dataTrunk = {};
    state = {
        data: [],
        showModal: false,
        showRemoveTrunkModal: false,
        showRevokeTrunkModal: false
    };

    shouldComponentUpdate({trunks}) {
        if (trunks !== this.props.trunks) {
            this.setState({data: trunks});

            return false;
        }
        return true;
    }

    onEditTrunk = (rowData) => {
        this.dataTrunk = {...rowData};
        this.setState({showModal: true});
    };

    onDownloadNumbers = async (id) => {
        this.setState(({data, ...state}) => ({
            ...state, data: data.map(
                trunk => ({
                    ...trunk,
                    downloadLoading: trunk.id === id ? true : trunk.downloadLoading
                })
            )
        }));
        const {acc_key: account_id, trunk_id} = this.props;
        const result = await getFileResponse('trunk_number:get_list', {
            target: {account_id, trunk_id: id} //  trunk_id => id
        });
        if (result) saveFileBlob(result, 'allocated_numbers.csv');

        this.setState(({data, ...state}) => ({
            ...state, data: data.map(
                trunk => ({
                    ...trunk,
                    downloadLoading: trunk.id === id ? false : trunk.downloadLoading
                })
            )
        }));
    };
    onRevokeTrunk = () => this.setState({showRevokeTrunkModal: true});
    onRemoveTrunk = (rowData) => {
        this.dataTrunk = {...rowData};
        this.setState({showRemoveTrunkModal: true});
    };
    onClickTrunk = (id) => this.props.setTrunk(id);
    showTrunk = () => {
        this.dataTrunk = {};
        this.setState({showModal: true});
    };

    render() {
        const {
            onAllocateNumbers,
            trunks, trunksLoading, allocatedNumbersLoading, trunk_id, getTrunks, acc_key
        } = this.props;
        const {data, showModal, showRevokeTrunkModal, showRemoveTrunkModal} = this.state;

        const currentTrunk = this.props.trunks.find((trunk) => trunk.id === trunk_id);

        if (!data.length && trunks.length)
            this.setState({data: trunks});

        return (
            <div>
                <HeaderTrunkActions>
                    <Add onClick={this.showTrunk}>+Add New Trunk</Add>
                </HeaderTrunkActions>
                {showModal
                &&
                <TrunkModal
                    initialValues={this.dataTrunk}
                    account_id={acc_key}
                    update={getTrunks}
                    onClose={() => this.setState({showModal: false})}/>
                }

                <Table
                    data={data}
                    loading={trunksLoading || allocatedNumbersLoading}
                    columns={columns}
                    height={'25%'}
                    ActionCell={ActionCell(
                        this.onEditTrunk,
                        this.onDownloadNumbers,
                        onAllocateNumbers,
                        this.onRevokeTrunk,
                        this.onRemoveTrunk,
                    )}
                    active_id={trunk_id}
                    onRowClick={this.onClickTrunk}
                    rowClassName={
                        (rowData) => rowData && rowData.closed ? 'closed-row' : rowData && !rowData.active ? 'disabled--row' : ''
                    }
                />

                {showRevokeTrunkModal && <RevokeTrunkModal
                    account_id={acc_key}
                    trunk_id={trunk_id}
                    onClose={() => this.setState({showRevokeTrunkModal: false})}
                    update={getTrunks}/>
                }
                {showRemoveTrunkModal && <RemoveTrunkModal
                    account_id={acc_key}
                    trunk_id={trunk_id}
                    data={this.dataTrunk}
                    trunkList={data.filter(trunk => canIMoveNumbersToAnotherTrunk(currentTrunk, trunk))}
                    onClose={() => this.setState({showRemoveTrunkModal: false})}
                    update={getTrunks}/>
                }
            </div>
        );

    }
}


const ActionCell = (edit, download, allocate, revoke, remove) => (
    <Column flexGrow={1}>
        <HeaderCell>Options</HeaderCell>
        <Cell>
            {rowData => (
                <div style={{position: 'relative', 'top': '-2px'}}>
                    <EditTd onClick={() => edit(rowData)}/>
                    <DownloadTd loading={rowData.downloadLoading} onClick={() => download(rowData.id)}/>
                    <AllocateTd onClick={() => allocate(rowData.id)}/>
                    <RevokeTd onClick={() => revoke(rowData.id)}/>
                    <DeleteTd onClick={() => remove(rowData)}/>
                </div>
            )}
        </Cell>
    </Column>
);