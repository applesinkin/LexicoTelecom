import React, {useState} from 'react'
import Modal from '../../../../components/Modal';
import { api } from '../../../../api/loginRoutes';
import TrunkForm from "./TrunkForm";
import {toEndDayUTCTime, toUTCDateTime} from 'utils';

export default ({onClose, account_id, initialValues, update}) => {
    let form;
    let dialerForm;
    const [disabled, setDisabled ] = React.useState(false);
    
    const [is_default, onChangeDefault] = useState( initialValues.is_default_term_point !== undefined 
                                                    ? initialValues.is_default_term_point : true);

    const onSubmit = async() => {
        if(!form.check()) return;
        if(!is_default && !dialerForm.check()) return;

        setDisabled(true);
        
        const method = initialValues.id ? 'trunk:modify' : 'trunk:create';

        let _data = form.getFormValue();

        const data = {
            name: _data.name,
            sp_key: _data.sp_key,
            is_default_term_point: _data.is_default_term_point,
            prt_key: _data.prt_key || null,
            start_date: _data.start_date ? toUTCDateTime(new Date(_data.start_date)) : null,
            end_date: _data.end_date ? toEndDayUTCTime(new Date(_data.end_date)) : null,
            active: !!_data.active,
        };

        if(!is_default){
            _data = dialerForm.getFormValue();
            data.prt_key = _data.prt_key;
            data.ip = _data.ip;
            data.port = +_data.port;
            data.tprefix = _data.tprefix;
        }

        try {
            await api(method,{
                target:{
                    account_id,
                    trunk_id: _data.id
                },
                ...data,
                sp_key: _data.id ? undefined : data.sp_key
            });

            onClose();
            update();
        } catch (e) {
            console.log('Change trunk error');
        }

        setDisabled(false);
    };

    return (
        <Modal 
            {...{onClose}} 
            show={true} 
            onSuccess={onSubmit}
            disabled ={disabled}
            title="Create/Edit Trunk"
            footer
            successText = "Save"
            width={620}
        >
              <TrunkForm 
                  disabled = {disabled}
                  is_default = {is_default}
                  updateFormRef  = { ref => form = ref}
                  updateFormRef2 = { ref => dialerForm = ref}
                  onChangeDefault = {onChangeDefault}
                  initialValues ={initialValues}
            />    
        </Modal>
    )
};