import React, {useState} from 'react'
import Modal from '../../../components/Modal';
import {api} from '../../../api/loginRoutes';

export default ({onClose, update, account_id, trunk_id}) => {
    
    const [disabled, setDisabled ] = React.useState(false)

    const onSubmit = async () => {
        setDisabled(true)
        const result = await api('trunk:revoke_all_numbers',{
            target:{
                account_id,
                trunk_id
            }
        })
        if(result) {
            onClose();
            update()
        }
        setDisabled(false)
    }

    return (

        <Modal 
            show 
            onClose={onClose}
            footer
            successText = "Yes"
            onSuccess = {onSubmit}
            disabled = {disabled}
        >
            All numbers from this trunk will be revoked. Do you really want to do it?
        </Modal>
    )
};

