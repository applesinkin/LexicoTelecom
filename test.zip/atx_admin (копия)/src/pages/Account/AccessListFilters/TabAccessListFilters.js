import React from 'react';
import AccessList from './AccessList';
import {Header} from './styled';
import {Checkbox} from "rsuite";


export default  class  extends React.Component{
    render () {
        const { account_id, accessListLoading } = this.props;

        return (
            <>
                <Header>Access list mailing</Header>
                <AccessList {...{accessListLoading}} acc_key = {account_id} />
            </>
        )
    }
}
