import React from 'react';
import {Table as _Table} from 'rsuite';

// Utilities
import {saveFileBlob} from '../../../utils/helpers';

// API
import {getFileResponse} from '../../../api/loginRoutes';

// Components
import Table from '../../../components/Table/TableServerSort';
import {AddButton as Add, AllocateTd, DeleteTd, DownloadTd, EditTd, RevokeTd} from '../../../styled/Buttons';
import {HeaderTrunkActions} from './styled';
import CreateFilterForm from './CreateFilterForm';
import AccessListFilters from 'pages/Account/AccessListFilters/AccessListFilters';


const {Column, HeaderCell, Cell} = _Table;

const columns = [
    {label: 'Origin', dataKey: 'origin'},
    {label: 'Origin prefix', dataKey: 'origin_prefix'},
    {label: 'Destination', dataKey: 'destination'},
    {label: 'Minimal payout', dataKey: 'minimal_payout', formatData: 'date'},
];

export default class extends React.Component {
    
    dataTrunk = {};
    state = {
        data: [],
        showModal: false,
        showRemoveTrunkModal: false,
        showRevokeTrunkModal: false
    };

    onEditAccess = (id) => {

    };

    onRemoveAccess = (id) => {

    };

    onRemoveAccessOpenModal = (state) => {

    };

    shouldComponentUpdate({trunks}) {
        if (trunks !== this.props.trunks) {
            this.setState({data: trunks});

            return false;
        }
        return true;
    }

    render() {
        const {acc_key, accessListLoading} = this.props;
        const {data} = this.state;

        return (
            <div>
                
                <CreateFilterForm/>
                <AccessListFilters />
                <Table
                    data={data}
                    loading={accessListLoading}
                    columns={columns}
                    height={'25%'}
                    ActionCell={ActionCell(
                        this.onEditAccess,
                        this.onRemoveAccessOpenModal,
                    )}
                    onRowClick={this.onClickTrunk}
                    rowClassName={
                        (rowData) => rowData && rowData.closed ? 'closed-row' : rowData && !rowData.active ? 'disabled--row' : ''
                    }
                    ispagination
                    columnSelectorLSKey="AccessListTable"
                />
            </div>
        );

    }
}


const ActionCell = (edit, download, allocate, revoke, remove) => (
    <Column flexGrow={1}>
        <HeaderCell>Options</HeaderCell>
        <Cell>
            {rowData => (
                <div style={{position: 'relative', 'top': '-2px'}}>
                    <EditTd onClick={() => edit(rowData)}/>
                    <DownloadTd loading={rowData.downloadLoading} onClick={() => download(rowData.id)}/>
                    <AllocateTd onClick={() => allocate(rowData.id)}/>
                    <RevokeTd onClick={() => revoke(rowData.id)}/>
                    <DeleteTd onClick={() => remove(rowData)}/>
                </div>
            )}
        </Cell>
    </Column>
);