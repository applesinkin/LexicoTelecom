import React, {useState} from "react";
import { withRouter } from "react-router";
import { compose } from "redux";
import { connect } from "react-redux";

import { Form, Schema, SelectPicker, FormControl, Input, Button } from "rsuite";
import { api } from '../../../api/loginRoutes';


const CreateFilterForm = ({defaultFilters, ...props}) => {

    const form = React.createRef();

    const {StringType, NumberType} = Schema.Types;

    const formModel = Schema.Model({
        a_sde_key: StringType().isRequired("Required"),
        b_sde_key: StringType().isRequired("Required"),
        a_prefix: StringType().isRequired("Required"),
        rate_min: NumberType().isRequired("Required").isInteger("Must be Integer"),
    });
    
    const defaultValues = {};
    const [fields, setFields] = useState(defaultValues);
    const handleChange = (formValues) => {
        console.log(formValues);

        setFields(formValues)
    };
    
    const account_id = props.match.params.id;

    const handleSubmit = (e) => {
        e.preventDefault();
        form.current.check();
        let data = form.current.getFormValue();

        return;
        api("access_list_filter:create", {
            target:{
                account_id
            },
            ...data,
            rate_min: +data.rate_min
        });
    };

    return(
        <>
            <Form 
                onSubmit={handleSubmit}
                ref={form}
                model={formModel}
                onChange={handleChange}
                formDefaultValue={fields} 
                layout="inline"
                style={{margin: '0px', width: '100%'}}
            >

                <FormControl
                    accepter={SelectPicker}
                    data={props.subdestinationList}
                    name="a_sde_key"
                    placeholder="Origin"
                    valueKey="sde_key"
                    labelKey="name"
                />

                <FormControl
                    accepter={SelectPicker}
                    data={props.subdestinationList}
                    name="b_sde_key"
                    placeholder="Destination"
                    valueKey="sde_key"
                    labelKey="name"
                />

                <FormControl
                    accepter={Input}
                    name="a_prefix"
                    placeholder="Origin Prefix"
                    type="text"
                />

                <FormControl
                    accepter={Input}
                    name="rate_min"
                    placeholder="Minimal payout"
                    type="text"
                />

                <Button type="submit" appearance="primary">Create Filter</Button>

            </Form>
        </>
    )
}

const mapStateToProps = ({references}) => {
    return {
        subdestinationList: references.subdestination_list
    }
}

export default compose(
    connect(mapStateToProps),
    withRouter,
)(CreateFilterForm);