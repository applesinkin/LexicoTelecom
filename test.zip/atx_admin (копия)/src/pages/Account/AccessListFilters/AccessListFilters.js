import React, {useState} from 'react';
import {Form, Schema, SelectPicker} from 'rsuite';
import FormHOC from '../../../hoc/FilltersForm';
import ServicePlans from '../../../components/Filters/ServicePlans';
import Text from '../../../components/Form/Text';
import {ControlLabel, FormControl, FormGroup, Checkbox} from 'rsuite/es';
import CustomField from 'components/Form/CustomField';
import GreenButton from 'styled/GreenButton';
import {removeNilValues} from 'utils';

const { StringType } = Schema.Types;

const filtersModel = Schema.Model({
        str: StringType().maxLength(40, 'Max characters 40'),
    }
);

export default FormHOC( ({ onChange, onApplyFilters, defaultFilters, loading, ...props}) => {
    const [topFilters, setTopFilters] = useState(defaultFilters);
    const [bottomFilters, setBottomFilters] = useState(defaultFilters);

    const handleChange = (formValues, setState) => {setState(formValues)};

    const handleApply = () => {onApplyFilters({...bottomFilters, ...topFilters})};

    return (
        <>
            <Form
                onChange={(value)=>handleChange(value, setTopFilters)}
                formDefaultValue = {defaultFilters}
                layout="inline"
                style = {{marginBottom: '-10px'}}
            >
                <Checkbox name="daily" inline> daily</Checkbox>
                <FormGroup>
                    <ControlLabel> for price</ControlLabel>
                    <ServicePlans filtered style={{marginLeft: '12px'}}/>
                </FormGroup>
                <FormGroup>
                    <ControlLabel> during </ControlLabel>
                    <FormControl
                        name="during"
                        accepter={SelectPicker}
                        labelKey = "dr_name"
                        valueKey = "dr_key"
                        placeholder="Timing"
                        style={{width: '180px'}}
                        searchable={false}
                    />
                </FormGroup>
                <FormGroup>
                    <ControlLabel> type </ControlLabel>
                    <FormControl
                        name="during"
                        accepter={SelectPicker}
                        labelKey = "tp_name"
                        valueKey = "tp_key"
                        placeholder="Type"
                        style={{width: '180px'}}
                        searchable={false}
                    />
                </FormGroup>
                <FormGroup>
                    <GreenButton style={{padding: '8px 34px', marginLeft: 12}}
                                 onClick={handleApply}
                                 disabled={loading}
                    >
                        Apply Filters
                    </GreenButton>
                </FormGroup>
            </Form>
            <Form
                model={filtersModel}
                onChange={(value) => {
                    handleChange(value, setBottomFilters);
                    onChange({...topFilters, ...bottomFilters})
                }}
            >
                <FormGroup  style={{display: 'flex', alignItems: 'center'}}>
                    <Checkbox name="appearance" style={{marginRight: '12px'}}> per appearance for filtered destinations</Checkbox>
                    <Text name="str" placeholder="Origin/origin prefix/destination" style={{display: 'inline-block'}}/>

                </FormGroup>
            </Form>
        </>
    )
}, filtersModel, 500);