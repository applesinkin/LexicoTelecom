import React from 'react';
import {
  Badge,
  Button,
  ButtonToolbar,
  Container,
  Content,
  ControlLabel,
  FlexboxGrid,
  Form,
  FormControl,
  FormGroup,
  Header,
  Icon,
  Nav,
  Navbar,
  Panel,
  Schema
} from 'rsuite';
import SUser from '../../styled/MenuUserInfo';
import SCompany from '../../styled/MenuCompanyInfo';
import VersionLabel from 'components/VersionLabel/VersionLabel';
import {connect} from 'react-redux';
import {checkLogin} from 'actions/auth';
import {Link} from 'react-router-dom';

const {StringType, NumberType, ArrayType} = Schema.Types;

export const loginModel = Schema.Model({
  email: StringType().isRequired('Required').isEmail('Email required'),
  password: StringType().isRequired('Required'),
});

export const secondAuthModel = Schema.Model({
  second_password: StringType().isRequired('Required').maxLength(8, 'The maximum of this field is 8 characters')
});

const styleContainer = {
  minHeight: '100vh'
};
const stylePanel = {
  marginTop: '15vh'
};
const styleLogo = {
  maxHeight: '100%'
};


const Login = ({checkLogin, loading, secondAuthType, secondAuthLink, secondAuthEmail}) => {
  let form;

  let {account_name, name, email} = localStorage.getItem('userInfo') && JSON.parse(localStorage.getItem('userInfo')) || {};

  const submit = () => {
    if (form.check()) {
      checkLogin(form.getFormValue());
    }
  };

  return (
      <Container style={styleContainer}>
        <Header>
          <Navbar appearance="inverse">
            <Navbar.Header>
              {
                account_name && name &&
                <SUser>
                  <SCompany>
                    <Badge
                        style={{marginRight: '2px', width: '4px', height: '4px', position: 'relative', top: '-4px'}}/>
                    {account_name}
                  </SCompany>
                  {name}
                </SUser>
              }

            </Navbar.Header>
            <Navbar.Body>
              <Nav pullRight>
                < Nav.Item icon={<Icon icon="sign-in"/>}>Log in</Nav.Item>
              </Nav>
            </Navbar.Body>
          </Navbar>
        </Header>
        <Content>
          <FlexboxGrid justify="center">
            <FlexboxGrid.Item colspan={12}>
              <Panel header={<h3>Login</h3>} style={stylePanel} bordered>
                {!secondAuthType && <Form
                    fluid
                    ref={ref => (form = ref)}
                    formDefaultValue={{email}}
                    model={loginModel}
                >
                  <FormGroup>
                    <ControlLabel>Email address</ControlLabel>
                    <FormControl autoFocus={!email} name="email"/>
                  </FormGroup>
                  <FormGroup>
                    <ControlLabel>Password</ControlLabel>
                    <FormControl autoFocus={!!email} name="password" type="password"/>
                  </FormGroup>
                  <FormGroup>
                    <ButtonToolbar>
                      <Button appearance="primary" onClick={submit} type="submit" disabled={loading}>Sign in</Button>
                      <Link to="/reset-password">Forgot password?</Link>
                    </ButtonToolbar>
                  </FormGroup>
                </Form>}
                {secondAuthType && <Form
                    ref={ref => (form = ref)}
                    formDefaultValue={{email: secondAuthEmail}}
                    model={secondAuthModel}
                    style={{display: 'block'}}
                >
                  <div className="alert alert-warning" role="alert">
                    Your account is under two factor authentication, please enter code which we sent to
                    your {secondAuthType} <b>{secondAuthLink}</b>
                  </div>

                  <FormControl name="email" hidden={true}/>

                  <FormControl
                      style={{
                        display: 'block',
                        width: '100%',
                        marginBottom: '20px'
                      }}
                      autoFocus={true}
                      placeholder="Enter your code here"
                      name="second_password"
                  />
                  <FormGroup>
                    <ButtonToolbar>
                      <Button appearance="primary" onClick={submit} type="submit" disabled={loading}>Confirm</Button>
                    </ButtonToolbar>
                  </FormGroup>
                </Form>}
              </Panel>
            </FlexboxGrid.Item>
          </FlexboxGrid>
        </Content>
        <VersionLabel/>
      </Container>
  );
};

const mapState = ({auth}) => ({
  loading: auth.loading,
  secondAuthType: auth.secondAuthType,
  secondAuthLink: auth.secondAuthLink,
  secondAuthEmail: auth.secondAuthEmail,
});

export default connect(mapState, {checkLogin})(Login);