import React from 'react';
import {FlexboxGrid, Button} from 'rsuite'
import Header from '../../styled/PageHeader'
import AccessListFilters from './AccessListFilters'
import AccessListTable from './AccessListTable'
import PanelLayout from '../../styled/PanelLayout';
import ExportCsv from '../../components/ExportCsv';
import {connect} from "react-redux";
import {getAccessList} from "../../actions/access_list";

class AccessList extends React.Component {
    constructor(props) {
        super(props);

        this.filters = {
            str: '',
            sp_key: props.defaultSPKey
        };

        this.state = {
            sort: {}
        }
    }

    componentDidMount() {
        const {getAccessList, per_page} = this.props;
        getAccessList(this.filters, 1, per_page, this.state.sort);
    }

    onChangeFilters = (filtersObj) => {
        const {getAccessList, per_page} = this.props;
        this.filters = filtersObj;
        getAccessList(this.filters, 1, per_page, this.state.sort);
    };

    getItems = (page, per_page, sort) => {
        const { getAccessList } = this.props;
        getAccessList(this.filters, page, per_page, sort);
    };

    render () {
        const {accessList, accessListLoading, page, count, per_page} = this.props;

        return (
            <PanelLayout>
                <Header>
                    <FlexboxGrid.Item colspan={22}>
                        Access List
                    </FlexboxGrid.Item>
                    <FlexboxGrid.Item colspan={2} style={{textAlign:'right'}} >
                        <ExportCsv
                            method = 'access_list__get_list'
                            params = {{filter: this.filters}}
                            title = 'Download'
                            fileName = 'accesses_list.csv'
                            style = {{position: 'relative', right: 5}}
                        />
                    </FlexboxGrid.Item>
                </Header>
                <FlexboxGrid >
                    <FlexboxGrid.Item colspan={24}>
                        <AccessListFilters 
                            onChange = {this.onChangeFilters}
                            defaultFormValue = {this.filters}
                            />
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                
                <AccessListTable 
                    {...{
                        accessList,
                        accessListLoading,
                        page, 
                        count,
                        per_page
                    }}
                    getItems = {this.getItems}
                    onSort={(column, type) => this.setState({sort: {column, type}})}
                />
                
            </PanelLayout>
        )
    }
}

const mapState = ( {access_list, references} )=> ({
    accessList: access_list.items,
    count: access_list.count,

    accessListLoading: access_list.loading,
    page: access_list.page,
    per_page: access_list.per_page,
    defaultSPKey: references.defaultSPKey
});

export default connect(mapState, {
    getAccessList
})(AccessList);