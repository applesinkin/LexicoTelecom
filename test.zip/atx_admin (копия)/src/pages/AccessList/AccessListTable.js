import React from 'react';
import TableServerSort from '../../components/Table/TableServerSort';

const columns = [
    {label: 'Access origin', dataKey: 'a_subdestination_name', sortable: true},
    {label: 'CLI', dataKey: 'a_number', sortable: true},
    {label: 'Access destination', dataKey: 'b_subdestination_name', sortable: true},
    {label: 'Test number', dataKey: 'b_number', sortable: true},
];


export default ({ accessList = [], getItems, accessListLoading = false, page = 1, count = 0 , per_page, ...props}) => (
    <TableServerSort
        data={accessList}
        loading={accessListLoading}
        columns = {columns}
        count = {count}
        per_page = {per_page}
        page = {page}
        getItems = {getItems}
        ispagination
        {...props}
    />   
)

