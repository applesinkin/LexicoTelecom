import React from 'react';
import {Form, Schema} from 'rsuite';
import FormHOC from '../../hoc/FilltersForm';
import ServicePlans from '../../components/Filters/ServicePlans';
import Text from '../../components/Form/Text';

const { StringType } = Schema.Types;

const filtersModel = Schema.Model({
    str: StringType().maxLength(40, 'Max characters 40'),
    }
);

export default FormHOC( ({ onChange, defaultFormValue }) => {    
    return (
        <Form model={filtersModel}
              onChange={onChange}
              formDefaultValue = {defaultFormValue}
              layout="inline"
              style = {{marginBottom: '-10px'}}
              >
                <ServicePlans filtered/>
                <Text name="str" placeholder="Filter per origin, CLI"/>
        </Form>
    )
},filtersModel, 500)