import React, {useState} from 'react';
import Header from "../../styled/PageHeader";
import {FlexboxGrid} from "rsuite";
import ExportCsv from "../../components/ExportCsv";
import PanelLayout from "../../styled/PanelLayout";
import TrafficReportsTable from "pages/TrafficReports/TrafficReportsTable";
import {TRAFFIC_REPORTS_METHOD} from "const/apiMethods";
import TrafficReportsFilters from "pages/TrafficReports/TrafficReportsFilters";


const TrafficReportsPage = () => {
    const today = new Date(Date.now());
    const [filters, setFilters] = useState({range:[today, today], group_checkbox: ['originator_key']});

    return (
        <PanelLayout>
            <Header>
                <FlexboxGrid.Item colspan={21}>Traffic Reports</FlexboxGrid.Item>
                <FlexboxGrid.Item colspan={3} style={{textAlign:'right'}}>
                    <ExportCsv
                        method = {TRAFFIC_REPORTS_METHOD}
                        params = {{filter: filters}}
                        title = 'Export CSV'
                        fileName = 'traffic_report.csv'
                        style = {{position: 'relative', right: 5}}
                    />
                </FlexboxGrid.Item>
            </Header>
            <FlexboxGrid >
                <FlexboxGrid.Item colspan={24}>
                    <TrafficReportsFilters onApplyFilters={(filters) => {setFilters(filters)}} defaultFilters={filters}/>
                </FlexboxGrid.Item>
            </FlexboxGrid>
            <TrafficReportsTable filters={filters} />
        </PanelLayout>
    );
};

export default TrafficReportsPage;