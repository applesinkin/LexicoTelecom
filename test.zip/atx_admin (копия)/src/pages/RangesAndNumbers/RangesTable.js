import React from 'react';
import {Table, IconButton, Icon, Checkbox} from 'rsuite';
import RenderedColumns from '../../components/Table/RenderColumns';
// import Edit from '../../styled/EditButton';

const { Column, HeaderCell, Cell } = Table;

const columns = RenderedColumns([
    {label: 'Range', dataKey: 'name'},
    {label: 'Test numbers', dataKey: 'test_number'},
    {label: 'Numbers', dataKey: 'numbers'}
]);

export default ({data = [], loading, onRowClick}) => {
    return (
        <Table
            height={ ((data.length * 30) || 100) + 50}
            data={data}
            loading={loading}
            rowHeight={30}
            width={600}
            onRowClick={ ({pr_key}) => onRowClick(pr_key)}
        >
            {columns}
            <Column width={50   }>
                <HeaderCell/>
                <Cell>
                    <Checkbox style={{position:'relative', top:'-5px'}} />
                </Cell>
            </Column>
        </Table>
    );
};

