import React, {useEffect} from 'react';
import ReactDOM from 'react-dom';
import Delete from '../../styled/CloseButton';
import ModalSendApi from '../../components/Modal/ModalSendApi';
import ApiRequest  from '../../components/ApiRequest';
import {Alert, Tag, Tree} from 'rsuite';
import {api} from "api/loginRoutes";
import Loader from "components/Loader/Loader";

export default ({getList, disabled, update}) => {
    const [show, setShow] = React.useState(false);
    const [loading, setLoading] = React.useState(false);
    const [rangesToDelete, setRangesToDelete] = React.useState([]);

    useEffect(() => {
        if (show) {
            const keys = getList().list.map((range) => range.pr_key);

            setLoading(true);

            api('price_range__get_list_with_account_trunk_numbers_list', {pr_key_list: keys})
                .then((resp) => {
                    const tree = resp.price_range_list.map((range) => {
                        const trunks = range.dialer_allocated_numbers_list.map((dialer) => ({
                            value: dialer.trunk_name,
                            label: <div>
                                <div className="float-left">
                                    Dialer: {dialer.account_name}
                                </div>
                                <div className="float-right">
                                    <Tag color="green">{dialer.numbers} numbers</Tag>
                                </div>
                            </div>,
                        }));
                        return {
                            value: range.id,
                            label: <div data-range-id={range.id} onClick={() => {
                                changeExpandTree(range.id);
                            }}>
                                <div className="float-left">Range: {range.name}</div>
                                <div className="float-right">
                                    <Tag color="orange">{range.dialer_allocated_numbers_list.length} dialers</Tag>
                                    <Tag color="green">{range.all_numbers} numbers</Tag>
                                </div>
                            </div>,
                            children: trunks.length ? trunks : null
                        }
                    });

                    setRangesToDelete(tree);
                }).finally(() => {
                    setLoading(false);
                });
        }
    }, [show]);

    const changeExpandTree = (rangeId) => {
        const node =  document.getElementsByClassName('rs-tree-node-children');
        if (node && node.length) {
            for (const treeNode of node) {
                const icon = treeNode.getElementsByClassName('rs-tree-node-expand-icon');
                const iconNode = icon && icon.length && icon[0];
                const nodeByRangeId = treeNode.querySelector(`[data-range-id='${rangeId}']`);
                if (treeNode && nodeByRangeId) {
                    if (treeNode.classList.contains('rs-tree-open')) {
                        treeNode.classList.remove('rs-tree-open');
                        iconNode.classList.remove('rs-tree-node-expanded');
                    } else {
                        treeNode.classList.add('rs-tree-open');
                        iconNode.classList.add('rs-tree-node-expanded');
                    }
                }
            }
        }
    };

    return (
        <>
            <Delete disabled={disabled} onClick={() => setShow(true)} >- Delete ranges</Delete>
            { show &&
            <ModalSendApi
                title="Delete Range"
                successText="Confirm"
                onClose={() => setShow(false)}
                update={update}
            >
                <ApiRequest
                    method="price_range__delete"
                    checkResultKey = 'ranges'
                    update = { ({ranges}) => {
                        Alert.success(`Removed ${ranges} ranges`)
                    }}
                    data={{pr_key_list: getList().list.map(x => x.pr_key)}}
                    // style={{maxHeight: '200px'}}
                >
                    <Loader show={loading} isLocal/>
                    <h6 className="text-center"> Selected range allocated to following dialers</h6>
                    <Tree data={rangesToDelete} />
                    <h6 className="text-center">All numbers will be revoked.</h6>
                </ApiRequest>
            </ModalSendApi>
        }
        </>
        
    );
}