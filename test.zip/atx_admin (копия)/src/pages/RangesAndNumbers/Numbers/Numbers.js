import React from 'react';
import Filters from './NumbersFilters';
import TableServerSort from '../../../components/Table/TableServerSort';
import Revoke from './Revoke';
import Allocate from './Allocate';
import SetOrUnsetTest from './SetOrUnsetTest';
import Block from 'pages/RangesAndNumbers/Numbers/Block';
import Unblock from 'pages/RangesAndNumbers/Numbers/Unblock';
// import styled from 'styled-components';
// import Pagination from "../../../components/Pagination";


const columns = [
    {label: 'Number', dataKey: 'number', sortable: true, width: 260},
    {label: 'Allocated to and trunk', dataKey: 'trunk_name', sortable: true}
];

export default class Numbers extends React.Component {
    filters = {show_allocated_numbers: true, show_unallocated_numbers: true, show_test_numbers: true, show_block_allocation_numbers: true, show_only_block_allocation_numbers: false};
    state = {
        selected: {all: false, list: []},
        sort: {}
    };
    /** @type MyTable */
    tableRef = null;

    getFilters = () => ({...this.filters});
    getSelectedList = () => ({...this.state.selected, countAll: this.props.numbersCount});

    getNumbers = (page, per_page, sort) => {
        this.props.getNumbers(this.filters, page, per_page, sort);
    };

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (!this.props.numbers.length && prevProps.numbers !== this.props.numbers) {
            this.clearSelected();
        }
    }

    onChangeFilters = (filters) => {
        this.filters = filters;
        this.props.getNumbers(this.filters, 1, this.props.numbersPerPage, this.state.sort);
        this.clearSelected();
    };

    clearSelected() {
        this.setState({selected: {all: false, list: []}});
        this.tableRef.clear();
    }

    render() {
        const {
            numbers, numbersLoading, numbersPage, numbersCount, numbersPerPage
        } = this.props;
        const {
            selected
        } = this.state;
        console.log(numbers);

        const includedNumber = selected.list.length && numbers.filter(number => selected.list.includes(number.prn_key));
        const disabledBlockedNumbersButtonSign = includedNumber && includedNumber.some(number => number.trunk_name === "blocked");

        return (
            <div style={{marginLeft: 20}}>
                <div style={{marginBottom: 25, textAlign: 'right'}}>
                    <Revoke
                        disabled={!selected.list.length}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}

                    />
                    <Allocate
                        disabled={!selected.list.length || disabledBlockedNumbersButtonSign}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}

                    />
                    <SetOrUnsetTest
                        disabled={!selected.list.length || disabledBlockedNumbersButtonSign}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}
                        isSetTest={true}
                    />
                    <SetOrUnsetTest
                        disabled={!selected.list.length || disabledBlockedNumbersButtonSign}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}
                        isSetTest={false}
                    />
                    <Block
                        disabled={!selected.list.length}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}
                    />
                    <Unblock
                        disabled={!selected.list.length}
                        getList={this.getSelectedList}
                        update={() => {
                            this.props.getNumbers(this.filters, 1, numbersPerPage);
                            this.tableRef.clear();
                        }}
                    />
                </div>
                <Filters
                    onChange={this.onChangeFilters}
                />
                <TableServerSort
                    ref={ref => this.tableRef = ref}
                    data={numbers}
                    loading={numbersLoading}
                    columns={columns}
                    count={numbersCount}
                    per_page={numbersPerPage}
                    page={numbersPage}
                    getItems={this.getNumbers}
                    row_key="prn_key"
                    setSelected={selected => {
                        console.log(selected);
                        let includeNumbers = selected.list.length && numbers.filter(number => selected.list.includes(number.prn_key));
                        console.log(includeNumbers);
                        console.log(includeNumbers && includeNumbers.some(number => number.blocked));
                        this.setState({selected})
                    }}
                    ispagination
                    isselected
                    onSort={(column, type) => this.setState({sort: {column, type}})}
                />
            </div>
        );

    }
}


