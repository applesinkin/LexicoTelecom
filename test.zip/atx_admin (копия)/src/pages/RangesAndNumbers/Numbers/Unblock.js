import React from 'react';
import GreenButton from 'styled/GreenButton';
import Modal from '../../../components/Modal';
import {api} from '../../../api/loginRoutes';
import {Alert, Schema} from 'rsuite';
import Icon from 'rsuite/es/Icon';

const {NumberType, StringType} = Schema.Types;

export default ({getList, disabled, update}) => {
    const [show, setShow] = React.useState(false);
    const [_disabled, setDisabled] = React.useState(false);

    // eslint-disable-next-line react-hooks/exhaustive-deps

    const onSubmit = async () => {
        setDisabled(true);
        const numbersKeysList = getList().list;

        const result = await api('price_range_number:unset_block_allocation_list', {
            prn_key_list: numbersKeysList
        });

        if (result && result.price_range_numbers) {
            Alert.success(`${result.price_range_numbers} number were unblocked`);
            setShow(false);
            update();
        }
        setDisabled(false);

    };
    return (
        <>
            <GreenButton disabled={disabled} onClick={() => setShow(true)} className="mr-3">
                <Icon icon="unlock-alt"/> Unblock</GreenButton>
            {show && <Modal
                show={show}
                title="Allocate numbers"
                onClose={() => setShow(false)}
                footer={true}
                successText="Confirm"
                disabled={_disabled}
                onSuccess={onSubmit}
            >
                Selected numbers will be set as free. You can allocate them or set test in future
            </Modal>
            }
        </>

    );
}
