import React, {useState} from 'react';
import Revoke from '../../../styled/CloseButton';
import Modal from '../../../components/Modal';
import { api } from '../../../api/loginRoutes';
import {Alert, Checkbox, DatePicker} from 'rsuite';
import {toUTCDateTime} from "utils";

export default ({getList, disabled, update}) => {
    const [show, setShow ] = React.useState(false)
    const [_disabled, setDisabled ] = React.useState(false)
    const [date, setDate] = useState(null);
    const [withDate, setWithDate] = useState(false);


    const onSubmit = async () => {
        setDisabled(true);
        const numbersKeysList = getList().list;

        const result = await api('price_range_number:revoke_list',{
            prn_key_list: numbersKeysList,
            end_date: date
        });

        if (result && result.price_range_numbers) {
            Alert.success(`Generated ${result.price_range_numbers} numbers`)
            setShow(false);
            update();
        } else {
            Alert.warning(
        `${numbersKeysList.length > 1 ? 'These numbers' : 'This number'} can't be revoked`
            );
            setShow(false);
            update();
        }

        setDisabled(false)
    };

    const selectedCount = () => {
        const data = getList();
        
        if(data.all)
            return data.countAll;
        return data.list.length;
    };

    return (
        <>
            <Revoke disabled={disabled} onClick={() => setShow(true)} className="mr-3">Revoke</Revoke>
            { show && <Modal
                show = {show}
                title = "Revoke numbers"
                onClose  = {() => setShow(false)}
                footer = {true}
                successText = "Yes"
                disabled = {_disabled}
                onSuccess  = {onSubmit}
            >
                Selected {selectedCount()} numbers from this range will be revoked. 
                Do you really want to do it?
                <div className="text-center mt-4">
                    <Checkbox inline className="mr-2" onChange={(v, checked) => {
                        setWithDate(checked);

                        if (!checked) {
                            setDate(null);
                        }
                    }}>From date</Checkbox>
                    <DatePicker placeholder="Enter Date" disabled={!withDate} onChange={(date) => {
                        date && setDate(toUTCDateTime(date));
                    }}/>
                </div>
            </Modal>
        }
        </>
        
    );
}