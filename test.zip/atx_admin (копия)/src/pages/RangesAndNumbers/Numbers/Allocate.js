import React from 'react';
import GreenButton from 'styled/GreenButton';
import Modal from '../../../components/Modal';
import { api } from '../../../api/loginRoutes';
import { Alert, Form , Schema, InputNumber,SelectPicker} from 'rsuite';
import CustomField from '../../../components/Form/CustomField'
import RateField from "../../../components/Form/RateField";

const {NumberType, StringType} = Schema.Types;

export default ({getList, disabled, update}) => {
    const [show, setShow ] = React.useState(false);
    const [_disabled, setDisabled ] = React.useState(false);
    const [dialers, setDialers ] = React.useState([]);
    let formRef = null;

    // eslint-disable-next-line react-hooks/exhaustive-deps
    React.useEffect( () => {
        api('trunk_list_for_accounts').then( ({trunk_list}) => {
            setDialers((trunk_list || []).map(x =>({
                ...x,
                _name:`${x.acc_name}\\${x.tr_name}\\${x.sp_name}`
            })))
        })
    }, [])

    const onSubmit = async () => {
        if(formRef.check()){
            setDisabled(true) 
            const data = formRef.getFormValue();

            const result = await api('allocation:price_range_number_list',{
                target: {
                    trunk_id: data.trunk_id,
                },
                prn_key_list: getList().list,
                rate: +data.rate
            })

            if (result && result.price_range_number_list) {
                Alert.success(`Allocated ${result.price_range_number_list.length} numbers`)
                setShow(false);
                update();
            }
            setDisabled(false)
        }
    }
    return (
        <>
            <GreenButton disabled={disabled} onClick={() => setShow(true)} className="mr-3">Allocate</GreenButton>
            { show && <Modal
                show = {show}
                title = "Allocate numbers"
                onClose  = {() => setShow(false)}
                footer = {true}
                successText = "Confirm"
                disabled = {_disabled}
                onSuccess  = {onSubmit}
            >
             Choice dialer and trunk. Pay your attention - if they are allocated to any dialer they will be revoked from them too.   
            <AllocateForm  
                dialers_trunk_list={dialers} 
                disabled={disabled}
                updateFormRef = {ref => formRef = ref} 
            />
            </Modal>
        }
        </>
        
    );
}


const formModel = Schema.Model({
    trunk_id: StringType().isRequired('Required'),
    rate: NumberType().isRequired('Required'),
});

const AllocateForm  =  ({disabled, dialers_trunk_list, updateFormRef}) => {
   
    return (

        <Form layout="inline"
            model={formModel}
            ref= {updateFormRef}
        >
            <CustomField
                disabled = {disabled}
                accepter={SelectPicker}
                data={dialers_trunk_list}
                cleanable={false}
                labelKey="_name"
                valueKey="tr_uuid"
                placeholder="Trunk"
                name="trunk_id"
                classPrefix="minWidth"
            />
            <br/>
            <RateField
                name="rate"
                label="Rate"
            />
         </Form>
    );
};
