import React, {useState} from 'react';
import Header from "../../styled/PageHeader";
import {FlexboxGrid} from "rsuite";
import ExportCsv from "../../components/ExportCsv";
import PanelLayout from "../../styled/PanelLayout";
import CDRTable from "./CDRTable";
import CDRFilters from "pages/CDR/CDRFilters";


const CDRPage = () => {
    const today = new Date();
    const [filters, setFilters] = useState({range:[today, today]});

    return (
        <PanelLayout>
            <Header>
                <FlexboxGrid.Item colspan={21}>CDR</FlexboxGrid.Item>
                <FlexboxGrid.Item colspan={3} style={{textAlign:'right'}}>
                    <ExportCsv
                        method = 'cdr_full:get_list_admin'
                        params = {{filter: filters}}
                        title = 'Export CSV'
                        fileName = 'crd.csv'
                        style = {{position: 'relative', right: 5}}
                    />
                </FlexboxGrid.Item>
            </Header>
            <FlexboxGrid >
                <FlexboxGrid.Item colspan={24}>
                    <CDRFilters onApplyFilters={(filters) => {setFilters(filters)}} defaultFilters={filters}/>
                </FlexboxGrid.Item>
            </FlexboxGrid>
            <CDRTable filters={filters} />
        </PanelLayout>
    );
};

export default CDRPage;