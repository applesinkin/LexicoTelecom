import React from 'react';
import {Input, Form, Button, IconButton, Icon, CheckPicker, Message, Schema } from 'rsuite';
import CustomField from './ContactCustomField';
import {AddButton, BorderBtn} from '../../styled/Buttons';
import Modal from '../../components/Modal';
import RemoveListButton from '../../styled/RemoveListButton';

const { StringType, NumberType, ArrayType } = Schema.Types;

const passwordRegExp =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d#?!_@$%^&*-]{8,}$/; 

export const userModel = Schema.Model({
    name: StringType().isRequired('Required').maxLength(40, 'The maximum is only 40 characters.'),
    login: StringType().isRequired('Required').maxLength(40, 'The maximum is only 40 characters.'),
    email: StringType().isRequired('Required').isEmail('Email required'),
    password: StringType()
        .maxLength(40, 'The maximum is only 40 characters.')
        .addRule( value =>passwordRegExp.test(value) , 'Please enter legal characters'),
})

const passwordModel = Schema.Model({
    password: StringType()
        .isRequired('Required')
        .maxLength(40, 'The maximum is only 40 characters.')
        .addRule( value => passwordRegExp.test(value) , 'Please enter legal characters'),
    confirm_password: StringType()
        .isRequired('Required')
        .addRule( (value, data) => data.password === value , 'Password dosn\'t match'),
});


// export const initUser = {name:'',login:'',email:'', password: null, key: null} 

export const initUser = {name:'',login:'',email:'', key: null} 

export default ( {disabled, users, updateUsers, formsRef, updateFormRef} ) => {

    let passwordRef = {};
    
    const [passwordModal, setShowPasswordModal] = React.useState(false);
    const [errorsPasswordForm, setErrorsPasswordForm] = React.useState({
       password: null,
       confirm_password: null
    });
    const [password_key, setPassword_key] = React.useState(null);

    const updateFormValues = (formValues, key) => {
        updateUsers([
                ...users.map( user => 
                    user.key === key 
                    ?
                    {...user, ...formValues} : user
                )
            ])
    }
    const onRemove = (key) => {
        updateUsers( users.filter( user => user.key !== key ) )
    }

    const onShowPasswordModal = (key) => {
        setShowPasswordModal(true);
        setPassword_key(key);
        setErrorsPasswordForm({
            password: null,
            confirm_password: null
        })
    } 

    const onCloseModal = () => {
        setShowPasswordModal(false)
    }
    const setPassword = () => {
        if(!errorsPasswordForm.password && !errorsPasswordForm.confirm_password){

            const password = passwordRef.getFormValue().password;
            updateUsers([
                ...users.map( user => 
                    user.key === password_key
                    ?
                    {...user, password} : user
                )
            ])
            onCloseModal()
        }
    }

    const onChangePasswordForm = () => {
        setTimeout( (passwordRef) => {
            const status = passwordModel.check(passwordRef.getFormValue());
            const password = status.password.hasError ?  status.password.errorMessage : null;
            const confirm_password = status.confirm_password.hasError ?  status.confirm_password.errorMessage : null;
            setErrorsPasswordForm({
                password,
                confirm_password
            })
        }, 100, passwordRef)
    };

    return (
        <>
        { users.map(
            (user, i) => 
                <Form  
                    layout="inline"
                    key={user.key}
                    ref= { ref => updateFormRef(ref, user.key)}
                    onChange = { (formValues) =>  updateFormValues(formValues, user.key)}
                    formDefaultValue = {user}
                    model = {user.email_disabled ? Schema.Model({}) :userModel}
                >
                    <CustomField
                        disabled={disabled}
                        accepter ={Input}
                        name="name" 
                        placeholder="Name"
                    />
                    <CustomField
                        disabled={disabled || user.login_disabled}
                        accepter ={Input}
                        name="login" 
                        placeholder="Login"
                    />
                    <CustomField
                        disabled={disabled || user.email_disabled}
                        accepter ={Input}
                        name="email" 
                        placeholder="Email"
                    />
                    <BorderBtn onClick={() => onShowPasswordModal(user.key)} size="sm" >Set password</BorderBtn>
                    <div style={{marginTop: 5, display: 'inline-block'}}>
                        <RemoveListButton onClick={() => onRemove(user.key)} />
                    </div>
                </Form>
                )
            }
                <Modal show={passwordModal} onClose={onCloseModal} >
                    <Message
                        type="info"
                        description={
                            <p>
                            The minimal length of password is 8 characters (just latin, digits special symbols #?!_@$%^&amp;* are allowed). Password must contain at least per one uppercase, lowercase and digit.
                            </p>
                        }
                        style={{marginBottom: 10}}
                    />
                    <Form  
                        layout="inline"
                        ref= { ref => passwordRef = ref}
                        // model = {passwordModel}
                        onChange = { () => onChangePasswordForm() }

                    >
                        <CustomField
                            disabled={disabled}
                            accepter ={Input}
                            name="password"
                            type="password" 
                            placeholder="Password"
                            errorMessage={errorsPasswordForm.password}
                        />
                        <CustomField
                            disabled={disabled}
                            accepter={Input}
                            name="confirm_password"
                            type="password" 
                            placeholder="Confirm password"
                            errorMessage={errorsPasswordForm.confirm_password}
                        />
                         <AddButton onClick={setPassword} size="sm" >Set password</AddButton>
                    </Form>
                </Modal>
            </>    
            
    );
}