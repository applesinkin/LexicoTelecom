import React from 'react';
import {FormGroup, FormControl, ControlLabel, HelpBlock} from 'rsuite'

export default class  extends React.PureComponent {
    render() {
      const { name, message, label,widthLabel, accepter, error, ...props } = this.props;
      return (
            <FormGroup className={error ? 'has-error' : ''} style={{marginBottom: 10, width:'100%'}}>
                { label && <ControlLabel style={{width:'100%', textAlign:'left', display:'block'}}>{label}</ControlLabel>}
                <FormControl
                    name={name}
                    accepter={accepter}
                    errorMessage={error}
                    errorPlacement="topRight"
                    style={{width:'250px'}}
                    {...props}
                />
            </FormGroup>
      );
    }
  }