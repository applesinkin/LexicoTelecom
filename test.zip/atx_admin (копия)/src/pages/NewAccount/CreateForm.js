import React from 'react';
import { Schema } from 'rsuite';
import { Form, FormGroup, FormControl, Input, SelectPicker, RadioGroup, Button, Icon, IconButton,  Radio, ControlLabel, HelpBlock, FlexboxGrid, CheckboxGroup, CheckPicker} from 'rsuite';
import Checkbox from '../../hoc/Checkbox';
import Contacts from './Contacts';
import Users from './Customers';
import CustomField from './CustomField';
import {ID} from '../../utils/helpers';
import { formValid } from '../../utils/validate';
import { initContact, contactModel } from './Contacts';
import { initUser, userModel } from './Customers';
import {AccountCreate} from './SaveModel';
import styled from 'styled-components';
import AddListButton from '../../styled/AddListButton';
import SaveButton from '../../styled/SaveButton';
import CancelButton from '../../styled/CancelButton';
import CloseAccount from './CloseAccount';
import OpenAccount from 'pages/NewAccount/OpenAccount';
import {connect} from 'react-redux';
import {
    addAuthNumber,
    addUploadAuthNumbers,
    deleteAuthNumber,
    editAuthNumber,
    getAuthNumbers, setAnyLoading
} from 'actions/auth_numbers';


const { StringType, NumberType, ArrayType } = Schema.Types;

const accountModel = Schema.Model({
    name: StringType().isRequired('Required').maxLength(40, 'The maximum is only 40 characters.'),
    account_manager_id: StringType().isRequired('Required'),
    cur_key: NumberType().isRequired('Required'),
    pt_key: NumberType().isRequired('Required'),
});


const styleRow = {margin:'10px 0px'};

export default ( {disabled, disabledCurrency = false, onSubmit: _onSubmit, currency_list, payment_terms_list, 
                    account_manager_list, formDefaultValue, account_id, onCancel, active, ...props} ) => {

    const {users: formDefaultUsers, contacts: formDefaultContacts } = formDefaultValue || {};
    const [form, setForm] = React.useState(null);
    const [contacts, updateContacts] = React.useState( formDefaultContacts && formDefaultContacts.length ? formDefaultContacts : [{...initContact, key: ID()}]);
    const [activeState, setActiveState] = React.useState(active);

    React.useEffect(()=> {
        if(!disabled && !contacts.length)
            updateContacts(formDefaultContacts && formDefaultContacts.length ? formDefaultContacts : [{...initContact, key: ID()}]);
    }, [formDefaultContacts, disabled]);

    const [users, updateUsers] = React.useState( formDefaultUsers || []);

    // Иногда пропадают юзеры, точнее в state users не попадает ничего и он undefined. Разботает раз через 5 раз. Какой-то странный рандом. Данное решение фиксит этот баг
    React.useEffect(()=> {
        if(!disabled && !users.length)
            updateUsers(formDefaultUsers || []);
    }, [formDefaultUsers, disabled]);

    const formsContactRef = {};
    const updateContactFormRef = (ref , key) => formsContactRef[key] = ref;

    const addContacts = () => {
        const unValidContacts = contacts.filter( contact => !formValid( contactModel.check(contact) ) );
        
        if(unValidContacts.length)
            unValidContacts.map(
                contact => formsContactRef[contact.key].check()
            );
        else
            updateContacts([...contacts, {...initContact, key: ID()}])            
    };

    const onSubmit = () => {
        const validContact  =
            !Object.keys(formsContactRef)
            .map( key => formsContactRef[key].check() )
            .filter( check => !check).length;

        const validUsers  =    
            !Object.keys(formsUsersRef)
            .map( key => formsUsersRef[key].check() )
            .filter( check => !check).length;
        
        if(validContact && validUsers && form.check()){
            _onSubmit(new AccountCreate(form.getFormValue()),
                    form.getFormValue().account_manager_id,
                    users,
                    contacts
            )
        }
    };

    const formsUsersRef = {};
    const updateUsersFormRef = (ref , key) => formsUsersRef[key] = ref;

    const onAddUser = () => {
        const unValidUsers = users.filter( user => !formValid(userModel.check(user)) && !user.email_disabled);
        
        if(unValidUsers.length)
            unValidUsers.map(
                user => formsUsersRef[user.key].check()
            );
        else
            updateUsers([...users, {...initUser, key: ID()}])            
    };
    
    return (
        <Form          
          model={accountModel}
          style={{marginBottom: '20px'}}          
          layout="horizontal"
          ref = { ref => setForm(ref)}
          formDefaultValue = {formDefaultValue}
        >   
         <FlexboxGrid style={styleRow}>
             <FlexboxGrid.Item colspan={6} >
                <CustomField
                    disabled={disabled}
                    accepter ={Input}
                    name="name"
                    placeholder="Account name"
                    label="Account name"
                />
                
                <CustomField
                    disabled={disabled}
                    accepter ={SelectPicker}
                    size="sm"
                    placeholder="Account manager"
                    data={account_manager_list}
                    labelKey="name"
                    valueKey="id"
                    name="account_manager_id"
                    label="Account manager"
                    searchable = {false}
                    cleanable = {false}
                /> 
                
                <CustomField
                    disabled={disabled || disabledCurrency}
                    accepter ={SelectPicker}
                    size="sm"
                    name="cur_key"
                    placeholder="Currency"
                    data={currency_list}
                    labelKey="name"
                    valueKey="cur_key"
                    label="Currency"
                    searchable = {false}
                    cleanable = {false}
                />

                <CustomField
                    disabled={disabled}
                    accepter ={SelectPicker}
                    size="sm"
                    name="pt_key"
                    placeholder="Payment terms"
                    data={payment_terms_list}
                    labelKey="name"
                    valueKey="pt_key"
                    label="Payment terms"
                    searchable = {false}
                    cleanable = {false}

                /> 
            </FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={7} style={{marginTop: 33}} >
                
                <CustomField
                    disabled={disabled}
                    accepter ={Checkbox}
                    name="allocate_number"
                    defaultChecked = {formDefaultValue.allocate_number}
                >
                 Allow to allocate numbers himself
                </CustomField>

                <CustomField
                    disabled={disabled}
                    accepter ={Checkbox}
                    name="allocatr_pattern"
                    defaultChecked = {formDefaultValue.allocatr_pattern}
                >
                 Allow to allocate own numbers
                </CustomField>

            </FlexboxGrid.Item>

            <FlexboxGrid.Item colspan={10}  style={{marginTop: 33}}>
                
                <CustomField
                    disabled={disabled}
                    accepter={RadioGroup}
                    name="trunk_notificaton"
                >
                    <Radio style={{width:450}} value={'all_numbers_trunk'}>Send full list of allocated numbers for trunk after update</Radio>
                    <Radio style={{width:450}} value={'all_numbers_all_trunks'}>Send full list of allocated numbers for all trunk after update</Radio>
                    <Radio style={{width:450}} value={'number_trunk'}>Send only new allocated numbers</Radio>
                    <Radio style={{width:450}} value={'nothing'}>Don't send notifications</Radio>

                </CustomField>

            </FlexboxGrid.Item>
        </FlexboxGrid>    

        <FlexboxGrid style={styleRow}>
            <HeaderList>Contacts <AddListButton  onClick = {addContacts} /> </HeaderList>
        </FlexboxGrid>    

        <FlexboxGrid style={styleRow}>
            <Contacts  {...{contacts,updateContacts,disabled}} formsRef={formsContactRef}  updateFormRef={updateContactFormRef}/>
        </FlexboxGrid>

        <FlexboxGrid style={styleRow}>
            <HeaderList>Customers  <AddListButton onClick = {onAddUser} /> </HeaderList>
        </FlexboxGrid>    
        
        <FlexboxGrid style={styleRow}>
            <Users  {...{users,updateUsers,disabled}} formsRef={formsUsersRef}  updateFormRef={updateUsersFormRef}/>
        </FlexboxGrid>

        <ButtonFooter>
            <SaveButton disabled={disabled}  onClick = {onSubmit}>Save</SaveButton>
            <CancelButton onClick={() => onCancel()}>Cancel</CancelButton>
            {activeState
                && account_id && <CloseAccount onUpdate={() => {setActiveState(false)}} target={{account_id}} />
                || account_id && <OpenAccount onUpdate={() => {setActiveState(true)}} target={{account_id}} />
            }
        </ButtonFooter>
        </Form>
    );
};

const HeaderList = styled.div`
    font-family: Roboto;
    font-style: normal;
    font-weight: 500;
    font-size: 18px;
    line-height: 21px;
    /* identical to box height */
    color: #8256C8;
`;


const ButtonFooter = styled.div`
    text-align: center
    >div{
        margin-right: 50px
    }
`;