export function  AccountCreate (form){
    this.active = true;
    this.description = 'Description is required? Realy??? You dont read task!'
    this.is_dailer = true;
    this.is_supplier = false;
    this.permission_list = [];

    form.allocate_number && this.permission_list.push('allocate_number');
    form.allocatr_pattern && this.permission_list.push('allocatr_pattern');
    this.trunk_notificaton = form.trunk_notificaton;

    this.name  = form.name;
    this.cur_key = form.cur_key;
    this.pt_key = form.pt_key;

    // this.account_manager_id = form.account_manager_id;
    // this.CONTACT_LIST  = form.contacts;
}
