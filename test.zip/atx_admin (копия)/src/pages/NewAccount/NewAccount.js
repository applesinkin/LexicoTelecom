import React from 'react';
import {Alert, Loader, Placeholder} from 'rsuite';
import CreateForm from './CreateForm';
import Header from '../../styled/PageHeader';
import PanelLayout from '../../styled/PanelLayout';
import {api} from '../../api/loginRoutes';
import {withRouter} from 'react-router-dom';
import {ACCOUNT_CREATE_METHOD} from 'const/apiMethods';

const {Paragraph} = Placeholder;

class NewAccount extends React.Component {
    formDefaultValue = {
        account_manager_id: null,
        cur_key: null,
        pt_key: null,
        trunk_notificaton: 'all_numbers_trunk'
    };

    state = {
        disabled: false
    };

    constructor(props) {
        super(props);

        this.setUpFormDefaultValues(props);
    }

    setUpFormDefaultValues(props) {
        const {currency_list, payment_terms_list, account_manager_list} = props;

        if (currency_list.length)
            this.formDefaultValue.cur_key = currency_list[0].cur_key;

        if (payment_terms_list.length)
            this.formDefaultValue.pt_key = payment_terms_list[0].pt_key;

        if (account_manager_list.length)
            this.formDefaultValue.account_manager_id = account_manager_list[0].id;
    }

    checkData = () => {
        return !!Object.keys(this.formDefaultValue).filter(
            x => this.formDefaultValue[x] === null
        ).length;
    };

    shouldComponentUpdate(nextProps, nextState, nextContext) {
        this.setUpFormDefaultValues(nextProps);

        return true;
    }

    onCancel = () => {
        this.props.history.goBack();
    };

    onSubmit = async (data, account_manager_id, users, contacts = []) => {
        this.setState({disabled: true});

        try {
            const result = await api(ACCOUNT_CREATE_METHOD, {...data, target: {account_manager_id}}, true);
            this.setState({disabled: false});

            if (result && result.account && result.account.id) {
                await Promise.all([
                        ...users.map(
                            (user) => api('account_user:create', {...user, target: {account_id: result.account.id}})
                        ),
                        ...contacts.map(
                            (contact) => api('account_contact:create', {
                                ...contact,
                                target: {account_id: result.account.id}
                            }, true)
                        )
                    ]
                ).finally(() => {
                    this.props.history.replace({
                        pathname: `/accounts/view/${result.account.id}`,
                        search: '?tab=general'
                    });
                });
            }
        } catch (e) {
            Alert.error('Account name already exists, please change to another');
            this.setState({disabled: false});
        }
    };

    render() {
        const {disabled} = this.state;
        const {currency_list, payment_terms_list, account_manager_list, loadingReferences} = this.props;

        return (
            <div>
                <PanelLayout>
                    <Header>Create Account</Header>
                    {loadingReferences && <Loader backdrop content="loading..." vertical/>}

                    {
                        loadingReferences
                            ?
                            <Paragraph rows={5}/>
                            :
                            <CreateForm
                                onSubmit={this.onSubmit}
                                disabled={loadingReferences || disabled}
                                formDefaultValue={this.formDefaultValue}
                                onCancel={this.onCancel}
                                {...{currency_list, payment_terms_list, account_manager_list}}
                            />
                    }

                </PanelLayout>
            </div>
        );

    }
}

export default withRouter(NewAccount);