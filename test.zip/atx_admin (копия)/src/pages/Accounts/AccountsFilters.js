import React from 'react';
import {Icon, InputGroup, Schema} from 'rsuite'
import { Form, FormGroup, FormControl, ControlLabel, HelpBlock, FlexboxGrid, CheckboxGroup, } from 'rsuite';
import Checkbox from '../../hoc/Checkbox';
import CheckPicker from '../../hoc/CheckerPicker';
import { formValid } from '../../utils/validate';
import FormHOC from '../../hoc/FilltersForm';

const { StringType, ArrayType } = Schema.Types;

const accFiltersModel = Schema.Model({
    name: StringType().maxLength(5, 'The maximum is only 5 characters.'),
    account_manager: ArrayType()
});



export default FormHOC( ( {onChange,account_manager_list} ) => {
    return (
        <Form
          onChange={onChange}
          model={accFiltersModel}
          style={{marginBottom: '5px'}}
          formDefaultValue={{traffic_check:true}}
          fluid
        >
         <FlexboxGrid  style={{marginBottom: '10px'}}>
            <FlexboxGrid.Item colspan={3}>

                    <InputGroup>
                        <FormControl name="account_name" errorPlacement="topRight"  placeholder="Account name"/>
                        <InputGroup.Addon><Icon icon="search" /></InputGroup.Addon>
                    </InputGroup>


            </FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={1}></FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={4}>
                <FormGroup >                    
                    <CheckPicker
                        sticky
                        data={account_manager_list}
                        labelKey="name"
                        valueKey="id"                
                        style={{ width: 224 }}
                        placeholder="All account manager"
                        name="account_managger"
                        
                    />
                </FormGroup>
            </FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={3}>            
                <Checkbox  name="traffic_check" defaultChecked>Only with traffic</Checkbox>
            </FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={4}>            
                <Checkbox  name="allocated_check">Only with Allocated mumbers</Checkbox>
            </FlexboxGrid.Item>
            <FlexboxGrid.Item colspan={3}>            
                <Checkbox  name="closed_check">Show closed accounts</Checkbox>
            </FlexboxGrid.Item>
        </FlexboxGrid>
         

        </Form>
    );
}, accFiltersModel,300);