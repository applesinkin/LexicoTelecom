import React from 'react';
import { FlexboxGrid } from 'rsuite';
import AccountsTable from './AccountsTable';
import AccountsFilters from './AccountsFilters';
import { pipe } from '../../utils/helpers';
import { newAccount } from '../../routes';
import { Link } from 'react-router-dom';
import  PanelLayout from '../../styled/PanelLayout'
import GreenButton from 'styled/GreenButton';
import {checkPermissionsFor} from "store/storeHelpers";
import {ACCOUNT_CREATE_METHOD} from "const/apiMethods";
import accounts from "reducers/accounts";
import {ASC_SORT} from "const";

const FiltersFuncs = {
    account_name: (x,f) => x.name.toLowerCase().includes(f.toLowerCase()),
    account_managger: (x,f) => f.some( am_key => am_key === x.account_manager.id),
    traffic_check: (x,f) => !!x.VOLUME_1_OUT ||  !!x.VOLUME_7_OUT ||  !!x.VOLUME_30_OUT,
    allocated_check: (x,f) => !!x.allocated_numbers,
    closed_check: (x,f) => x.closed || !x.closed,
};

export default class  extends React.Component{

    state = {
        accounts: this.props.accounts,
        inner_loading: false
    }

    shouldComponentUpdate(nextProps) {                
        if(nextProps.accounts !== this.props.accounts){
            this.setState({accounts: this.withTraffic(this.onlyOpened(nextProps.accounts))});
            return false;
        }

        return true;
    }

    onlyOpened = (accounts) => {
        return accounts.filter(acc => !acc.closed)
    };

    withTraffic = (accounts) => {
        return accounts.filter(FiltersFuncs.traffic_check)
    };

    componentDidMount() {
        this.props.getAccounts();
    }

    onChangeFilters = (filters) => {
        this.setState({inner_loading:true})
        setTimeout(()=>this.setState({
            accounts: filters.closed_check
                    ?
                    pipe(this.props.accounts, filters, FiltersFuncs)
                    :
                    this.onlyOpened(pipe(this.props.accounts, filters, FiltersFuncs)), 
            inner_loading: false
        }),0)
    }    

    setLoading = (loading) => {
        this.setState({inner_loading:loading});
    }

    render () {
        const { loading, account_manager_list } = this.props;
        const { accounts, inner_loading } = this.state;

        return (
            <PanelLayout>
                <FlexboxGrid >
                    <FlexboxGrid.Item colspan={21}>
                        <AccountsFilters onChange={this.onChangeFilters}  {...{account_manager_list}} setLoading={this.setLoading}/>
                    </FlexboxGrid.Item>
                    <FlexboxGrid.Item colspan={3} style={{textAlign:'right'}} >
                    {checkPermissionsFor(ACCOUNT_CREATE_METHOD) &&
                        <Link to={newAccount}><GreenButton>+Add account</GreenButton></Link>
                    }
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                
                <AccountsTable
                    data={accounts}
                    loading={loading || inner_loading}
                    defaultSortColumn="name"
                />
            </PanelLayout>
        )
    }
}