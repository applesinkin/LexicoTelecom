import React from 'react';
import {Table} from 'rsuite';
import {TableClientSortHOC} from 'components/Table/TableClientSort'
import { withRouter } from "react-router";
const { Column, HeaderCell, Cell } = Table;

export default TableClientSortHOC(withRouter(({data = [], loading, history, ...props}) => {
    return (
        <Table
            virtualized
            height={700}
            data={data}
            loading={loading}
            rowHeight={30}
            rowClassName={(rowData)=>{
                if (rowData)
                    return rowData.closed ?'table-row-account__closed':'table-row-account'
            }}
            onRowClick={ ({id}) => {
                history.push(`/accounts/view/${id}`)
            }}
            {...props}
        >            

            <Column flexGrow={2} sortable>
            <HeaderCell>Account</HeaderCell>
                <Cell dataKey="name" >
                    {
                        ({name, account_manager = {}}) =>  (
                            <span>{name + '/' + (account_manager.name || '')}</span>
                            )
                    }
                </Cell>
            </Column>            

            <Column  flexGrow={1} sortable>
            <HeaderCell>Currency</HeaderCell>
            <Cell dataKey="currency"  />
            </Column>

            <Column  flexGrow={1} sortable>
                <HeaderCell>Balance</HeaderCell>
                <Cell dataKey="balance">
                    {
                        ({balance, invoice_balance}) =>  balance+ '/'+ invoice_balance
                    }
                </Cell>
            </Column>

            <Column  flexGrow={1} sortable>
            <HeaderCell>Traffic for 1/7/30</HeaderCell>
                <Cell dataKey="VOLUME_1_OUT" >
                    {
                        ({VOLUME_1_OUT = 0, VOLUME_7_OUT = 0, VOLUME_30_OUT = 0}) =>
                            `${VOLUME_1_OUT}/${VOLUME_7_OUT}/${VOLUME_30_OUT}`
                    }
                </Cell>
            </Column>

            <Column  flexGrow={1} sortable>
            <HeaderCell>Allocated Numbers</HeaderCell>
                <Cell dataKey="allocated_numbers">
                    {
                        ({allocated_numbers = 0, numbers_with_traffic = 0}) =>  `${allocated_numbers}/${numbers_with_traffic}`
                    }
                </Cell>
            </Column>
        </Table>
    );
}));