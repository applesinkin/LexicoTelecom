import React, {useState} from 'react';
import Modal from '../Account/Trunks/AllocatedNumbers/AllocateNumbersModal/Modal';
import {connect} from "react-redux";
import {closeAllocationModal} from "../../actions";

const NumberAlocation = ({show, onClose, defaultSPKey}) => {
    return <Modal
            show={show}
            disabledTrunk={false}
            sp_key={defaultSPKey}
            onClose={onClose}
        />
    ;
};

const mapState = ({settings, references}) => ({
    show: settings.showAllocation,
    defaultSPKey: references.defaultSPKey
});

export default connect(mapState, {
    onClose: closeAllocationModal
})(NumberAlocation);