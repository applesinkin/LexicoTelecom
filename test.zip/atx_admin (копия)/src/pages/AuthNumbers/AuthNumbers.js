import React, {Component} from 'react';
import PanelLayout from '../../styled/PanelLayout';
import {FlexboxGrid} from 'rsuite';
import {connect} from 'react-redux';
import {
    addAuthNumber,
    addUploadAuthNumbers,
    deleteAuthNumber,
    editAuthNumber,
    getAuthNumbers,
    setAnyLoading
} from '../../actions/auth_numbers';
import Uploader from 'rsuite/es/Uploader';
import Button from 'rsuite/es/Button';
import Icon from 'rsuite/es/Icon';

import './AuthNumbers.css';
import AuthNumbersFilter from './AuthNumbersFilter';
import Header from '../../styled/PageHeader';
import AuthNumbersTable from './AuthNumbersTable';
import ModalEdit from 'components/Modal/ModalEdit';

const uploaderIcons =
    {
        'inited': 'arrow-up2',
        'uploading': 'spinner',
        'error': 'warning',
        'finished': 'check-circle',
    };

class AuthNumbers extends Component {
    constructor(props) {
        super(props);

        this.defaultFilters = {number: ''};

        this.state = {
            numbers: [],
            filters: {number: ''},
            inner_loading: false,
            csv: [],
            showDeleteModal: {show: false, key: null},
            onDeletePostFunction: null
        };

    }

    componentDidMount() {
        const {getAuthNumbers} = this.props;

        getAuthNumbers();
    }

    onChangeFilters = (filters) => {
        let filterData;

        if (Object.keys(filters).length === 0) {
            filterData = this.defaultFilters;
        } else {
            filterData = filters;
        }

        this.setState({
            inner_loading: true,
            filters: filterData,
        });

    };

    onAddAuthNumber = (number, description) => {
        const {addAuthNumber, getAuthNumbers} = this.props;

        addAuthNumber(number, description, getAuthNumbers);
    };

    onEditAuthNumber = (id, number, description) => {
        const {editAuthNumber} = this.props;

        editAuthNumber(id, number, description);
    };

    onDeleteAuthNumber = (id) => {
        const {deleteAuthNumber} = this.props;

        deleteAuthNumber(id);
    };

    handleChangeCSV = (value) => {
        const file = value.slice(-1).pop();


        this.setState({
            csvList: [file],
            csvFile: file
        });
    };

    getFilteredData = (data) => {
        const {filters} = this.state;

        const filterName = filters && filters.number || '';
        const dataValue = data.filter(value => value && (value.number && value.number.includes(filterName)));

        return dataValue ? dataValue : [];
    };

    onPickDeleteNumber = (show, key, postFunction) => {
        this.setState({
            showDeleteModal: {show, key},
            onDeletePostFunction: postFunction
        });
    };


    render() {
        const {auth_number_list, setAnyLoading, getAuthNumbers, loading, loadingItem} = this.props;
        const {csvList, csvFile, filters, showDeleteModal, onDeletePostFunction} = this.state;

        const onAddAuthNumber = this.onAddAuthNumber;
        const onEditAuthNumber = this.onEditAuthNumber;
        const onDeleteAuthNumber = this.onDeleteAuthNumber;
        const onPickDeleteNumber = this.onPickDeleteNumber;

        setAnyLoading(false);

        const initialData = this.getFilteredData(auth_number_list);

        return (
            <PanelLayout>
                <Header>
                    <FlexboxGrid.Item colspan={21}>
                            <span
                                style={{
                                    marginLeft: '15px'
                                }}
                            >
                                List of auth numbers
                            </span>
                    </FlexboxGrid.Item>
                        <Uploader
                            autoUpload={true}
                            disabledFileItem={true}
                            ref={ref => {
                                this.uploader = ref;
                            }}
                            data={csvFile}
                            onChange={this.handleChangeCSV}
                            // action={}
                            onSuccess={(response) => {
                                if (response !== undefined) {
                                    getAuthNumbers();
                                }
                            }}
                            style={{
                                position: 'absolute',
                                right: '0',
                                width: '150px'
                            }}
                            disabled={'disabled'}
                        >
                            <Button
                                style={{
                                    border: '2px solid #20BA88'
                                }}
                            >
                                {
                                    csvFile && <Icon

                                        icon={uploaderIcons[csvFile.status]}
                                        pulse={csvFile.status === 'uploading'}
                                        style={{
                                            marginRight: '5px'
                                        }}/>
                                    || <Icon
                                        icon="file"
                                        style={{
                                            marginRight: '5px',
                                            color: '#20BA88'
                                        }}
                                    />
                                }
                                <span>Upload from file</span>
                            </Button>
                        </Uploader>
                </Header>
                <FlexboxGrid>
                    <FlexboxGrid.Item colspan={21}>
                        <AuthNumbersFilter
                            onChange={this.onChangeFilters}
                            setLoading={setAnyLoading}
                            defaultFilters={this.defaultFilters}
                        />
                    </FlexboxGrid.Item>
                    <FlexboxGrid.Item colspan={3} style={{textAlign: 'right'}}>
                    </FlexboxGrid.Item>
                </FlexboxGrid>
                <AuthNumbersTable
                    data={initialData}
                    {...{
                        filters,
                        loading,
                        loadingItem,
                        onAddAuthNumber,
                        onEditAuthNumber,
                        onDeleteAuthNumber,
                        onPickDeleteNumber,
                        getAuthNumbers
                    }}
                />
                {showDeleteModal && showDeleteModal.key && <ModalEdit show={showDeleteModal.show}
                            onClose={() => this.setState({showDeleteModal: false, key: null})}
                            onSuccess={() => {
                                this.onDeleteAuthNumber(showDeleteModal.key);
                                onDeletePostFunction && onDeletePostFunction();
                            }}
                            title={`Delete auth number`}
                            width={400}
                >
                    Are you sure about that?
                </ModalEdit>
                }
            </PanelLayout>
        );
    }
}

const mapState = ({auth_numbers}) => ({
    loading: auth_numbers.loading,
    auth_number_list: auth_numbers.auth_number_list,
    loadingItem: auth_numbers.loadingItem
});

export default connect(mapState, {
    getAuthNumbers,
    editAuthNumber,
    deleteAuthNumber,
    addAuthNumber,
    addUploadAuthNumbers,
    setAnyLoading
})(AuthNumbers);