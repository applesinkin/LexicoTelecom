import React, {Component, createRef} from 'react';
import {Schema, Table} from 'rsuite';
import Form from 'rsuite/es/Form';
import Text from 'components/Form/Text';
import Button from 'rsuite/es/Button';
import Icon from 'rsuite/es/Icon';
import {connect} from 'react-redux';

const {StringType} = Schema.Types;
const {Column, HeaderCell, Cell} = Table;

export class AuthNumbersTable extends Component {
    constructor(props) {
        super(props);
        const {data} = this.props;

        this.emptyField = {number: '', description: '', an_key: 'new', edit: true};

        this.columns = [
            {label: 'Number', dataKey: 'number', width: 400},
            {label: 'Description', dataKey: 'description', width: 1150},
        ];
        this.formsNumbersRef = {};
        this.refTextArea = createRef();

        this.formModel = Schema.Model({
            number: StringType().pattern(/^[1-9][\d]*$/, 'The number must not begin with 0 and must contain only digits').isRequired('This is required field').maxLength(15, 'The maximum  of this field is 15 characters'),
            description: StringType().isRequired('This is required field').maxLength(255, 'The maximum of this field is 255 characters')
        });

        this.copy = null;
        this.defaultHeightTable = 500;

        this.state = {
            numberState: data || [],
            editState: null,
            formState: data || [],
            inputError: {},
            inputMessage: {},
            filledTextArea: '',
            autoHeightTable: this.defaultHeightTable
        };
    }

    componentDidUpdate = (prevProps) => {
        const {data, getAuthNumbers} = this.props;


        if (JSON.stringify(prevProps.data) !== JSON.stringify(data)) {
            if (data && !data.filter(number => number.an_key === 'new').length) {
                this.setState({numberState: data, formState: [...data, this.emptyField]});
            } else {
                this.setState({numberState: data, formState: data});
            }
            getAuthNumbers();

            data && data.length && this.setState({autoHeightTable : this.getAuthHeightTable(data)})
        }
    };

    componentDidMount = () => {
        const {formState} = this.state;
        const {data, getAuthNumbers} = this.props;

        // if (formState.length === 0 || !formState.filter(number => number.an_key === 'new').length) {
        //     this.setState({ formState: [...data, this.emptyField]});
        // }

        getAuthNumbers();
    };

    updateFormRef = (refStorage, ref, id, dataKey) => {
        refStorage[id] = {...refStorage[id], [dataKey]: ref};
    };

    updateTableValues = (formValues, id) => {
        const {numberState} = this.state;

        this.setState({
            numberState: [
                ...numberState.map(
                    number => number.an_key === id ? {...number, ...formValues} : number
                )
            ]
        });
    };

    updateFormValues = (formValues, id) => {
        const {formState} = this.state;

        this.setState({
            formState: [
                ...formState.map(
                    number => number.an_key === id ? {...number, ...formValues} : number
                )
            ]
        });
    };

    getNumbers = () => {
        const {getAuthNumbers} = this.props;

        getAuthNumbers();
    };

    renderColumn = ({label, dataKey, value = null, width = 300, ...props}) => {
        const {inputError, inputMessage, formState, editState, filledTextArea} = this.state;

        return (
            <Column width={width} {...props}>
                <HeaderCell>{label}</HeaderCell>
                <Cell dataKey={dataKey} rowIndex={dataKey}>
                    {
                        (rowData) => {
                            return <Form
                                onMouseOver={() => {
                                    this.copy = {[rowData.an_key]: dataKey};

                                    if (this.formsNumbersRef[rowData.an_key] && this.formsNumbersRef[rowData.an_key][dataKey]) {
                                        this.setState({filledTextArea: this.formsNumbersRef[rowData.an_key][dataKey].value});
                                    }
                                }}
                                onMouseOut={() => {
                                    this.copy =  null;
                                }}
                                classPrefix={'auth-number-form'}
                                model={this.formModel}
                                onError={error => {
                                    this.setState({
                                        inputError: {
                                            ...inputError,
                                            [rowData.an_key]: {...inputError[rowData.an_key], [dataKey]: error[dataKey]}
                                        }
                                    });
                                }}
                                key={rowData.an_key}
                                onChange={(formValues, event) => {
                                    const formCheck = this.formModel.check(formValues);
                                    const checker = Object.keys(formCheck).map(i => formCheck[i].hasError).some(value => value === false);

                                    this.setState({
                                        inputMessage: {
                                            ...inputMessage,
                                            [rowData.an_key]: {...inputMessage[rowData.an_key], [dataKey]: !checker}
                                        }
                                    });
                                    this.setState({
                                        formState: [
                                            ...formState.map(
                                                number => number.an_key === rowData.an_key ? {
                                                    ...number, ...formValues,
                                                    event: {...number.event, [event.target.name]: event.target}
                                                } : number
                                            )
                                        ]
                                    });
                                }}
                                value={(rowData.an_key !== 'new' ? {[dataKey]: rowData[dataKey]} : {...editState})}
                                formDefaultValue={(rowData.an_key !== 'new' ? {[dataKey]: rowData[dataKey]} : {[dataKey]: this.emptyField[dataKey]})}
                            >
                                <Text
                                    inputRef={ref => this.updateFormRef(this.formsNumbersRef, ref, rowData.an_key, dataKey)}
                                    className="auth-number-input"
                                    width={width - 10}
                                    readOnly={rowData.an_key || rowData.an_key === 'new' ? !rowData.edit : false}
                                    name={dataKey}
                                    placeholder={label}
                                    message={inputError && inputError[rowData.an_key] && inputMessage[rowData.an_key] && inputMessage[rowData.an_key][dataKey] &&
                                    <span className="rs-table-auth-numbers-input-error">
                                        {inputError[rowData.an_key][dataKey]}
                                    </span>
                                    }
                                />
                                {
                                    rowData.an_key !== 'new' &&
                                    !rowData.edit &&
                                    this.copy &&
                                    this.copy[rowData.an_key] &&
                                    this.copy[rowData.an_key] === dataKey &&
                                <>
                                    <Button
                                        className="rs-table-auth-numbers-copy-button"
                                        onClick={() => {
                                            if (this.formsNumbersRef[rowData.an_key]) {
                                                this.refTextArea.current.select();
                                                document.execCommand('copy');
                                            }
                                        }}
                                    >
                                        <Icon inverse icon="copy-o"/>
                                    </Button>
                                    <textarea
                                        ref={this.refTextArea}
                                        value={filledTextArea}
                                        className="rs-table-auth-numbers-textarea-hidden"
                                    />
                                </>}
                            </Form>;
                        }
                    }
                </Cell>
            </Column>
        );
    };

    getAuthHeightTable = (data) => {
        const length = (data.length);
        const height = data && length ? length * 46 + 40 : 40;

        return length <= 10 ? height : this.defaultHeightTable
    };


    render() {
        const {inputError, numberState, formState, inputMessage, editState, autoHeightTable} = this.state;
        const {loading, onAddAuthNumber, onEditAuthNumber, onPickDeleteNumber} = this.props;

        const renderedColumns = this.columns.map(this.renderColumn);
        return (<>
            <Table
            virtualized
            height={autoHeightTable}
            data={numberState}
            loading={loading}
            columns={this.columns}
            >
                {renderedColumns}
                <Column width={120}>
                    <HeaderCell>Action</HeaderCell>
                    <Cell>
                        {
                            rowData =>
                                <div style={{marginTop: '2px'}}>
                                    {! rowData.edit &&
                                    <Button    // Edit number
                                        color="green"
                                        onClick={() => {
                                            this.setState({editState: rowData});
                                            this.updateTableValues({edit: true}, rowData.an_key);
                                        }}
                                        className="rs-table-auth-numbers-buttons rs-table-auth-numbers-green-button"
                                    >
                                        <Icon icon="edit2"/>
                                    </Button>

                                    || <>
                                        <Button    // Confirm editing
                                            color="green"
                                            onClick={() => {
                                                const dataField = formState.find(number => number.an_key === rowData.an_key);
                                                this.updateTableValues({
                                                    ...dataField,
                                                    edit: false
                                                }, rowData.an_key);

                                                onEditAuthNumber(rowData.an_key, dataField.number, dataField.description);
                                            }}
                                            className="rs-table-auth-numbers-buttons rs-table-auth-numbers-green-button"
                                            disabled={
                                                formState && formState.length && Object.keys(this.formModel.check(formState.find(number => number.an_key === rowData.an_key)))
                                                    .map(i => this.formModel.check(formState.find(number => number.an_key === rowData.an_key))[i].hasError)
                                                    .some(value => value === true)
                                                    ? 'disabled' : ''
                                            }
                                        >
                                            <Icon icon="check-circle"/>
                                        </Button>
                                        <Button    // Cancel editing
                                            color="red"
                                            onClick={() => {
                                                this.getNumbers();
                                                this.setState({
                                                    editState: null,
                                                    inputMessage: {
                                                        ...inputMessage,
                                                        [rowData.an_key]: {...inputMessage[rowData.an_key], number: false, description: false}
                                                    }
                                                });
                                                this.updateTableValues({
                                                    ...rowData,
                                                    edit: false
                                                }, rowData.an_key);

                                                const formValue = formState.find(state => state.an_key === rowData.an_key);

                                                if (rowData.an_key === (editState && editState.an_key) && formValue.event) {
                                                    for (let name in formValue.event) {
                                                        if (formValue.event.hasOwnProperty(name)) {
                                                            formValue.event[name].value = editState[name];
                                                        }
                                                    }
                                                }
                                            }}
                                            className="rs-table-auth-numbers-buttons rs-table-auth-numbers-red-button"
                                        >
                                            <Icon icon="close-circle"/>
                                        </Button>
                                    </>

                                    }
                                    <Button    // Delete number
                                        color="red"
                                        onClick={() => {
                                            onPickDeleteNumber(true, rowData.an_key, () => {
                                                this.setState({
                                                    numberState:
                                                        [
                                                            ...numberState.filter(number => number.an_key !== rowData.an_key)
                                                        ]
                                                })
                                            });
                                        }}
                                        className="rs-table-auth-numbers-single-button rs-table-auth-numbers-red-button"
                                    >
                                        <Icon icon="trash2"/>
                                    </Button>
                                </div>
                        }

                    </Cell>
                </Column>
            </Table>
            <Form
                layout="inline"
                model={this.formModel}
                classPrefix="auth-add-number-form"
                onError={error => {
                    console.log({inputError: {...inputError["new"], "number": error[ "number"], "description": error["description"]}});
                    this.setState({
                        inputError: {
                            ...inputError,
                            "new": {...inputError["new"],
                                "number": error[ "number"],
                                "description": error["description"]
                            }
                        }
                    });
                }}
                onChange={(formValues, event) => {
                    const formCheck = this.formModel.check(formValues);
                    console.log({inputMessage: {...inputMessage["new"], "number": formCheck["number"].hasError, "description": formCheck["description"].hasError}}
                    );

                    this.setState({
                        inputMessage: {
                            ...inputMessage,
                            "new": {...inputMessage["new"], "number": formCheck["number"].hasError, "description": formCheck["description"].hasError}
                        }
                    });
                    this.setState({
                        formState: [
                            ...formState.map(
                                number => {
                                    return number.an_key === "new" ? {
                                        ...number, ...formValues,
                                        event: {...number.event, [event.target.name]: event.target}
                                    } : number
                                }
                            )
                        ]
                    });
                }}
                value={{...formState.find(number => number.an_key === "new")}}
                formDefaultValue={this.emptyField}
            >
                <Text
                    inputRef={ref => this.updateFormRef(this.formsNumbersRef, ref, "new", "number")}
                    className="auth-number-input"
                    width={390}
                    name="number"
                    placeholder={"Number"}
                    message={inputError && inputError["new"] && inputMessage["new"] && inputMessage["new"]["number"] &&
                        <span className="rs-table-auth-numbers-input-error">
                            {inputError["new"]["number"]}
                        </span>
                    }
                />
                <Text
                    inputRef={ref => this.updateFormRef(this.formsNumbersRef, ref, "new", "description")}
                    className="auth-number-input"
                    width={1140}
                    name="description"
                    placeholder={"Description"}
                    message={inputError && inputError["new"] && inputMessage["new"] && inputMessage["new"]["description"] &&
                        <span className="rs-table-auth-numbers-input-error">
                            {inputError["new"]["description"]}
                        </span>
                    }
                />
                    <Button    // Add number
                        style={{marginLeft: 10}}
                        color="green"
                        onClick={() => {
                            const numberValue = formState.find(number => number.an_key === 'new');
                            const number = numberValue.number;
                            const description = numberValue.description;
                            const duplicateNumber = numberState.find(value => value.number === number);
                            const duplicateDescription = numberState.find(value => value.description === description);

                            const key = duplicateNumber && Object.keys(duplicateNumber).length !== 0 ? duplicateNumber.an_key : "new";

                            const formEmptyField = formState.find(state => state.an_key === "new");

                            if (!duplicateNumber || duplicateNumber && !duplicateDescription) {
                                this.setState({
                                    editState: null,
                                    formState:
                                        [
                                            ...formState.filter(number => number.an_key !== "new" && number.an_key !== key),
                                            {...formEmptyField, number: '', description: ''}
                                        ]
                                });
                                for (let name in formEmptyField.event) {
                                    if (formEmptyField.event.hasOwnProperty(name)) {
                                        formEmptyField.event[name].value = '';
                                    }
                                }
                                onAddAuthNumber(number, description);
                                this.getNumbers();

                                console.log(formState);
                            }
                        }}
                        className="rs-table-auth-numbers-single-button rs-table-auth-numbers-green-button"
                        disabled={
                            !(inputMessage["new"] && (!inputMessage["new"]["description"] && !inputMessage["new"]["number"])) ? 'disabled' : ''
                        }
                    >
                        <Icon icon="plus"/>
                    </Button>
            </Form>
        </>);
    };
}

const mapState = ({auth_numbers}) => ({
    auth_number_list: auth_numbers.auth_number_list,
});

export default connect(mapState)(AuthNumbersTable);