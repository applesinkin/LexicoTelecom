import React from 'react';
import LeftIcon from '../../styled/LeftIconButton';
import Modal from '../../components/Modal';

import {Form, Schema, SelectPicker} from 'rsuite';
import CustomField from '../../components/Form/CustomField';
import {api} from '../../api/loginRoutes';
import FormHoc from '../../hoc/FilltersForm';
import InputSearch from '../../components/Form/InputSearch';
import ExportPrice from './ExportPrice';
import styled from 'styled-components';
import {DEFAULT_PER_PAGE_MEDIUM, MONTH_PT_NAME, USD_DEFAULT_CURRENCY_KEY, WEEK_PT_NAME} from '../../const';
import {getPaymentTermKeyByName} from '../../store/storeHelpers';
import MyTable from 'components/Table';

const {StringType, NumberType} = Schema.Types;

const ShowPrice = ({currency_list, sp_key}) => {
    const [show, setShow] = React.useState(false);
    const [items, setItems] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    const [count, setCount] = React.useState(0);
    const [page, setPage] = React.useState(1);
    const [filter, setFilter] = React.useState({
        cur_key: USD_DEFAULT_CURRENCY_KEY, str: ''
    });
    const per_page = DEFAULT_PER_PAGE_MEDIUM;

    const getData = (filter, page) => {
        setLoading(true);
        api('price_range:get_default_price', {
            filter: {cur_key: USD_DEFAULT_CURRENCY_KEY, str: '', ...filter, sp_key}, page, per_page,
            // add: {test_trunk_number_list:{}, service_plan_price:{} }
        })
            .then(({price_range_list, price_range_count}) => {
                setCount(price_range_count || 0);
                setPage(page);
                setItems(
                    (price_range_list || []).map(
                        item => {
                            item.payments_7_1 = '';
                            item.payments_30_45 = '';

                            if (item.payment_trems_rate_list
                                &&
                                item.payment_trems_rate_list.length
                            ) {

                                item.payments_7_1 = (item.payment_trems_rate_list.find(
                                    el => el.pt_key === getPaymentTermKeyByName(WEEK_PT_NAME)
                                ) || {}).rate || '';


                                item.payments_30_45 = (item.payment_trems_rate_list.find(
                                    el => el.pt_key === getPaymentTermKeyByName(MONTH_PT_NAME)
                                ) || {}).rate || '';
                            }

                            item.test_number = '';
                            if (item.test_trunk_number_list && item.test_trunk_number_list.length) {
                                item.test_number = item.test_trunk_number_list[0];
                                item.test_trunk_number_list[1] && (item.test_number += ' ...');
                            }
                            return item;
                        }
                    )
                );
                setLoading(false);
            })
            .catch(error => setLoading(false));
    };
    const onChangeFilters = (_filters) => {
        setFilter({str: _filters._str || '', cur_key: _filters.cur_key});
        getData({str: _filters._str || '', cur_key: _filters.cur_key}, page);
    };
    React.useEffect(() => {
        if (show) {
            setFilter({cur_key: USD_DEFAULT_CURRENCY_KEY, str: ''});
            getData({cur_key: USD_DEFAULT_CURRENCY_KEY, str: ''}, 1);
        }

    }, [show]);
    return (
        <>
            <LeftIcon onClick={() => setShow(true)} icon="eye">Show price</LeftIcon>
            <Modal
                show={show}
                title="Price"
                onClose={() => setShow(false)}
                width="90%"
            >
                <Header>
                    <div>
                        <Filters
                            {...{
                                currency_list
                            }}
                            onChange={onChangeFilters}
                        />
                    </div>
                    <div><ExportPrice str={filter.str} cur_key={filter.cur_key} sp_key={sp_key}/></div>
                </Header>

                <MyTable
                    data={items}
                    height="50%"
                    loading={loading}
                    columns={columns}
                    count={count}
                    page={page}
                    per_page={per_page}
                    getItems={(page) => getData(filter, page)}
                    ispagination
                    hidePerPage
                />
            </Modal>
        </>
    );
};

export default ShowPrice;


const filtersModel = Schema.Model({
    _str: StringType().maxLength(40, 'The maximum is only 40 characters.'),
});

const Filters = FormHoc(({onChange, currency_list}) => {

    return (
        <Form layout="inline"
              onChange={onChange}
              formDefaultValue={{cur_key: USD_DEFAULT_CURRENCY_KEY}}
              model={filtersModel}
        >
            <div style={{display: 'inline-block', width: 200}}>
                <CustomField
                    name="_str"
                    accepter={InputSearch}
                    errorPlacement="topRight"
                    placeholder="Prefix/Range name"
                    // style={{width:220}}
                />
            </div>
            <CustomField
                accepter={SelectPicker}
                data={currency_list}
                cleanable={false}
                searchable={false}
                labelKey="name"
                valueKey="cur_key"
                name="cur_key"
                classPrefix="allocated"
            />
        </Form>
    );
}, filtersModel, 300);

const columns = [
    {label: 'Prefix', dataKey: 'prefix'},
    {label: 'Range name', dataKey: 'name'},
    {label: 'Payout 7-1', dataKey: 'payments_7_1'},
    {label: 'Payout 30-45', dataKey: 'payments_30_45'},
    {label: 'Test number', dataKey: 'test_number'},
];

const Header = styled.div`
    margin-bottom: -20px;
    > div {
        display: inline-block;
        width: 50%
    }
    >div:last-child{
        text-align: right
    }
`;
