import React from 'react';
import GreenButton from 'styled/GreenButton';
import { API_Modal, MyForm, NumbersSelect, SDE_Component, NumberField,
        CheckboxControl, ErrorMessage } from '../../components/';
import {Table, InputNumber,  Alert, Form} from 'rsuite';
import {api} from '../../api/loginRoutes'
import styled from 'styled-components';
import RateField from "../../components/Form/RateField";
import {connect} from "react-redux";
import {getPaymentTermKeyByName} from "../../store/storeHelpers";
import {MONTH_PT_NAME, WEEK_PT_NAME} from "../../const";
import ServicePlans from "components/Filters/ServicePlans";


const AddNewSubdestination = ({sp_key, currency_list, update, defaultSPKey}) => {
    const [show, setShow] = React.useState(false);
    const [disabledRanges, setDisabled] = React.useState(true);
    const [rates, setRates] = React.useState([]);
    const [touched, setTouched] = React.useState(false);
    const [sdeList, setSdeList] = React.useState([]);
    const [sde_key, setSdeKey] = React.useState(null);


    React.useEffect(() => {
        if(show) {
            setTouched(false);
            setRates([]);
            setSdeKey(null);
            setSdeList([]);
            api('newsubdestination_list_for_sp', {sp_key})
                .then( ({ subdestination_list: data }) => setSdeList(data || []))
        }
    }, [show]);

    const onChangeRate = (cur_key, pt_key, rate) => {
        console.log(cur_key, pt_key);
        if(!touched) setTouched(true);

        setRates(
            rates => {
                const _rates = rates.filter(
                    rateObj => rateObj.cur_key !== cur_key || rateObj.pt_key !== pt_key
                );

                if (rate)
                    return [..._rates, {cur_key, pt_key, rate}];

                return _rates
            }
        )
    };


    const field1 =<NumberField
        disabled = {disabledRanges}
        min={1}
        step={1}
        label = "Ranges"
        name = "ranges"
    />;
    const field2 = <NumbersSelect
        disabled = {disabledRanges}
        label = "Numbers"
        name = "numbers"
    />;

    const noGenerateRange = disabledRanges || !sde_key;

    return (
        <>
            <GreenButton onClick={() => setShow(true)} >+ Add subdestination</GreenButton>
            { show &&
            <API_Modal
                title = "Add new Subdestination"
                onClose  = {() =>{
                    setDisabled(true)
                    setShow(false)
                }}
                successText = "Create"
                update = {update}
                checkFirstAll
                checkBefore = {() => {
                    if(!touched) setTouched(true);

                    return !!rates.length;
                }}
            >
                <MyForm
                    method="service_plan_price:new_subdestination"
                    formDefaultValue = {{sp_key}}
                    addData = {{
                        rates: rates
                    }}
                    noCheck
                    //remove rates fields from request
                    unsendFields={['00','01','10','11']}
                >
                    <ServicePlans filtered/>
                    <SDE_Component
                        subdestination_list = {sdeList}
                        labelKey = "sde_name"
                        name = "sde_key"
                        validationKey = "num_required"
                        onChange = {(v) => setSdeKey(v)}
                    />
                    {touched && !rates.length &&
                        <ErrorMessage>
                            Must be filled at least one Currency.
                        </ErrorMessage>}
                    <TablePayments
                        data={currency_list}
                        onChange={onChangeRate}
                    />
                </MyForm>
                <MyForm
                    formDefaultValue = {{sp_key: defaultSPKey, numbers: 1000}}
                    method="price_range__generate_by_sde"
                    checkResultKey = 'ranges'
                    update = { ({ranges}) => {
                        Alert.success(`Generated ${ranges || 0} ranges`)
                    }}
                    addData={{
                        sde_key
                    }}
                    noSend = {noGenerateRange}
                >
                    <CheckboxControl
                        onChange = {(value) => setDisabled(!value)}
                        useBr>
                        Make Ranges
                    </CheckboxControl>

                    {disabledRanges  ?  <Fieldset>{field1} {field2}</Fieldset> : <></>}
                    {!disabledRanges ?  field1 : <></>}
                    {!disabledRanges ?  field2 : <></>}
                </MyForm>
            </API_Modal>
            }
        </>
    );
};

const mapStateToProps = ({references}) => ({
    defaultSPKey: references.defaultSPKey
});

export default connect(mapStateToProps)(AddNewSubdestination);

const { Column, HeaderCell, Cell } = Table;

const TablePayments =  ({data, disabled, onChange}) => (
    <Table
        height={140}
        data={data}
        rowHeight={50}
    >
        <Column width={100}>
            <HeaderCell>Currency</HeaderCell>
            <Cell dataKey="name"/>
        </Column>

        <Column flexGrow={1}>
            <HeaderCell>7-1</HeaderCell>
            <Cell>
                { (row, i) => (
                    <RateField
                        disabled = {disabled}
                        onChange = { v => onChange(row.cur_key, getPaymentTermKeyByName(WEEK_PT_NAME), +v)}
                        name={`${i}0`}
                    />
                ) }

            </Cell>
        </Column>

        <Column flexGrow={1}>
            <HeaderCell>30-45</HeaderCell>
            <Cell>
                { (row, i) => (
                    <RateField
                        disabled = {disabled}
                        onChange = { v => onChange(row.cur_key, getPaymentTermKeyByName(MONTH_PT_NAME), +v)}
                        name={`${i}1`}
                    />
                ) }
            </Cell>
        </Column>
    </Table>
);

const Fieldset = styled.fieldset`
    border: none;
    margin: 0;
    padding: 0;
     > div {
         margin-right: 10px;
         vertical-align: middle;
     }
`;