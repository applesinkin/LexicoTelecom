import React from 'react';
import {Table as _Table} from 'rsuite';
import PanelLayout from '../../styled/PanelLayout';
import Header from '../../styled/PageHeader';
import PriceFilters from './PriceFilters';
import Ranges from './Ranges';
import AddNewSubdestination from './AddNewSubdestination';
import styled from 'styled-components';
import ShowPrice from './ShowPrice';
import ExportPrice from './ExportPrice';
import EditPrice from './EditPrice';
import Table from '../../components/Table';
import Edit from '../../styled/EditButton';
import {connect} from 'react-redux';
import {getPrices} from '../../actions/prices';
import {getRanges} from '../../actions/ranges';
import {USD_DEFAULT_CURRENCY_KEY} from '../../const';
import {checkPermissionsFor} from 'store/storeHelpers';
import {SP_CHANGE_RATE_METHOD, SP_PRICE_NEW_SUBDESTINATION_METHOD} from 'const/apiMethods';

const Top = styled.div`
    margin-bottom: -20px;
    > div:first-child {
        display: inline-block;
        width: 80%
    }
    >div:last-child{
        display: inline-block;
        width: 20%;
        text-align: right
    }
`;

const HeaderButton = styled.div`
    padding: 20px 0 ;
    > div:first-child {
        display: inline-block;
        width: 70%
    }
    >div:last-child{
        display: inline-block;
        width: 30%;
        text-align: right
    }
`;

class Prices extends React.Component {
    state = {
        sde_key: null,
        edit: false
    };

    constructor(props) {
        super(props);

        this.filters = {
            cur_key: USD_DEFAULT_CURRENCY_KEY,
            sp_key: props.defaultSPKey
        };
    }

    componentDidMount() {
        this.props.getPrices(this.filters, 1);

        // При открытии Prices из страниц не выбирался первый элемент списка прайсов. Add ranges random требует sde_key
        this.selectFirstPrice();
    }

    shouldComponentUpdate({service_plan_price_list: list},) {
        const {service_plan_price_list} = this.props;

        if (!service_plan_price_list.length
            &&
            service_plan_price_list !== list
            &&
            list[0]
            &&
            list[0].sde_key
        ) {
            this.setState({sde_key: list[0].sde_key}, () => {
                this.getRanges(this.filters);
            });

            return false;
        }

        return true;
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.service_plan_price_list !== this.props.service_plan_price_list) {
            this.selectFirstPrice();
        }
    }

    onClickPrice = (sde_key) => {
        this.setState({sde_key}, () => {
            this.getRanges(this.filters, 1);
        });
    };

    onChangeFilters = (filters) => {
        this.filters = filters;
        this.props.getPrices(filters, 1);
        this.selectFirstPrice();
    };

    getRanges = (filters, page = 1) => {
        const {sde_key} = this.state;
        const _filters = {...filters};

        delete _filters['cur_key'];

        this.props.getRanges({..._filters, sde_key}, page);
    };

    onEditPrice = (pt_key_1, pt_key_2) => {
        this.setState({edit: true, pt_key_1, pt_key_2});
    };

    selectFirstPrice = () => {
        const {service_plan_price_list, getRanges} = this.props;

        if (service_plan_price_list.length
            &&
            service_plan_price_list[0]
            &&
            service_plan_price_list[0].sde_key
        ) {
            const first_sde_key = service_plan_price_list[0].sde_key;
            this.setState({sde_key: first_sde_key}, () => {
                this.getRanges(this.filters);
            });
        }
    };

    render() {

        const {
            service_plan_price_list, loading, count, page,
            currency_list, worldzone_list, subdestination_list, destination_list,
            ranges, rangesLoading, rangesPage, rangesCount, first_sde_key
        } = this.props;

        window.sde_list = service_plan_price_list;

        const {sde_key, edit, pt_key_1, pt_key_2} = this.state;
        return (
            <PanelLayout>
                {edit && <EditPrice
                    sde_key={sde_key}
                    cur_key={this.filters.cur_key}
                    sp_key={this.filters.sp_key}
                    pt_key_1={pt_key_1}
                    pt_key_2={pt_key_2}
                    update={() => this.props.getPrices(this.filters, page)}
                    setShow={() => this.setState({edit: false})}
                />}
                <HeaderButton>
                    <div>
                        <Header>Prices</Header>
                    </div>
                    <div>
                        <ShowPrice currency_list={currency_list} sp_key={this.filters.sp_key}/>
                        <ExportPrice sp_key={this.filters.sp_key}/>
                    </div>
                </HeaderButton>
                <Top>
                    <div>
                        <PriceFilters
                            onChange={this.onChangeFilters}
                            {...{
                                currency_list,
                                worldzone_list,
                                subdestination_list,
                                destination_list,
                            }}/>
                    </div>
                    <div>
                        {checkPermissionsFor(SP_PRICE_NEW_SUBDESTINATION_METHOD) &&
                        <AddNewSubdestination
                            sp_key={this.filters.sp_key}
                            update={() => this.props.getPrices(this.filters, page)}
                            currency_list={currency_list}
                        />
                        }
                    </div>

                </Top>
                <Table
                    data={service_plan_price_list}
                    height="50%"
                    loading={loading}
                    columns={columns}
                    count={count}
                    page={page}
                    getItems={(page) => this.props.getPrices(this.filters, page)}
                    active_id={sde_key}
                    row_key='sde_key'
                    onRowClick={this.onClickPrice}
                    hidePerPage
                    ispagination
                    ActionCell={checkPermissionsFor(SP_CHANGE_RATE_METHOD) ? ActionCell(this.onEditPrice) : null}
                />
                <Ranges
                    getRanges={this.getRanges}
                    items={ranges}
                    loading={rangesLoading}
                    count={rangesCount}
                    page={rangesPage}
                    sde_key={sde_key}
                    filters={this.filters}
                    subdestination_list={subdestination_list}
                />
            </PanelLayout>
        );

    }
}

const columns = [
    {label: 'Subdestination', dataKey: 'subdestination_name'},
    {label: '7-1', dataKey: 'payment_terms_rate:7_1'},
    {label: '30-45', dataKey: 'payment_terms_rate:30_45'}
];

const {Column, HeaderCell, Cell} = _Table;

const ActionCell = (onEdit) => (
    <Column flexGrow={1}>
        <HeaderCell>Options</HeaderCell>
        <Cell>
            {rowData => (
                <div style={{position: 'relative', 'top': '-2px'}}>
                    <Edit onClick={() => onEdit(
                        rowData['payment_terms_rate:7_1'],
                        rowData['payment_terms_rate:30_45'],
                    )}/>
                </div>
            )}
        </Cell>
    </Column>
);

const mapState = ({references, prices, access_list, ranges}) => ({
    service_plan_price_list: prices.service_plan_price_list,
    loading: prices.loading,

    currency_list: references.currency_list,
    worldzone_list: references.worldzone_list,
    subdestination_list: references.subdestination_list,
    destination_list: references.destination_list,
    defaultSPKey: references.defaultSPKey,

    page: prices.page,
    count: prices.count,
    ranges: ranges.ranges,
    rangesLoading: ranges.loading,
    rangesPage: ranges.page,
    rangesCount: ranges.count,

});

export default connect(mapState, {
    getPrices,
    getRanges,
})(Prices);