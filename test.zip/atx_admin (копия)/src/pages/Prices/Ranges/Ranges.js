import React from 'react';
import {Table as _Table} from 'rsuite';
import AddNewRange from './AddNewRange';
import Table from '../../../components/Table';
import RangesFilters from './RangesFilters';
import styled from 'styled-components';
import List from '../../../styled/ListButton';
import {withRouter} from 'react-router';
import queryString from 'query-string';

const Header  = styled.div`
    margin-bottom: -20px;
    > div {
        display: inline-block;
        width: 50%
    }
    >div:last-child{
        text-align: right
    }
`;


 class Ranges  extends React.Component{
    filters={};
    filterform = null;

    onUpdateRef =  (ref) => this.filterform = ref;

    onChangeFilters = (filters) => {
        this.filters = filters;
        this.props.getRanges(this.filters, 1);
    }

    onClickList=()=> {
        const {sde_key, history, filters} = this.props;
        const params = {...filters, sde_key};
        const query = queryString.stringify(params);

        history.push(`/ranges-numbers?${query}`);
    };

    render () {

        const {items, loading, count, page, sde_key} = this.props;

        return (
            <>
                <Header>
                   <div>
                        <RangesFilters 
                            onChange = {this.onChangeFilters}
                            onUpdateRef = {this.onUpdateRef} />
                    </div>
                    <div>
                        <AddNewRange 
                            sde_key={sde_key}
                            disabled={!!sde_key}
                            update={() => this.props.getRanges(this.filters, page)}
                        />
                    </div>
                </Header>
                <Table
                    data={items}
                    height = "50%"
                    loading={loading}
                    columns = {columns} 
                    count = {count}
                    page = {page}
                    getItems = {(page) => this.props.getRanges(this.filters,page)}
                    ispagination
                    hidePerPage
                    ActionCell = {ActionCell(this.onClickList)} 
                />
            </>
        )

    }
}

export default withRouter(Ranges)

const columns = [
    {label: 'Range name', dataKey: 'name'},
    {label: 'Range prefix', dataKey: 'prefix'},
    {label: 'Numbers', dataKey: 'all_numbers'},
    {label: 'Allocated', dataKey: 'allocated_numbers'},
    {label: 'Test numbers', dataKey: 'test_number'},
];

const { Column, HeaderCell, Cell } = _Table;
const ActionCell = (onClickList) => (
    <Column flexGrow={1}>
        <HeaderCell>Options</HeaderCell>
        <Cell>
            { ({sde_key}) => (
                <div style={{position:'relative', 'top':'-2px'}}>
                    <List onClick={() => onClickList(sde_key)}/> 
                </div>
            )}
        </Cell>
    </Column>   
)