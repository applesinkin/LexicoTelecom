import React from 'react';
import GreenButton from 'styled/GreenButton';
import MyForm from '../../../components/MyForm';
import {Alert, Input, Radio, RadioGroup, SelectPicker} from 'rsuite';
import CustomField from '../../../components/Form/CustomField';
import ModalSendApi from '../../../components/Modal/ModalSendApi';
import SDE from '../../../components/Filters/SDE';
import NumberField from '../../../components/Form/NumberField';
import {connect} from 'react-redux';

const AddNewRange = ({sde_key, update}) => {
    const [show, setShow] = React.useState(false);
    const [random, setRandom] = React.useState(!!sde_key);
    const onChangeRandom = (value) => setRandom(value);
    let timerid = null;
    const [template_list, setTemplateList] = React.useState([]);
    const changeTemplateList = (str) => {
        clearTimeout(timerid);
        timerid = setTimeout(() => {
            str = str.replace(/\r?\n/g, ' ');
            setTemplateList(str.split(' ').filter(s => s !== ''));
        }, 300);
    };

    React.useEffect(() => {
        setRandom(!!sde_key);
    }, [sde_key]);

    return (
        <>
            <GreenButton onClick={() => setShow(true)}>+ Add ranges</GreenButton>
            {show &&
            <ModalSendApi
                title="Add new ranges"
                onClose={() => {
                    setShow(false);
                }}
                successText="Create"
                update={update}
            >
                {random
                    ?
                    RandomForm({onChangeRandom, sde_key})
                    :
                    TemplateForm({onChangeRandom, changeTemplateList, template_list})
                }
            </ModalSendApi>
            }
        </>
    );
};

export default connect()(AddNewRange);

const TemplateForm = ({onChangeRandom, changeTemplateList, template_list}) => {
    return (
        <MyForm
            // numbers: 100 было добавлено, потому, что при смене формы, не применяется formDefaultValue для другой формы,
            // если была выбрана эта форма и наоборот
            formDefaultValue={{numbers: 1000}}
            method="price_range__generate_by_templates"
            checkResultKey='ranges'
            update={({ranges}) => {
                Alert.success(`Generated ${ranges || 0} ranges`);
            }}
            addData={{template_list}}
        >
            <RadioGroup value={false} onChange={onChangeRandom} inline>
                <Radio value={false}>Per Template</Radio>
                <Radio value={true}>Random</Radio>
            </RadioGroup>
            <CustomField
                accepter={Input}
                name="template_list"
                onChange={changeTemplateList}
                validationKey="in_template_list_range"
                componentClass="textarea"
                wrap="off"
                rows={3}
                style={{width: 400}}
                placeholder="Template list(one per row)"/>
        </MyForm>
    );
};

const numbers = ['1000', '10000', '100000', '1000000'].map(x => ({label: x, value: +x}));
console.log(numbers);
const RandomForm = ({onChangeRandom, sde_key}) => {
    return (
        <MyForm
            formDefaultValue={{
                numbers: 1000,
                ranges: 1,
                sde_key
            }}
            method="price_range__generate_by_sde"
            checkResultKey='ranges'
            update={({ranges}) => {
                Alert.success(`Generated ${ranges || 0} ranges`);
            }}
            addData={{}}
        >
            <SDE name="sde_key" validationKey="num_required" classPrefix={undefined}/>
            <RadioGroup value={true} onChange={onChangeRandom} inline>
                <Radio value={false}>Per Template</Radio>
                <Radio value={true}>Random</Radio>
            </RadioGroup>
            <br/>
            <NumberField
                label="Number of ranges"
                name="ranges"
                placeholder="0" useBr
                min={1}
                step={1}
            />
            <CustomField
                accepter={SelectPicker}
                data={numbers}
                label="Number per range"
                name="numbers"
                cleanable={false}
                searchable={false}
            />
        </MyForm>
    );
};