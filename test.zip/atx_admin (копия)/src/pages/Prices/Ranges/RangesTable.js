import React from 'react';
import {Table, IconButton, Icon} from 'rsuite';
import RenderedColumns from '../../../components/Table/RenderColumns';
import List from '../../../styled/ListButton';

const { Column, HeaderCell, Cell } = Table;

const columns = RenderedColumns([
    {label: 'Range name', dataKey: 'name'},
    {label: 'Range prefix', dataKey: 'prefix'},
    {label: 'Numbers', dataKey: 'digit'},
    {label: 'Allocated', dataKey: 'allocated'},
    {label: 'Test numbers', dataKey: 'test_number'},
]);

export default ({data = [], loading, onClickList}) => {
    return (
        <Table
            height={140}
            data={data}
            loading={loading}
            rowHeight={30}
        >
            {columns}
            <Column width={100}>
                <HeaderCell />
                <Cell>
                    <List onClick={onClickList}/>
                </Cell>
            </Column>
        </Table>
    );
};