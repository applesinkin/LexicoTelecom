import React from 'react';
import {API_Modal, ApiRequest, Info, MyForm} from '../../components';
import {Alert, Checkbox, InputNumber, Table} from 'rsuite';
import {api} from '../../api/loginRoutes';
import RateField from '../../components/Form/RateField';
import {getPaymentTermKeyByName} from "store/storeHelpers";
import {MIN_RATE_VALUE, MONTH_PT_NAME, WEEK_PT_NAME} from "const";
import {SP_CHANGE_RATE_METHOD} from "const/apiMethods";
import MyTable from 'components/Table';

const { Column, HeaderCell, Cell } = Table;

const labelWidth = 130;
const inputNumberWidth = 100;
const heightResize = 190;
const rowHeight = 30;
const rowHeaderHeight = 40;

const styleF = {
    display: 'inline-block',
    width: 300,
    borderRight: '3px solid #C4C4C4',
    verticalAlign: 'middle',
    marginTop: 50
};
const styleT = {
    display: 'inline-block',
    width: 410,
    marginLeft: 20,
    verticalAlign: 'top'
};

const EditPrice = ({setShow,  sp_key, sde_key, cur_key, pt_key_1, pt_key_2, update}) => {
    const [accounts, setAccounts] = React.useState({
        data: [],
        loading: true
    });
    const [ptKey1, setPtKey1] = React.useState(pt_key_1 );
    const [ptKey1Checkbox, setPtKey1Checkbox] = React.useState(!!pt_key_1 || pt_key_1 === 0 );
    const [ptKey2, setPtKey2] = React.useState(pt_key_2);
    const [ptKey2Checkbox, setPtKey2Checkbox] = React.useState(!!pt_key_2 || pt_key_2 === 0);

    React.useEffect(()=>{
        setAccounts({
            ...accounts,
            loading: true,
        });

        api('service_plan_price:account_with_special_price',{
            sp_key,
            sde_key,
            cur_key
        }).then( ({account_with_special_price}) => setAccounts({
            data: account_with_special_price || [],
            loading: false
        }))
    }, [])

    const onChangeRate = (account_id, rate) => {
        setAccounts({
            ...accounts,
            data: accounts.data.map(
                row => row.account_id === account_id ? {...row, checked: true, rate} : row
            )
        })
    }
    const onChangeChecked = (selected) => {
        setAccounts({
            ...accounts,
            data: accounts.data.map(
                row => selected.list.includes(row.account_id) ? {...row, checked: true} : {...row, checked: false}
            )
        })
    }

    const numberControlProps = {
        labelWidth,
        width: inputNumberWidth,
        mr: 5
    }

    const checkboxProps = {
        inline: true
    }
    const calculatedHeight = accounts.data.length < 5 && accounts.data.length > 0 ? rowHeight * accounts.data.length + rowHeaderHeight : heightResize;
    return (
        <API_Modal
            title = "Change rate for subdestination"
            onClose  = {() => setShow(false)}
            successText = "Change"
            width = {800}
            update = {() => {
                Alert.success('Changed');
                update();
            }}
        >
            <MyForm
                formDefaultValue = {{sp_key, sde_key, cur_key}}
                method = {SP_CHANGE_RATE_METHOD}
                // update = { (rusult) => {
                //     Alert.success(`Payment terms were chabged`)
                // }}
                addData = {{
                    new_rates: ([
                        (ptKey1Checkbox ? {pt_key: getPaymentTermKeyByName(WEEK_PT_NAME),rate: +ptKey1} : undefined),
                        (ptKey2Checkbox ? {pt_key: getPaymentTermKeyByName(MONTH_PT_NAME),rate: +ptKey2} : undefined)
                    ]).filter( x => x)
                }}
                noCheck
                style = {{...styleF, height: calculatedHeight}}
            >
                <div style={{
                    marginTop: (calculatedHeight - 70) / 2,
                    marginRight: 0,
                    marginBottom: 0,
                    height: 70
                }}>
                    <RateField
                        style={{padding: 0, margin: 0}}
                        label="New rate for 7/1" {...numberControlProps}
                        value={ptKey1} onChange={(v) => setPtKey1(v) || setPtKey1Checkbox(!!v)}/>
                    <Checkbox {...checkboxProps}
                              style={{padding: 0, margin: 0, marginTop: -20}}
                              checked={ptKey1Checkbox}
                              onChange={(v, checked) => {
                                  setPtKey1Checkbox(checked);

                                  if (checked) setPtKey1(ptKey1 || MIN_RATE_VALUE);
                              }}/>
                    <RateField
                        style={{padding: 0, margin: 0}}
                        label="New rate for 30/45" {...numberControlProps}
                        value={ptKey2} onChange={(v) => setPtKey2(v) || setPtKey2Checkbox(!!v)}/>
                    <Checkbox {...checkboxProps}
                              style={{padding: 0, margin: 0, marginTop: -20}}
                              checked={ptKey2Checkbox}
                              onChange={(v, checked) => {
                                  setPtKey2Checkbox(checked);

                                  if (checked) setPtKey2(pt_key_2 || MIN_RATE_VALUE);
                              }}/>
                </div>
            </MyForm>
            <ApiRequest
                method = 'account_price__set_account_list'
                data = {{
                    sp_key, sde_key, cur_key,
                    rates: accounts.data.filter(x => x.checked).map( x => ({account_id: x.account_id, rate: +x.rate}))
                }}
                noCheck
                style = {styleT}
            >
                <Info>These dialers have speial rates for this subdestination. Do you want to update them?</Info>
                <MyTable
                    heightResize={calculatedHeight}
                    data={accounts.data}
                    loading={accounts.loading}
                    columns = {columns}
                    row_key = "account_id"
                    setSelected = {onChangeChecked}
                    isselected
                    stateChecked
                    ActionCell = {ActionCell(onChangeRate)}
                />
            </ApiRequest>
        </API_Modal>
    );
}

export default EditPrice;

const columns = [{
    label: 'Dialer', dataKey: 'acc_name'
}];

const ActionCell = (onChange) => (
    <Column width={120}>
        <HeaderCell>Rate</HeaderCell>
        <Cell>
            {rowData => (
                <InputNumber
                    key={rowData.account_id}
                    max={10}
                    min={0.00001}
                    size="sm"
                    placeholder="0"
                    defaultValue={rowData.rate}
                    style={{position:'relative', top: '-5px', width: 100}}
                    onChange = { value => onChange(rowData.account_id, value)}
                />
            )}
        </Cell>
    </Column>
)
