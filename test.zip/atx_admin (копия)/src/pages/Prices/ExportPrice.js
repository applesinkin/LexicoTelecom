import React from 'react';
import LeftIcon from '../../styled/LeftIconButton';
import {getFileResponse} from '../../api/loginRoutes';
import {saveFileBlob} from '../../utils/helpers';
import {USD_DEFAULT_CURRENCY_KEY} from "../../const";

export default ({cur_key = USD_DEFAULT_CURRENCY_KEY, str = '', sp_key}) => {
    const [loading, setLoading] = React.useState(false);
    const exportFile = async () => {
        setLoading(true);

        const result = await getFileResponse('price_range:get_default_price',{
            filter:{ str, cur_key, sp_key },
            // add: { service_plan_price:{}}
        });

        if(result)
            saveFileBlob(result,'prices.csv');
        setLoading(false)

    };

    return (
        <LeftIcon onClick={() => exportFile()} loading = {loading} icon = "upload2" >Export price</LeftIcon>
    )
};