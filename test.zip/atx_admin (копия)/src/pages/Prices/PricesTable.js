import React from 'react';
import {Table, IconButton, Icon} from 'rsuite';
import RenderedColumns from '../../components/Table/RenderColumns';
import Edit from '../../styled/EditButton';

const { Column, HeaderCell, Cell } = Table;

const columns = RenderedColumns([
    {label: 'Subdestination', dataKey: 'subdestination_name'},
    {label: '7-1', dataKey: 'payment_terms_rate:7_1'},
    {label: '30-45', dataKey: 'payment_terms_rate:30_45'}
]);

export default ({data = [], loading, onClickPrice, onEditPrice}) => {
    return (
        <Table
            height={140}
            data={data}
            loading={loading}
            rowHeight={30}
            onRowClick={ ({sde_key}) => {
                onClickPrice(sde_key)
            }}
        >
            {columns}
            <Column flexGrow={1}>
                <HeaderCell/>
                <Cell>
                    <Edit onClick={() => onEditPrice()}/>
                </Cell>
            </Column>
        </Table>
    );
};