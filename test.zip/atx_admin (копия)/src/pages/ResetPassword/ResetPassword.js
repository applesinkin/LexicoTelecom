import React, {Component} from 'react';
import {
    Button,
    ButtonToolbar,
    Container,
    Content, ControlLabel,
    FlexboxGrid, Form, FormControl, FormGroup,
    Header,
    Icon,
    Nav,
    Navbar, Panel, Schema,
    Alert
} from "rsuite";
import {Link, withRouter} from 'react-router-dom';
import VersionLabel from "components/VersionLabel/VersionLabel";
import {notAuthApi} from "api/auth";
import history from "config/history";
import {DEFAULT_ERROR_MESSAGE, DEFAULT_NOT_AUTH_PATH} from "const";

const { StringType, NumberType} = Schema.Types;

export const requestFormModel = Schema.Model({
    email: StringType().isRequired('Required').isEmail('Email required'),
});

const resetPasswordFormModel = Schema.Model({
        password: StringType()
            .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])[A-Za-z'\d#?!_@$%^&*-]{8,}$/, 'Must contain at least one number and one uppercase and lowercase letter')
            .minLength(8, 'Password must be at least 8 characters ')
            .isRequired('This field is required'),
        confirm_password: StringType()
            .isRequired('This field is required')
            .addRule((value, formValues) => value === formValues.password, 'Passwords must be same')
    }
);

class ResetPassword extends Component {
    formRef = null;

    state = {
        isTokenValid: false,
        formValues: {}
    };

    handleSubmitResetRequest = () => {
        const formValues = this.formRef.getFormValue();

        if(this.formRef.check()){
            notAuthApi('account_user__reset_password:request', {...formValues, site: 1})
                .then(response => {
                    if (response !== undefined) {
                        Alert.success('Email was successfully sent! Check your SPAM folder');
                        history.push(DEFAULT_NOT_AUTH_PATH);
                    }
                })
                .catch(() => {
                    Alert.error('Incorrect email');
                });
        }
    };

    handleSubmitNewPassword = () => {
        const password = this.formRef.getFormValue().password;
        const token = this.props.match.params.token;

        if(this.formRef.check()){
            notAuthApi('account_user__reset_password:modify', {password, token}).then((response) => {
                Alert.success('Password successfully changed');
                history.push(DEFAULT_NOT_AUTH_PATH);
            }).catch(() => {
                Alert.error(DEFAULT_ERROR_MESSAGE);
            });
        }
    };

    componentDidMount() {
        const token = this.props.match.params.token;

        if (token) {
            notAuthApi('account_user__reset_password:check', {token}).then(() => {
                this.setState({
                    isTokenValid: true
                });
            }).catch(() => {
                Alert.error('Token expired, please try to reset password again');
            });
        }
    }

    render() {
        const isTokenValid = this.state.isTokenValid;

        return (
            <Container style={{height: '100vh'}}>
                <Header>
                    <Navbar appearance="inverse">
                        <Navbar.Header>
                        </Navbar.Header>
                        <Navbar.Body>
                            <Nav pullRight>
                                <Nav.Item componentClass={Link} icon={<Icon icon="sign-in" />} to="/login">Log in</Nav.Item>
                            </Nav>
                        </Navbar.Body>
                    </Navbar>
                </Header>
                <Content >
                    <FlexboxGrid justify="center" >
                        <FlexboxGrid.Item colspan={12} >
                            <Panel header={<h3>Reset Password</h3>} bordered style={{marginTop: '15vh'}}>
                                {!isTokenValid &&
                                    <Form fluid ref={ref => (this.formRef = ref)} model={requestFormModel}>
                                        <FormGroup>
                                            <ControlLabel>Please, enter an email address</ControlLabel>
                                            <FormControl autoFocus={true} name="email"/>
                                        </FormGroup>
                                        <FormGroup>
                                            <ButtonToolbar>
                                                <Button appearance="primary" type="submit"
                                                        onClick={this.handleSubmitResetRequest}>Reset</Button>
                                            </ButtonToolbar>
                                        </FormGroup>
                                    </Form>
                                }

                                {isTokenValid &&
                                <Form fluid
                                      ref={ref => (this.formRef = ref)}
                                      model={resetPasswordFormModel}
                                      formValue = {this.state.formValues}
                                      onChange={(formValues) => this.setState({formValues})}
                                >
                                    <FormGroup>
                                        <ControlLabel>Password</ControlLabel>
                                        <FormControl autoFocus={true} name="password" type="password"/>
                                    </FormGroup>
                                    <FormGroup>
                                        <ControlLabel>Confirm Password</ControlLabel>
                                        <FormControl name="confirm_password" type="password"/>
                                    </FormGroup>
                                    <FormGroup>
                                        <ButtonToolbar>
                                            <Button appearance="primary" type="submit"
                                                    onClick={this.handleSubmitNewPassword}>Reset Password</Button>
                                        </ButtonToolbar>
                                    </FormGroup>
                                </Form>
                                }
                            </Panel>
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                </Content>
                <VersionLabel/>
            </Container>
        );
    }
}

export default withRouter((ResetPassword));
