import React from 'react';
import TableClientSort from '../../components/Table/TableClientSort';
import { Table as _Table } from "rsuite";
import { RedBtn } from '../../styled/Buttons';
const { Column, HeaderCell, Cell } = _Table;

const columns = [
     {label: 'Account', dataKey: 'acc_name_orig', minWidth: 120, title:true, sortable: true},
     {label: 'A-number', dataKey: 'a_number' , minWidth: 120, sortable: true},
     {label: 'Originated from', dataKey: 'a_subdestination_name', minWidth: 150, title:true, sortable: true},
     {label: 'Rate orig', dataKey: 'rate_orig', minWidth: 120, align: 'center', sortable: true},
     {label: 'B-number', dataKey: 'b_number', minWidth: 120, sortable: true},
     {label: 'Destination', dataKey: 'b_subdestination_name', minWidth: 120, title:true, sortable: true},
     {label: 'Range', dataKey: 'range', title:true, sortable: true, minWidth: 100},
     {label: 'Rate term', dataKey: 'rate_term', minWidth: 120, align: 'center', sortable: true},
     {label: 'Dialer', dataKey: 'acc_name_term', title:true, sortable: true, minWidth: 100},
     {label: 'Termination point', dataKey: 'termination_point', minWidth: 150, align:'center', title:true, sortable: true},
     {label: 'Duration', dataKey: 'duration', minWidth: 100, sortable: true},
];


export default ({onStop, data, loading }) =>  {
        return (<TableClientSort
                    data={data}
                    loading={loading}
                    columns = {columns}
                    columnSelectorLSKey="LiveCallsTable"
                    ActionCell = {ActionCell(onStop)}
                 />
        );
}

const ActionCell = (onStop) => (
    <Column align={'center'} width={100}>
        <HeaderCell>Action</HeaderCell>
        <Cell>
            {({call_key}) => <RedBtn
                size="esm"
                onClick={() =>onStop(call_key)}
                style={{position:'relative', top:'-3px'}}>Stop</RedBtn>}
        </Cell>
    </Column>
)
