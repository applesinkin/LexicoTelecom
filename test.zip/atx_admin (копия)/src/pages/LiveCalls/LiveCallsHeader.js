import React from 'react';
import {InputGroup, Input, Icon, FlexboxGrid, Button} from "rsuite";
import {AddButton} from '../../styled/Buttons';

const styles = {
    width: 350,
    marginBottom: 10
};

export default ({onChange, onUpdate, loading})  => (
    <FlexboxGrid justify="space-between">
        <FlexboxGrid.Item colspan={12}>
            <InputGroup style={styles}>
                <Input onChange={onChange}
                    placeholder={'Filter per account/dialer/numbers/destinations'}
                />
            </InputGroup> 
        </FlexboxGrid.Item>
        <FlexboxGrid.Item colspan={12} style={{display: 'flex', 'justify-content': 'flex-end'}}>
            <AddButton onClick={onUpdate}  disabled={loading}>
                Update data
            </AddButton>
        </FlexboxGrid.Item>
    </FlexboxGrid>
)