import React from 'react';
import { FlexboxGrid } from 'rsuite';
import Header from '../../styled/PageHeader'
import LiveCallsTable from './LiveCallsTable';
import LiveCallsHeader from "./LiveCallsHeader";
import StopCallModal from './StopCallModal';
import PanelLayout from '../../styled/PanelLayout';

const SearchKeysIncluses = ['acc_name_orig', 'acc_name_term',  'a_subdestination_name', 'b_subdestination_name'];
const SearchKeysStarts = ['a_number', 'b_number']
    
export default class extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            show: false,
            data: props.live_calls_list,
            searchLoading: false
        }
    }

    shouldComponentUpdate (nextProps){  
        if(nextProps.live_calls_list !== this.props.live_calls_list){
            this.setState({data: nextProps.live_calls_list});
            if(this.searchValue) {
                this.onChangeFilters(this.searchValue);
            }
            return false;
        }
        return true;
    }

    componentDidMount() {
        this.props.getLiveCalls();
    }

    onChangeFilters = (value) => {
        clearTimeout(this.timerOnInputChange);
        const { searchLoading }=  this.state;
        if(!searchLoading) this.setState({searchLoading:true});
        
        this.timerOnInputChange = setTimeout( (value) => {
            this.searchValue = value;

            const { live_calls_list }  = this.props;
            const data = live_calls_list.filter( row => {
                for (let k of SearchKeysIncluses){
                    if(row[k].toLowerCase().includes(value))
                        return true;
                }
                for (let k of SearchKeysStarts){
                    if(row[k].toLowerCase().startsWith(value))
                        return true;
                }
                return false;
            })
            
            this.setState({data,searchLoading:false}) 
        }, 300, value.toLowerCase())
        
    };
    
    onStop = (id) => {
        this.call_key = id;
        this.setState({show: true})
    }
    onConfirmStopCallModal = () => this.props.stopCall(this.call_key, this.onCancelStopCallModal);
    onCancelStopCallModal = () => this.setState({show: false}, this.onUpdate)
    onUpdate = () => this.props.getLiveCalls();

    render () {
        const {data, searchLoading, show} = this.state;
        const {loading, loadingItem} = this.props;
        return (
            <PanelLayout >
                    <Header>Live calls</Header>
                    <FlexboxGrid >
                        <FlexboxGrid.Item colspan={24}>
                            <LiveCallsHeader
                                onUpdate={this.onUpdate}
                                onChange={this.onChangeFilters}
                                loading={loading}
                            />
                        </FlexboxGrid.Item>
                    </FlexboxGrid>
                        <LiveCallsTable
                            onStop={this.onStop}
                            data={data}
                            loading={loading || searchLoading}
                        />
                    <StopCallModal size={'xs'}
                                   show={show}
                                   loading={loadingItem}
                                   onCancel={this.onCancelStopCallModal}
                                   onConfirm={this.onConfirmStopCallModal}
                    />
            </PanelLayout>
        )
    }
}