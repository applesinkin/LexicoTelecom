import { connect } from 'react-redux';
import { getAccounts } from '../actions/accounts';
import Accounts from '../pages/Accounts';

const mapState = ( {accounts,references} )=> ({    
    loading: accounts.loading, 
    accounts: accounts.items,
    account_manager_list: references.account_manager_list    
});

export default connect( mapState, {getAccounts})(Accounts);
  