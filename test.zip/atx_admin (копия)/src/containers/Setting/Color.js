import { connect } from 'react-redux';
import { showModalColor, setColor } from '../../actions/settings';
import ColorComponent from '../../components/Settings/Color';

const mapState = ( {settings} )=> ({    
    show: settings.colorShow,
    color: settings.color,
});

export default connect( mapState, 
    {
        showModalColor,
        setColor
     }  )(ColorComponent);
  