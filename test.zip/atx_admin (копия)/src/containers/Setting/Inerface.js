import { connect } from 'react-redux';
import { showModalInterface, setSidebar } from '../../actions/settings';
import Interface from '../../components/Settings/Interface';

const mapState = ( {settings} )=> ({    
    show: settings.interfaceShow,
    sidebar: settings.sidebar,
});

export default connect( mapState, 
    {
        showModalInterface,
        setSidebar
     }  )(Interface);
  