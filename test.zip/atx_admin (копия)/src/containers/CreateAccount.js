import { connect } from 'react-redux';
import {createAccount} from '../actions/accounts';
import CreateAccount from '../pages/NewAccount';

const mapState = ( {references} )=> ({
    currency_list:references.currency_list,
    payment_terms_list: references.payment_terms_list,
    account_manager_list: references.account_manager_list,
    loadingReferences: references.loading  
})

export default connect( mapState, {createAccount})(CreateAccount);
  