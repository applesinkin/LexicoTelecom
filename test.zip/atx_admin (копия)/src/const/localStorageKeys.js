export const CDR_PER_PAGE = 'CDR_PER_PAGE';

export const USER_INFO = 'userInfo';