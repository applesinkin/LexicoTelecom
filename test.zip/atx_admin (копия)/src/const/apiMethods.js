export const CDR_LIST_METHOD = 'cdr_full:get_list_admin';
export const TRAFFIC_REPORTS_METHOD = 'cdr_full:group_get_list_admin';

export const AUTH_NUMBERS_GET_LIST = 'auth_number:get_list';
export const AUTH_NUMBERS_ADD_UPLOAD = 'auth_number:add_upload';
export const AUTH_NUMBERS_ADD = 'auth_number:create';
export const AUTH_NUMBERS_EDIT = 'auth_number:modify';
export const AUTH_NUMBERS_DELETE = 'auth_number:remove';

export const REFERENCES_METHOD = 'references_admin';
export const REFERENCES_FOR_REPORTS_METHOD = 'references_admin_report';

export const ACCOUNT_USER_MODIFY_BY_SELF = 'account_user:modify_by_self';
export const ACCOUNT_USER_MODIFY_PASSWORD_BY_SELF = 'account_user:modify_password_by_self';

/*Service plan methods*/
export const SP_CHANGE_RATE_METHOD = 'service_plan_price:change_rate';
export const SP_PRICE_NEW_SUBDESTINATION_METHOD = 'service_plan_price:new_subdestination';

export const ACCOUNT_CREATE_METHOD = 'account:create';
