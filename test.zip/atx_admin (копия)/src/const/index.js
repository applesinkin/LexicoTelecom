export const ACCOUNTS = 'ACCOUNTS';
export const VIEW_ACCOUNT = 'accounts::VIEW';
export const SET_VIEW_ACCOUNT = 'accounts::SET_VIEW';
export const SET_INFO_ACCOUNT = 'accounts::SET_INFO';

export const SET_TRUNK_ACCOUNT = 'accounts::SET_TRUNK';
export const SET_VIEW_ACCOUNT_AFTER_DELETE = 'accounts::SET_TRUNK_AFTER_DELETE';
export const ADD_TRUNK_ACCOUNT = 'accounts::ADD_TRUNK';

export const SET_ACCESS_LIST_FILTERS_LOADING = 'accounts::SET_ACCESS_LIST_FILTERS_LOADING';
export const SET_ACCESS_LIST_FILTERS = 'accounts::SET_ACCESS_LIST_FILTERS';

export const SET_USERS_ACCOUNT = 'accounts::SET_ACCOUNTS';
export const SET_USERS_ACCOUNT_LOADING = 'accounts::SET_ACCOUNTS_LOADING';

export const SET_EDIT_ERROR = 'accounts::SET_EDIT_ERROR';
export const SET_EDIT_ERROR_MESSAGE = 'accounts::SET_EDIT_ERROR_MESSAGE';

export const SET_TRUNK_ACCOUNT_LOADING = 'accounts::SET_TRUNK_LOADIING';
export const SET_ALLOCATED_ACCOUNT = 'accounts::SET_ALLOCATED';
export const SET_ALLOCATED_ACCOUNT_LOADING = 'accounts::SET_ALLOCATED_LOADING';

export const SETTINS_MODAL_SHOW = 'settings::MODAL';
export const SET_SIDEBAR = 'settings::SIDEBAR';
export const SETTINS_MODAL_COLOR_SHOW = 'settings::MODAL_COLOR';
export const SET_COLOR = 'settings::COLOR';


export const SET_AUTH = 'auth::SET_AUTH';
export const SET_LOADING_INFO = 'auth::SET_LOADING';

export const ACCESS_LIST = 'ACCESS_LIST';

export const LIVE_CALLS = 'live_calls';
export const LIVE_CALLS_LIST = 'live_call:get_list';
export const SET_LIVE_CALLS_LIST = 'live_calls::SET_LIVE_CALLS';

export const PRICES = 'service_plan_price:get_list_actual';
export const SET_SERVICE_PLAN_PRICE = 'SET_SERVICE_PLAN_PRICE';

export const REFERENCES_DIALER_TRUNK = 'REFERENCES_DIALER_TRUNK';

export const PRICE_RANGES = 'price_range:get_list';
export const SET_RANGES = 'price_range:SET_RANGES';

export const SPECIAL_RATES = 'account::special_rates';

export const  PRICE_NUMBERS = 'price_numbers';
export const  SET_NUMBERS = 'set_price_numbers';

export const AUTH_NUMBERS = 'auth_numbers';

export const SET_ROLES = 'atx/roles/SET_ROLES';

export const SET_NUMBER_ALLOCATION_MODAL = 'atx/settings/SET_NUMBER_ALLOCATION_MODAL';

export const ALERT_DISPLAY_DURATION = 5000;

export const DEFAULT_AUTH_PATH = '/accounts';
export const DEFAULT_NOT_AUTH_PATH = '/login';

export const DEFAULT_SP_KEY = 1;

export const MONTH_PT_NAME = '30_45';
export const WEEK_PT_NAME = '7_1';

export const DEFAULT_PRT_KEY = 1;

export const USD_CURRENCY_NAME = 'USD';
export const USD_DEFAULT_CURRENCY_KEY = 1;

export const EUR_CURRENCY_NAME = 'EUR';
export const EUR_DEFAULT_CURRENCY_KEY = 2;

export const DEFAULT_PER_PAGE_TINY = 5;
export const DEFAULT_PER_PAGE_SMALL = 10;
export const DEFAULT_PER_PAGE_MEDIUM = 15;
export const DEFAULT_PER_PAGE_BIG = 20;

export const DESC_SORT = 'desc';
export const ASC_SORT = 'asc';

export const MIN_RATE_VALUE = 0.0001;

export const EOL = navigator.appVersion.indexOf("Win") !== -1 ? '\n' : '\r\n';

export const DEFAULT_ERROR_MESSAGE = 'Something went wrong';

